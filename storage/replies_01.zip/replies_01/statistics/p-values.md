1. Misinterpretation and Misuse: P-values are often misunderstood and misused in research, leading to false conclusions. Many researchers interpret a p-value to mean the probability that their results were due to chance, which is incorrect. A p-value actually measures the probability of obtaining the observed data (or data more extreme) given that the null hypothesis is true.

2. Over-reliance: Another critique is the over-reliance on p-values as a measure of significance. A p-value does not indicate the magnitude or importance of an effect; it only signifies whether an effect is statistically significant.

3. Arbitrary Thresholds: P-values rely on arbitrary thresholds for significance. A common criticism is that the 0.05 cutoff for significance is arbitrary, and can lead to misinterpretation and misreporting of results. 

4. Reproducibility Crisis: The use of p-values has been cited as one of the contributing factors to the reproducibility crisis in science. A low p-value doesn't necessarily guarantee that the experiment will be reproducible.

5. Lack of Robustness: P-values are sensitive to sample size. With a large enough sample size, any small difference can be statistically significant, which doesn't mean the result is practically significant.

6. Ignoring Uncertainty: P-values provide a binary decision of reject/accept the null hypothesis and this approach ignores the uncertainty surrounding this decision. It doesn't tell us anything about the probability of the null hypothesis being true.

7. Null Hypothesis Significance Testing (NHST) Issues: Critics argue that p-values encourage a focus on testing hypotheses, rather than on estimating effect sizes and their corresponding uncertainties. 

8. P-hacking: This is the practice of changing your hypotheses based on the data you get, or stopping data collection once you have a significant result, which leads to false positives.

9. Not a measure of evidence: Some critics highlight that p-values should not be considered a measure of the weight of evidence against a null hypothesis.

10. Overlooking Pragmatic Considerations: P-values could overlook pragmatic considerations in favor of clinical or practical significance. For instance, a drug might show a statistically significant effect but the actual improvement in symptoms may be miniscule.