1. Cancer Risk Overstated: One of the most controversial ideas against the mainstream opinion on red meat is that its link to cancer has been grossly overstated. Critics argue that many studies don't differentiate properly between processed and unprocessed meats, or take into account cooking methods, which can significantly influence health outcomes. 

2. Obscuring the Real Issue: Some dissidents argue that focusing on red meat as a health risk diverts attention from the real culprits of modern disease, such as sugar, refined carbohydrates, and processed foods. 

3. Nutrient Density: There are those who defend red meat on the grounds of its nutrient density. They argue that red meat is a rich source of quality protein, essential amino acids, vitamins and minerals, and that there's a misinterpretation of the harm versus benefit ratio.

4. The Role of Quality: Critics argue that mainstream thought on red meat fails to distinguish between the quality of the meat, meaning meat from industrially-raised, grain-fed animals versus grass-fed, organically raised animals. They claim that quality makes a significant difference in the health impact of red meat.

5. Evolutionary Perspective: From an evolutionary point of view, some critics suggest that early human evolution was greatly influenced by the high nutrient content of red meat, and therefore our bodies are better adapted to digest and absorb nutrients from red meat, questioning the mainstream idea of red meat being harmful to health.

6. Misinterpretation of Data: Critics claim that many studies associating red meat with health problems are observational in nature and don't establish causation. They argue that many lifestyle factors aren't considered, like smoking, lack of exercise, and overall unhealthy diet besides red meat consumption.

7. Saturated Fat and Cholesterol Misconceptions: There's a growing group of advocates who argue that the notions around saturated fat and cholesterol being detrimental to health, particularly in relation to heart disease, are based on inconsistent and outdated research data. They argue that red meat's negative impact has been largely overemphasized based on these misconceptions.

8. Plant-based Bias: Some dissidents argue that there's a bias towards plant-based diets in nutritional research and the media. They claim that this bias skews the representation of the healthfulness of red meat. 

9. Lack of Personalization: Another important criticism is that nutritional recommendations around red meat are often blanket statements. Critics argue for a personalized nutrition approach, considering that people have different metabolic responses to foods, thus for some individuals moderate to high intakes of red meat might not pose any health risk.