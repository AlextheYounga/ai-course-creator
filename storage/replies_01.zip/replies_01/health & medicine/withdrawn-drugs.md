1. Lack of Transparency: Healthcare professionals, patients, and the general public are often unaware of the true reasons behind drug withdrawal, leading to misinformation and unnecessary panic. Companies may withdraw drugs for a variety of reasons, including economic considerations, manufacturing issues, or based on the results of post-marketing surveillance. 

2. Regulatory Failures: Some critics suggest that regulatory bodies have failed in their duty by approving drugs that later need to be withdrawn. This often leads to questions about the thoroughness of pre-market testing and the speed at which drugs are approved. 

3. Lack of Post-Market Surveillance: Critics argue there is often inadequate monitoring of drugs once they've been released into the market, leading to late detection of adverse effects. 

4. Inadequate Punishment for Pharma Companies: Some dissidents believe repercussions for pharmaceutical companies that need to withdraw drugs are not significant enough to deter negligence or gross malpractices such as suppressing negative trials or overstating benefits.

5. Over-Reliance on Pharmaceuticals: Critics make the point that our modern paradigm places too much emphasis on pharmaceutical solutions to health issues, potentially leading to unnecessary drug usage and eventually, drug withdrawals.

6. Profit Over Safety: Certain critics argue that pharmaceutical companies sometimes prioritize their profit over patient safety. The expedited development and approval of drugs can possibly compromise comprehensive safety assessments, leading to potential adverse health outcomes and subsequent withdrawals of drugs.

7. Failures in Clinical Trials: A significant criticism focuses on how initial clinical trials may fail to identify harmful side effects, especially those that may occur in the long term or on certain populations demographics that are underrepresented in clinical trials.

8. Discouraging Innovation: Following on from point 4, some critics suggest that fear of drug withdrawals creates an atmosphere of conservatism in the pharmaceutical industry, inhibiting the development of more radical or experimental treatments.  

9. Insufficient Patient Involvement: Critics might argue that patients lack agency in the current drug approval process, especially around decisions related to the risk-benefit ratio that ultimately leads to drug withdrawals. 

10. Ethical Concerns: There are also ethical concerns around withdrawing a drug once it has been approved, particularly if patients have become reliant on it and may face issues finding a suitable alternate treatment. This is particularly relevant for drugs treating chronic or life-threatening conditions.