Gadolinium is a contrast agent used in magnetic resonance imaging (MRI) to improve the clarity of the images. While it has gained mainstream acceptance, several dissident criticisms have emerged.

1. Nephrogenic Systemic Fibrosis (NSF): Gadolinium contrast agents, particularly linear forms, have been associated with a condition known as nephrogenic systemic fibrosis. This is a syndrome characterized by skin hardening, joint problems, and sometimes organ damage. It occurs primarily in patients with impaired kidney function.

2. Gadolinium Deposition Disease: While healthy kidneys can flush the contrast agent out of the body, in some patients, the gadolinium remains, leading to a condition called gadolinium deposition disease (GDD). GDD can cause a variety of symptoms such as brain fog, joint and bone pain, and skin changes, even in patients with normal kidney function.

3. Long-Term Effects: Scientists are just beginning to understand the long-term effects of gadolinium usage. Some research has hinted that gadolinium may stay in the body for months or even years after administration. The impact on human health over the long term still isn't fully understood.

4. Underreported Symptoms: Adverse reactions to Gadolinium, more than just the usual side effects, are often underreported. This includes the longer-term effects, which are currently less understood and are usually trivialized.

5. Allergic Reactions: While allergic reactions to gadolinium are rare, they can occur. These range from mild reactions (itching, rash) to severe (difficulty breathing, low blood pressure).

6. Inadequate Regulatory Oversight: Some argue that the approval process for contrast agents like gadolinium does not look sufficiently into the long-term effects or in patients with certain risk factors.

7. Alternatives to gadolinium: While gadolinium-based contrast agents greatly improve the diagnostic accuracy of MRIs, critics argue that alternative methods should be explored. In some instances, non-contrast MRIs are equally effective. There is a push for more research into these alternatives, especially given the potential risks associated with gadolinium.

8. Impact on Environment: Gadolinium waste is not easy to eliminate and thus, could accumulate in the environment over time. Its environmental impact is still not completely known but could be a potential concern.

It is important to note that gadolinium contrast agents have revolutionized imaging diagnostics, making it possible to visualize internal body structures in remarkable detail. That said, awareness and improved understanding of the potential drawbacks are essential.