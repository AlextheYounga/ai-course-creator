Bloodletting, the act of cutting a vein to let blood flow out, is now widely considered a rather outdated medical practice, falling out of favor with medical professionals somewhere in the late 19th century. Nonetheless, for the purpose of this question, major scholarly dissent against its use would likely include:

1. Lack of Scientific Evidence: A clear-cut argument against bloodletting is the lack of empirical evidence that it is beneficial. Modern medical practice is guided by rigorous scientific trials and studies, which are lacking for bloodletting. It is typically criticized as having anecdotal at best, or non-existent at worst, supportive evidence.

2. Potential for Harm: Bloodletting has the potential to do more harm than good. It can introduce infection, lead to severe blood loss, or result in other complications. 

3. Pseudoscientific Basis: The theoretical foundation of bloodletting—that sickness is caused by an imbalance of humors (blood, phlegm, and two types of bile) in the body—is not backed by scientific evidence. Modern medicine is based on understanding disease at molecular, cellular and physiological levels which contradicts the premise of bloodletting.

4. Indiscriminate Use: Historical accounts suggest bloodletting was used for many illnesses, regardless of the symptoms, disease, or patient's condition, which defies the principle of individualized modern medicine. 

5. Palliative not Curative: Some critics argue bloodletting merely manifests a placebo effect, as patients 'feel' better due to attention from physicians but it doesn't cure the underlying disease. This is against the principles of modern medicine which focuses on targeting the etiology of disease.

6. Ethical Concerns: In the past, bloodletting was performed without informed consent, with the power imbalance between doctor and patient adding another criticism.

It's essential to note that while bloodletting may no longer be in mainstream use, controlled phlebotomy is a valid practice for certain medical conditions, such as hemochromatosis or polycythemia.