1. Lack of Scientific Evidence: The most repetitive criticism of homeopathy is that it lacks scientific evidence. Most homeopathic remedies are so highly diluted that no molecules of the original substance remain in the final preparation. From a biochemical perspective, it's difficult to see how these remedies can have any effect beyond placebo.

2. Placebo Effect: Many arguments insist that any perceived benefits of homeopathic remedies are down to the placebo effect, where patients perceive an improvement in their health because they believe the treatment will work, not because it actually does.

3. Lack of Regulation: Homeopathic products do not have to go through the same rigorous testing and regulatory process as conventional medicines. This means there can be considerable variability in the quality and composition of homeopathic remedies.

4. Potential for Harm: While homeopathic remedies themselves are generally considered safe (due to their highly diluted nature), there is a significant risk that serious conditions can be left untreated in favor of homeopathic treatment. This can result in unnecessary harm or even death in some cases.

5. Economic Concerns: Critics note that the resources being used for the manufacturing, marketing, and distribution of homeopathic remedies could be better spent on proven treatments and public health initiatives.

6. Ethical Issues: There is also a significant ethical issue surrounding the promotion and sale of treatments that have no proven efficacy beyond placebo. Especially if they are being touted as alternatives to proven medical treatments. 

7. Contradicts Principles of Chemistry and Pharmacology: Homeopathy, with its concept of diluting substances to the point that virtually no molecules of the original substance remain, directly contradicts principles of chemistry and pharmacology. This forms a heavy point of criticism among many scientists and doctors.

8. Inconsistent Outcomes in Studies: Many high-quality studies fail to show that homeopathic treatments are more effective than a placebo, creating inconsistency and lack of replicability in the outcomes of studies. 

9. Misinterpretation and Miscommunication: Some critics argue that homeopaths often misinterpret the body's natural healing process as being the result of a homeopathic treatment, causing a miscommunication in perceived efficacy. 

10. Delay in Receiving Proper Treatment: If a patient decides to take homeopathic remedies for a serious condition, they could potentially delay receiving proper, scientific, and medically sound treatment which can lead to adverse effects on their health condition.