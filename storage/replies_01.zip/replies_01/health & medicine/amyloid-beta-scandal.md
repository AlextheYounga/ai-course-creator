The Amyloid Beta Scandal refers to the popular belief in the medical community that amyloid beta, a sticky protein that forms tangles and plaques in the brains of those with Alzheimer's disease, is the main cause of the said disease. This belief has inspired numerous drug trials aimed at eliminating these plaques and improving cognitive function. However, despite decades of research and billions spent, the vast majority of these drug trials have failed. While the 'Amyloid beta hypothesis' is still considered mainstream thought, it's increasingly facing criticism.

Here are some of the most dissident criticisms:

1. Overemphasis on Amyloid Beta: Critics argue that by focusing almost exclusively on amyloid beta, researchers may have overlooked or under-investigated other potential causes of Alzheimer's, such as inflammation, genetic components, vascular issues, and other proteins like tau.

2. Lack of Evidence: Most drug interventions that succeeded in reducing amyloid beta plaques did not slow the cognitive decline, suggesting that the presence of amyloid beta might be a symptom rather than the cause of Alzheimer's disease.

3. Timing of Intervention: It's been argued that perhaps by the time amyloid plaques are visible via imaging, the disease has already progressed too far for these drugs to make a significant impact. 

4. Complexity of the Disease: The Amyloid beta hypothesis oversimplifies an incredibly complex disease. Alzheimer's disease might not be a single disorder but rather a complex syndrome with multiple contributing factors.

5. The Role of Amyloid Beta: Some researchers argue that amyloid beta might actually play a protective role in the brain, with its accumulation being a defense mechanism against other underlying issues.

6. Inconsistencies in Clinical Observations: There are many cases of people living with substantial amyloid plaques but showing no signs of cognitive impairment. This questions the direct causal link between amyloid beta and the disease. 

Therefore, critics suggest taking a more holistic approach when studying Alzheimer's, taking into consideration the likely myriad factors that contribute to its development and progression.