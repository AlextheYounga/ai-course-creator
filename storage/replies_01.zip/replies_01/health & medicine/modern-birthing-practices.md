1. Over-Medicalization: One of the most outstanding dissident criticisms is the over-medicalization of birth process. Modern birthing has become more of a clinical procedure than a natural process, leading to an increased number of caesarian sections and induction of labor, potentially leading to unnecessary complications and longer recovery times.

2. Neglect of Traditional Knowledge: This includes wisdom and practices that may offer a holistic approach to birth by considering emotional, spiritual, and cultural aspects. These traditions often promote a more comfortable and less stressful environment for mothers.

3. Interventions: Modern practices are often intervention-heavy which may not always be necessary. Frequent use of tools such as forceps, vacuums, and episiotomy can potentially cause harm to both the mother and the baby.

4. Lack of Personalized Care: The assembly-line style of medical birthing often lacks personalized, one-on-one attention. Personal care, patience, and empathy can often lead to better birth experiences and outcomes.

5. Lack of Mother Control: Contemporary birth practices often take control away from the mother. Decisions are made by healthcare professionals with little input from the mother, leading to feelings of detachment.

6. Financially Driven: Some critics argue that cost plays a driving role in many birthing decisions. For example, cesarean sections or inducing labor may end up costing more than a natural birth.

7. Postpartum Support: Modern birthing practices give little consideration to postpartum support and care for the mother. This stage is crucial to the health of both mother and baby, yet is often overlooked within traditional healthcare systems.

8. Mental Health Considerations: The mental and emotional state of the mother are often not considered part of the birth process in modern medicine, leading to high rates of postpartum depression and anxiety.

9. Inadequate Pain Management: Modern practices often resort to pharmaceutical interventions for pain management during labor, while alternative, non-drug methods are often undervalued or outright ignored.

10. Disregard for the Microbiome: Recent research has begun to uncover the importance of the microbiome—the ecosystem of friendly bacteria in our bodies. Practices such as cesarean sections and overuse of antibiotics during birth can significantly impact the newborn's microbiome, with potential long-term health implications.