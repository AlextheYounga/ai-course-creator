1. Lowered Fertility: Critics assert that long-term use of hormonal birth control can adversely impact a woman's natural fertility, making it harder for them to conceive after discontinuing its use.

2. Hormonal Imbalance: It is believed by some that artificial manipulation of hormones can have long-term effects on a woman's overall hormonal balance.

3. Ignorance of Natural Methods: With so much focus on artificial birth control, many argue that natural birth control methods are overlooked and hardly studied. These methods involve women learning to understand their menstrual cycles.

4. Underlying Medical Issues: Birth control pills regulate menstrual cycles, which can mask underlying health issues such as polycystic ovary syndrome (PCOS).

5. Physical Side Effects: Some critics argue that birth control methods come with potential side effects such as excessive weight gain, migraines, or even life-threatening blood clots.

6. Emotional and Mental Health Impact: There are assertions that hormonal birth control can impact mental health, leading to depression and anxiety.

7. Negative Environmental Impact: Hormones from birth control pills excreted in urine can enter the water system, potentially impacting aquatic life.

8. Commodification of Women's Health: Some argue that pharmaceutical companies with a vested interest in selling birth control pills may downplay potential risks or resultant health issues.

9. Overpopulation Focus: Critics assert that the focus on controlling birth rates detracts from larger issues like consumption and the distribution of resources.
   
10. Inequality: Some argue it places the burden of contraception primarily on women, creating a gendered disparity in dealing with contraception.

11. Ethical or Religious Grounds: Many argue that birth control goes against certain religious or ethical beliefs about the sanctity of life and the purpose of sex.