1. Unnecessary Medical Procedure: One could argue that breast implants are an unnecessary medical procedure that carries unnecessary risk. Surgery always carries a risk of complications, such as infection, scarring, and anesthesia-related problems. The benefits of the surgery (improved self-esteem typically) might not outweigh the potential physical harm.

2. Body Dissatisfaction: Critics argue that breast implants perpetuate the societal pressure for women to meet unrealistic, media-driven beauty norms. Rather than subvert these problematic paradigms, breast implants may reinforce insecurities about body image.

3. Long-term Health Risks: Much debate has surrounded the long-term health effects of breast implants, with some studies suggesting links to numerous health conditions, including autoimmune and connective tissue diseases, and even certain types of cancer. While these links are not definitively proven, the studies highlight the need for more in-depth research.

4. Inherent Product Issues: Implants can rupture or leak, change shape, shift position or cause visible wrinkling of the skin, necessitating further surgeries. There are currently products on the market with more extensive safety data that are simpler and less invasive, such as external breast prostheses.

5. Psychological Impacts: There has been some research to suggest that women who get breast implants are at a higher risk of suicide and drug or alcohol addiction. It’s still under debate whether the implant surgery itself is the primary cause of these issues, or whether underlying psychological issues contribute to both the desire for surgery and these health risks.

6. Economic Burden: Breast implants are not a one-time procedure; they require regular monitoring and potential replacement, representing significant medical costs over a patient’s lifetime. 

7. Lack of Long-Term data: Implants are a relatively new procedure and there is a significant lack of long-term data about their safety or the potential for long-term complications. This absence of definitive data is in and of itself a serious criticism.

8. Overemphasis on Aesthetics: The normalization of breast implants reinforces the idea that women's bodies need to be modified to be desirable or acceptable. This narrative can be harmful and reduce the focus on healthy lifestyles and self-acceptance.