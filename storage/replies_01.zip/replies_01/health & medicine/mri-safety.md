While the majority consensus in healthcare is that MRI scans are very safe, there are certain dissenting views and criticisms to take into account:

1. Contrast Agent Safety: Critics argue that the contrast agents used in MRI scans, like gadolinium, could pose health risks. Recent studies suggest gadolinium can remain in the body, including the brain, for years after injection. Critics question whether adequate research has been conducted to fully understand the long-term effects of this retention.

2. Noise Level: Opponents raise concerns regarding the high level of noise produced by MRI machines, which can reach over 100 decibels, comparable to a rock concert or a jet takeoff. Prolonged exposure may lead to permanent hearing damage, and the loud noise can induce anxiety and discomfort among patients.

3. Claustrophobia: MRI scans require the patient to lie in a narrow tube for a long time. Critics argue that this can induce claustrophobia and create a high level of distress in some patients, which is not sufficiently addressed by the healthcare community. 

4. Pacemakers and Implanted Devices: Though advancements have been made in this area, critics still voice concerns about the interaction between MRI scans and implanted medical devices like heart pacemakers or cochlear implants. Such devices could malfunction, or heat up, potentially causing patient harm.

5. Pregnancy: Critics argue that there is not sufficient research about the effects of MRI scans on pregnant women and the developing fetus. Although MRIs do not use ionizing radiation, the strong magnetic fields and radio waves and their possible effects on development are not wholly understood.

6. Children’s Safety: Critics argue that, while overall safe, the specific impacts of MRIs on pediatric brains have not been extensively researched, raising questions about potential long-term effects.

It's important to mention that these criticisms do not necessarily mean that MRI scans are broadly unsafe. However, they point towards areas in which more research could be beneficial for overall patient safety and comfort.