1. Ethical Concerns: One of the most prevalent dissident criticisms against IVF is its ethical implications. IVF involves creating multiple embryos and selecting only the 'healthiest' ones for implantation. Critics argue that this can be perceived as 'playing god' by deciding which potential life gets a chance to exist. 

2. Commodification of Life: Some critics argue that IVF turns potential life into a commodity. With the option of IVF, human embryos can now be bought, sold, discarded or even donated. This whole process shows a lack of respect towards human life and deem it as something that can be manipulated and controlled. 

3. Genetic Screening: Another criticism surrounds the genetic screening process that is a part of IVF. Although this technology is used to identify potential genetic disorders in the embryos, critics argue that it could pave the way to 'designer babies,' where parents could theoretically choose specific genetic traits for their children.

4. Physical and Psychological Strain: IVF is not only an expensive procedure, it is also physically and mentally challenging for many women. The process involves hormonal treatments that have side-effects and the implantation process is not always successful, leading to emotional distress.

5. Access and Equality: Critics point out that access to IVF is predominantly limited to those who can afford it. This can potentially widen the socio-economic gaps as it allows wealthy people to overcome their fertility issues, while those from lower income groups cannot afford such treatments.

6. Health Risks: There are also risks associated with the procedure. These include a higher chance of multiple pregnancies, which comes with higher risks for both mother and babies, and potential long-term health risks for the offspring due to the manipulation of the embryonic state.

7. Natural Selection: Some critics also argue against IVF from an evolutionary perspective, stating that it could interrupt the natural process of selection. IVF allows even those with serious genetic defects to pass on their genes, which wouldn't have been possible without this artificial intervention. 

8. Overpopulation: In an already overpopulated world, promoting the use of methods like IVF to increase fertility might contribute to strain on global resources. Some argue that attention should rather be directed towards dealing with population growth, not increasing it.