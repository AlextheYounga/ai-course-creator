1. Misdiagnosis and Over-diagnosis: One of the major criticisms is that Lyme disease is often misdiagnosed or over-diagnosed. Due to its wide range of symptoms that are common in many other diseases, some practitioners or patients may be quick to label their illness as Lyme Disease, leaving the true root cause undetected.

2. Duration of Treatment: The mainstream approach believes that a short course of antibiotics is sufficient to treat Lyme disease. However, some dissidents argue that this one-size-fits-all approach is not effective. They believe in the Chronic Lyme Disease theory, stating that the bacteria causing Lyme Disease can persist in the body causing long-term symptoms, requiring more intensive treatment.

3. Lack of Accurate Diagnostic Tests: Dissidents criticize the testing methods for Lyme disease, claiming they lack sensitivity and can result in a significant number of false negatives. A negative test can prevent timely treatment of Lyme Disease, which can be detrimental.

4. Denial of Co-infections: Lyme disease is usually accompanied by several co-infections caused by other ticks-borne organisms. Critics argue that mainstream medicine often overlooks these co-infections.

5. Need for Evidence-Based Medicine: Lyme disease treatment at times seems anecdotal and symptom-based rather than rooted in solid scientific evidence. Critics argue for better research and treatment protocols.

6. Preventive Methods: Many dissidents also contend that we should focus more on avoiding tick bites as a primary Lyme disease prevention strategy, rather than just emphasizing early detection and treatment.

7. Recognition of Chronic Lyme Disease: Many doctors don't accept chronic Lyme disease as a legitimate diagnosis which leads to patients with lingering symptoms of Lyme disease not being treated adequately.
  
8. Vaccine Availability: There is also criticism about the lack of a widely available vaccine for Lyme Disease in humans, making prevention difficult.

These criticisms, if confirmed, may lead to a paradigm shift in how Lyme disease is understood and treated in the mainstream health & medicine field.