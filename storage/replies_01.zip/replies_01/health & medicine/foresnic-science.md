1. Lack of Scientific Rigor: A significant criticism of forensic science is the lack of scientific rigor. Many forensic techniques, such as fingerprinting, blood spatter analysis, or bite mark comparison, have not been tested in controlled, scientific conditions and therefore can't be definitively verified, leading to potential errors and faulty assumptions.

2. Subjectivity and Bias: Interpretation of forensic evidence, especially in pattern-matching disciplines like fingerprints or bullet marks, can be subjective and prone to cognitive biases. This opens room for significant human errors and misinterpretations and raises questions about the objectivity and reliability of forensic science.

3. Lack of Standardisation: Standards for the collection, analysis, and interpretation of forensic evidence vary considerably both within and between jurisdictions. This lack of standardisation can lead to inconsistencies and, in some instances, miscarriages of justice.

4. Overreliance on DNA Evidence: Modern forensic science has a major reliance on DNA evidence, which, while highly accurate, can also be misleading or misused. DNA evidence can be easily misinterpreted, corrupted, or contaminated, and many factors can affect its quality and reliability.

5. Forensic Fraud: Instances of forensic fraud have raised serious questions about the ethics and integrity of the field. Examples include professionals falsifying results, withholding evidence, or providing inaccurate testimony, often resulting in wrongful convictions.

6. Pressure from Legal Authorities: Forensic scientists often face tremendous pressure from police or prosecutors to produce results that support their case, which can influence the outcome of the analysis and interpretation of evidence. 

7. Misunderstanding by Legal Professionals and the Public: The popularization of forensic science through media (like TV crime shows) has created a perception of infallibility, often referred to as the 'CSI Effect'. This leads to individuals, including jurors, lawyers, and even judges, potentially overestimating the infallibility and reliability of forensic science.

8. Inadequate Training and Credentials: In some cases, the expert witnesses presented in court do not have proper professional credentials or adequate training in the field of forensic science. This lack of professional standardization can lead to misinformation and wrongful convictions. 

9. Inadequate Funding and Resources: Many forensic labs are underfunded and lack the resources necessary to effectively perform their roles. This can lead to backlogs, delays, and errors. 

10. Ethical Concerns: There are several ethical issues in forensic science, such as privacy concerns (especially with regard to genetic information revealed by DNA tests), as well as issues related to the use, storage, and disposal of human tissue samples.