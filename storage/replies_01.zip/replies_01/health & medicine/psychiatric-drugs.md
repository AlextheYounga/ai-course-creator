1. Overmedication: One criticism is that psychiatric drugs are prescribed too frequently and too easily. This could potentially exacerbate the problem rather than fixing it, leading to drug dependency and a lack of addressing root causes of mental health issues.

2. Side Effects: Psychiatric drugs can also have severe side effects, varying from mild issues such as weight gain and fatigue, to more severe symptoms such as suicidal thoughts/anxiety, and even physical health problems.

3. Limited Understanding: Critics argue that the exact mechanisms of how these medications work is not fully understood, raising ethical questions about prescribing them. The general consensus is that they alter brain chemistry, but the certainty ends there.

4. Ineffectiveness: Some reports suggest that psychiatric medicines are not as effective as claimed by pharmaceutical companies. Studies have suggested that the placebo effect can account for most of the change observed in patients.

5. Profit Motive: The influence of the pharmaceutical industry is a significant point of criticism. Critics argue that the industry has a vested interest in the over-prescription of psychiatric medicines and exaggerating their effectiveness.

6. Short-Term vs. Long-Term Solutions: Psychiatric drugs are often criticized for providing short-term relief while ignoring long-term solutions. They help to manage symptoms but don't solve the underlying problem.

7. Dangers of Withdrawal: Abruptly stopping the use of psychiatric drugs can lead to withdrawal symptoms. There’s also evidence that misuse or abrupt discontinuation can lead to long-term cognitive impairment.

8. Medicalization of Normality: Critics argue that psychiatry, backed by pharmaceutical companies, is pathologizing everyday life experiences and emotions, turning them into diagnosable illnesses requiring medication.

9. Lack of Individualized Care: The usage of psychiatric drugs often fails to take into account the individual's unique biochemistry and life circumstances. Critics argue this could lead to misdiagnosis and inappropriate treatment.

10. Alternatives Overlooked: Other forms of treatment such as cognitive behavioral therapy, exercise, diet changes, and meditation that could be as or more effective than medication are often overlooked.