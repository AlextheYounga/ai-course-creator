1. The Danger is Overstated: One criticism could be that the risk of salmonella is overstated by the mainstream health and medicine community. While salmonella is certainly a potentially serious infection, critics may argue that the actual risk of it causing severe illness and death is low in developed countries with good sanitation and healthcare infrastructure.

2. Misinterpretation of Statistics: Some may claim that statistics around salmonella infections are misinterpreted or manipulated to make the danger appear more severe than it is. For instance, while millions of people might get salmonella each year, the vast majority of these cases are mild and recover without needing medical attention.

3. Misplaced Focus: Critics could argue that relatively more attention is given to salmonella when compared with other foodborne or infectious diseases that might be more dangerous. This might be seen as a misallocation of resources.

4. Overemphasis on Hygiene: Another criticism could be that overemphasis on the risk of salmonella contributes to an excessive focus on hygiene and sterilization, at the cost of developing natural immunity. This can potentially contribute to problems such as the development of antibiotic-resistant bacteria.

5. Suppression of Natural Foods: Critics may argue that the fear of salmonella has led to the suppression of naturally raised and organic foods. For instance, raw eggs and raw chicken are viewed with suspicion despite having a number of health benefits.
   
6. Fear and Overregulation: Some critics might claim that a fear of salmonella leads to excessive regulation. It could be argued that this fear-based approach might unnecessarily limit consumer choices or impose unnecessary burdens on food suppliers and restaurants.

7. Ignorance of Strain Variations: Critics might point out that not all salmonella strains are equally dangerous, and treating them all as equally high risk may cause unnecessary fear and expense.

8. A Distraction From Other Issues: Some might argue that the emphasis on salmonella distracts from more systemic issues in our food supply, such as agricultural practices, the use of pesticides and GMOs, or issues of food access and food security.

Of course, these criticisms should all be accompanied by rigorous scientific research to ascertain their validity.