1. Iron Overload: The mainstream idea is that iron is vital for health, especially for functions like carrying oxygen throughout the body. A dissident viewpoint may highlight the potential dangers of iron overload. Hemochromatosis, a condition that occurs due to absorption of too much dietary iron, can cause serious health issues like diabetes, liver disease, or heart problems.

2. Iron Supplementation: Generally, it is accepted that iron supplements can help prevent iron deficiencies. However, excessive supplementation can lead to conditions like iron overload. Moreover, some research indicates that widespread iron supplementation in countries with high rates of malaria can increase the risk of infection and death in these regions.

3. Iron and Digestive Health: Mainstream medicine usually downplays the impact of iron on digestive health. Some dissident criticism could examine how excess iron can affect a person's gut bacteria, potentially leading to imbalances and digestive disorders. 

4. Artificial Iron Enrichment: Many food products are artificially fortified with iron to prevent deficiencies. However, there is debate about the effectiveness and potential risks of this approach. Some dissident thought may argue that this method leads to overconsumption, which could compound health issues.

5. Ignoring Individual Differences: The one-size-fits-all approach to iron intake recommendations could be criticized. The accepted daily intake does not take into account individual-specific factors like age, gender, diet, and general health status.

6. Risk of Diseases: The correlation between excess iron and increased risk of diseases like cancer, neurodegenerative diseases, or infectious illnesses could also be a point of contention. Some individuals and professionals may argue that there needs to be more emphasis on these risks in mainstream discussion. 

7. Iron and Aging: Some studies imply that iron could be a factor in the aging process and lifespan regulation. This concept largely deviates from mainstream thought, yet, there's not enough research to conclude how iron could affect aging.

8. Iron and Neurological Health: There's growing evidence linking excessive iron to neurological conditions like Alzheimer's and Parkinson's. However, this has not been widely accepted or incorporated into mainstream medical discourse. A dissident viewpoint could argue for more focus on this potential risk.