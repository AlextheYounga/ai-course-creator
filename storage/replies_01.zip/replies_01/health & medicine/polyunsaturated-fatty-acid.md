1. Oversold Benefits: Critics argue that the health benefits of polyunsaturated fatty acids (PUFAs) are generally exaggerated. Some studies show no significant decrease in heart disease or lengthening of lifespan despite high PUFA consumption.

2. Omega-6 & Omega-3 Ratio: Most commercial forms of PUFAs contain a high ratio of Omega-6 to Omega-3 fatty acids, which is not in line with our evolutionary diet and could lead to inflammatory diseases.

3. Increased Risk of Cancer: Several studies have pointed to an increased risk of certain types of cancer with a high intake of PUFAs.

4. Oxidation: Polyunsaturated fats are more susceptible to oxidation which can trigger an inflammatory response in the body, potentially damaging cells and causing health issues.

5. Research Bias: The majority of studies promoting the advantages of PUFAs are industry-sponsored, leading to a potential conflict of interest and creating bias.

6. Alternative Fat Source Demonization: To promote the intake of PUFAs, other sources of fat like saturated fats have been demonized, even though recent research suggests that they are not as harmful as previously thought.

7. Role in Autoimmune Disease: There's evidence to suggest that a diet high in PUFAs may exacerbate autoimmune conditions, thereby negating their proclaimed health benefits.

8. Psychological Health Consequences: Some research suggests that higher consumption of PUFAs can contribute to neurological disorders or cognitive decline. 

9. Negative Impact on Liver Health: High intake of some types of PUFAs, notably those in vegetable and seed oils, has been linked to fatty liver disease.

10. Overloading the Diet: By encouraging high intake of PUFAs, we may be minimizing the critical importance of a balanced diet inclusive of a variety of other nutrients necessary for optimal health.