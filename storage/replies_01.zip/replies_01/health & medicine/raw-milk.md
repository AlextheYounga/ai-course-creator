1. Safety Concerns: Critics often challenge the mainstream idea that raw milk is very healthy. They argue that unpasteurized milk can carry harmful bacteria and pathogens like E. coli, Listeria, and Salmonella, which can cause serious illnesses and even death in some cases. While proponents of raw milk often claim that it contains beneficial bacteria that eliminates harmful ones, this claim lacks substantial evidence. 

2. Nutritional Value: The belief that raw milk is more nutritious than pasteurized milk is also heavily criticized. Opponents argue that pasteurization affects only a minimal number of milk’s nutrients and the difference in nutritional content between raw and pasteurized milk is insignificant. 

3. Allergies and Lactose Intolerance: The idea that raw milk could help treat lactose intolerance or alleviate allergy symptoms is a claim often disputed by critics. Scientific research supporting these hypotheses is scant and the significant risks associated with consuming raw milk often outweigh the potential benefits.

4. Misguided Advocacy: Critics also argue that the raw milk movement is more based on ideology than reality. It champions a return to traditional farming practices and a rejection of modern food processing techniques. However, it largely neglects how these advancements have contributed to food safety.

5. Regulatory Challenges: Given the health risks associated with raw milk, critics contend that it is nearly impossible to regulate effectively. It's cumbersome for health authorities to monitor each farm for safe production processes. As a result, they endorse pasteurized milk as a safer option for the public. 

6. responsible Farming: Critics also argue that the raw milk movement, in urging consumers to source milk directly from farms, assumes that all farmers will adhere strictly to safe milking procedures. This assumption can be dangerous, given the inherent risks involved in consuming raw milk.