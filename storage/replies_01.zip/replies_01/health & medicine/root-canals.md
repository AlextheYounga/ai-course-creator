1. Potential for Incomplete Bacteria Removal: The primary dissident criticism of root canals is that it may be impossible to remove all bacteria from the root canal system. Research has shown that numerous microorganisms can inhabit root canals, including bacteria and fungi, and that some may be resistant to the cleaning solutions used in root canal therapy. As a result, there might be a risk of residual infection or recurrence of infection that can lead to chronic health problems.

2. Possible Toxicity: Critics also argue that the materials used in root canals, especially gutta-percha and dental sealers, could potentially be toxic. The argument is based on individual cases where patients have shown allergic reactions to these materials. Critics suggest that these could potentially pose long-term health risks.

3. Failure Rate: Root canals have generally high success rates, but they're not 100% successful. Critics point out this fact, arguing that there are other alternatives like dental implants which have higher success rates.

4. Impact on Systemic Health: Some dissident medical practitioners subscribe to the focal infection theory, which proposes that bacteria sheltered in teeth treated with root canals can travel to other parts of the body, triggering disease. Notably, there is no substantial scientific evidence to support this theory. 

5. Pain and Discomfort: Critics argue that root canals may result in pain and discomfort both during and after the procedure, due to infection, inflammation, or nerve injury that could result from the procedure. 

6. Preservation Vs. Extraction: A potentially radical critique is that root canals are sometimes performed to save teeth that could otherwise be extracted and replaced with implants or dentures. Critics argue that this is merely a cosmetic decision and that extraction might be safer and more effective in the long run.

However, it's important to note that these criticisms stand against established scientific consensus and extensive evidence supporting root canals' effectiveness in treating decayed or infected teeth. These procedures performed by experienced endodontists have a high degree of success and low complication rates.