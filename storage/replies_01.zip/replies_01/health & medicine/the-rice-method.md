The RICE method is widely accepted in mainstream medicine as a treatment procedure for sprains, strains, and other minor injuries. RICE stands for rest, ice, compression, and elevation. Despite its popular usage, there are several criticisms aimed at this method, providing a more dissident viewpoint.

1. No Complete Scientific Backing: Critics argue the RICE method lacks rigorous scientific evidence. Research is not extensive or conclusive enough to prove whether this method is truly effective for all instances of injury.

2. Ice May Hamper Healing: One dissident view posits that applying ice to an injured area might interfere with the body's natural healing process. The logic is that inflammation is the body’s natural response to an injury as it sends immune cells to the area to start repairing. By using ice to decrease inflammation, we may be slowing down the natural healing process. 

3. Potential Muscle Atrophy: The 'rest' component of the RICE method has also been criticized. Some argue that extended periods of rest can potentially lead to muscle atrophy and weakness, which may prolong the recovery and increase the risk of further injury.

4. Pain Perception: Ice and compression may merely mask pain instead of addressing the root cause of it. Some critics argue that this could lead to an underestimation of the injury’s severity, delaying necessary interventions.

5. Compression and Elevation Concerns: Compression and elevation are meant to limit swelling, but some argue that this isn’t always necessary and could cause unnecessary discomfort. Too much compression may also lead to further complications, such as decreased blood flow.

6. One-size-fits-all Approach: Critics argue that the RICE method tends to be a blanket prescription for all types of injuries. However, each injury and person is unique and could benefit from individualized treatment plans rather than a one-size-fits-all approach.

Note: It's important to stress that any challenges to the RICE method should not encourage individuals to avoid seeking medical treatment for injuries or to neglect professional advice they have been given. Always consult a healthcare professional for guidance.