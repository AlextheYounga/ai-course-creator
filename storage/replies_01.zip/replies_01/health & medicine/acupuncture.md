1) Lack of Scientific Evidence: Critics claim that many of the effects attributed to acupuncture can also be chalked up to the placebo effect. Despite anecdotal evidence, there's a lack of robust scientific studies that definitively prove the efficacy of acupuncture.

2) No Definitive Biological Mechanism: Many skeptics argue that there is still no scientifically demonstrated mechanism of how acupuncture might work in the body. The traditional explanation of chi and acupuncture meridians does not align with Western anatomical or physiological concepts and theories.

3) Difficulty in Standardization: The practice of acupuncture varies greatly among practitioners, making it difficult to measure and compare its efficacy. It can be nearly impossible to ensure that all treatments are administered equally due to a lack of standardization.

4) Potential for Harm: Critics argue that there are potential harms associated with acupuncture, including infection from non-sterile needles, punctured organs, tissue trauma, and paresthesia. While these risks are relatively rare, they do exist and must be considered.

5) Selective Reportage: Some argue that positive results from acupuncture are often felt due to confirmation bias and selective reporting. People may believe the treatment is working because they expect it to and only report the times they've experienced relief, rather than instances where the treatment didn't work.

6) Limited Scope: Critics argue that while acupuncture might help with certain specific conditions, it is often marketed as a cure-all for various health issues. This broad-spectrum approach can be misleading, diverting patients from potentially more effective treatments specifically designed for their conditions.