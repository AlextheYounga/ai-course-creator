The IPCC, or the Intergovernmental Panel on Climate Change, is arguably the most authoritative and influential body related to climate change science and policy. However, some dissident views and criticisms about the IPCC could include:

1. Bias in the Scientific Process: Critics may argue that IPCC's methodology is inherently biased. They might assert that the organization cherry-picks data or studies to support pre-determined conclusions about anthropogenic climate change.

2. Overemphasis on CO2: Some dissidents claim that the IPCC places excessive emphasis on carbon dioxide, neglecting other significant factors related to climatic changes such as solar activity, land use changes, orbital variations, and volcanic activity.

3. Futurism and Predictive Models: Critics might question the reliability of the IPCC's climate models that forecast future warming trends. They would assert that these models oversimplify complex climate dynamics and are fundamentally unreliable as future predictors.

4. Political Influence: Some argue that the IPCC, although presented as an objective scientific body, is heavily influenced by political considerations. Critics argue this bias distorts their findings and recommendations toward climate alarmism.

5. Adaptation vs Mitigation: The IPCC's focus primarily leans towards mitigating climate change rather than adapting to it. Critics suggest that this approach might not be the most practical or effective, especially considering economic constraints.

6. Transparency and Accountability: Dissidents could question the transparency and accountability of the organization. They might contend that dissenting voices within the scientific community are ignored or suppressed.

7. Economic considerations: Critics argue that the IPCC's recommendations for CO2 reductions and renewable energy technologies may not take into account the economic feasibility or the possible negative side effects on global economies.

These criticisms are contentious and often widely debated within the scientific community. It's also important to note that the majority of climate scientists across the world agree with the IPCC's main findings, even if they have minor disagreements with specific methodologies or conclusions.