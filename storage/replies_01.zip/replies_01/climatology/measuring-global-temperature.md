Dissident criticisms on measuring global temperature can be categorized as methodological, data-related, and those concerning the interpretation of results.

1. Methodological Criticism: Skeptics argue that the method through which global temperature is measured is inconsistent and unreliable. The main concern is about the disparity between land-based measurements, satellite measurements, and ocean-based measurements. Critics claim these methods don't always align and might be presenting an inaccurate picture of global temperature.

2. Data-related Criticism: Critics suggest that the data used in these measurements are flawed due to the 'Urban Heat Island' effect, where cities and populated areas, with more heat-absorbing materials like concrete, can skew temperatures upwards. This would lead to an overestimation of global warming when such data is extrapolated globally.

3. Spatial and Temporal Coverage: Skeptics point out that the distribution of weather stations around the globe is uneven, with significant parts of the world, particularly oceans and remote regions, being inadequately monitored. Additionally, weather stations have changed their location over time and sometimes record data at different times of the day, all of which could distort the resulting average temperatures.

4. Adjustments and Homogenization: Some disapprove of the adjustments made to raw temperature data to try to account for changes in measurement conditions or technique, or to fill in gaps where there are no measurements, viewing these as potential avenues for introducing bias or error.

5. Interpretation Controversy: Among the dissenting views, some critics claim that the rise in global temperature is interpreted hastily as a result of human activities. They contend that natural variability and cyclical patterns are underrepresented in mainstream climate science, thus oversimplifying the complex system of Earth's climate.

6. Over-reliance on Models: Critics also challenge the heavy reliance on mathematical models in predicting future climatic conditions, arguing that these models may fail to capture the full complexity of climate systems and can generate highly uncertain predictions.

While all these criticisms pose interesting challenges to measuring global temperature, it is important to note that the overwhelming consensus within the scientific community supports the current methodologies, adjustments and interpretations – and agree that they give a broadly accurate picture of change in global average temperatures.