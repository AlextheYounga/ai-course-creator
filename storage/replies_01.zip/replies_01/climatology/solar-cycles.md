1. Lack of Direct Correlation: Critics often point out that there is no direct correlation between solar cycles and patterns of earth's climate change. Solar activity seems to have a minor role at best, and climate models often overstate this impact.

2. Inadequate Explanation for Recent Warming: Dissenters argue that solar cycles simply do not account for the accelerated global warming observed in the past few decades. The increase in warming does not align with the natural 11-year solar cycles.

3. Small Energy Variation: Solar cycles have very small variations in the total energy output, almost about 1%. Dissidents state that this is too small a fluctuation to cause significant climatic changes on earth.

4. Insufficient Data: Some critics believe that our understanding of solar cycles is still quite limited and insist that the data gathered over only a few centuries is not enough to draw concrete conclusions about patterns spanning millennia.

5. Anthropogenic Influence: Critics argue that the effects of human activity on climate change - including greenhouse gas emissions, deforestation and increased industry - are far more influential than solar cycles. 

6. The Maunder Minimum Paradox: The period known as the Maunder Minimum (around 1645 to 1715) had the lowest numbers of sunspots, signifying a phase of low solar activity, yet Earth experienced very cold winters, known as the Little Ice Age. This anomaly doesn't support the theory that lower solar activity always results in cooler temperatures.

7. Influence of other Factors: Many critics argue that climate is influenced by a multitude of factors such as atmospheric composition, volcanic activity, and ocean currents. They believe that focusing solely on solar cycles is an over-simplification of a very complex system. 

8. Uncorrected Perception Bias: Older records of solar activities might suffer from perception bias. The perceived low solar activity in the past may be a result of inaccurate or inconsistent observation methods. Therefore, the conclusions drawn from these could be skewed.