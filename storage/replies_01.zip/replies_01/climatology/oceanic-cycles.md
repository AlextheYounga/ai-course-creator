While oceanic cycles are widely accepted within the scientific community as key elements in our understanding of the Earth's climate system, a contrarian perspective might critique the certainty and completeness of our understanding of these complex systems, based on several points:

1. Limitations of Empirical Data: Oceanic cycles, such as the Atlantic Multidecadal Oscillation (AMO) or the El Niño-Southern Oscillation (ENSO), are understood through datasets spanning decades or centuries. For an Earth that is over 4.5 billion years old, these data samples are comparatively small. The regularity and predictability of these cycles might not hold in the longer term or under changing climate conditions.

2. Interconnectedness and Complexity: The current models largely consider oceanic cycles as isolated systems, but the reality may be more complex. Interactions between land, water, and atmospheric systems are inadequately represented in these models, leaving potential gaps in our understanding. 

3. Influence of Climate Change: With human-induced global warming, old patterns may not hold as the increased heat added into the climate system could potentially disrupt or alter these oceanic cycles. Predictions based on historical behavior might become unreliable.

4. Lack of Consensus: There's little consensus on some aspects of oceanic cycles among climatologists. For example, the existence, definition and effects of the Pacific Decadal Oscillation (PDO) remain areas of contention. 

5. Dependence of Society and Infrastructure Planning: Many societal plans and infrastructure designs rely on the predictions made about oceanic cycles. If our understanding of these cycles is mistaken or incomplete, the consequences could be significant.

6. Shadows Unknown Phenomena: By focusing largely on known oceanic cycles, scientists may neglect unexplained phenomena or patterns that don't fit neatly within the expected scheme. This may lead to a bias in research and a potential oversight of other significant climatic factors.

Remember, while these criticisms hold some validity, they don't invalidate the concept of oceanic cycles outright. They are considerations that can help refine our understanding and lead to improved modeling of Earth's climate system.