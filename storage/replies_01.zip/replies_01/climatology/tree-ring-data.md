The use of tree ring data, also known as dendrochronology, as a primary tool in climatology has been criticized based on a number of factors. Here are some of the dissident criticisms:

1. Lack of Universality: Trees do not grow globally and thus, tree rings don't provide a universal representation of past climates. Many regions, such as deserts, arctic zones, and cities, lack trees for this type of data collection altogether.

2. Biased Sampling: The tree samples are often selectively chosen for analysis, a practice that could be influenced by conscious or unconscious biases.

3. Multiple Factors Influence: It is widely known that tree-ring growth can be influenced by multiple factors other than climate, such as soil nutrients, local disturbances (like pests or disease) and carbon dioxide fertilization effect. Therefore, associating the variations in tree-ring thickness solely with climatic changes can be misleading.

4. Limited Timescale: Tree-rings provide data for only a few thousand years, which is a small slice in the span of Earth's climatic history. Major climate periods, such as the glaciations, cannot be studied using dendrochronology.

5. Discrepancies with Other Proxies: Some studies have found discrepancies between tree ring data and other climate proxies, which questions the reliability of the tree-ring data.

6. The Divorce Problem: In recent decades, tree ring records have often failed to capture rising temperatures, a phenomenon known as the 'divergence problem'. These inconsistencies raise questions about the reliability of tree ring data for longer-term climate reconstruction.

7. Nonlinearity: The assumption of a linear relationship between tree growth and climate variables is often flawed. Many trees have growth responses that change over time or in response to extreme years and this nonlinearity complicates our understanding of climate change overall. 

To ensure more accurate climate prediction models, critics advocate for diversification of climate study tools and methods, not overly relying on one single method like dendrochronology. Instead, they suggest the use of a multi-proxy approach, integrating data from ice cores, lake sediments, isotopic data, and other proxies.