Cosmic Background Radiation (CBR), specifically the Cosmic Microwave Background (CMB) radiation, is the afterglow of the Big Bang that permeates the universe. It's often used as evidence for the Big Bang theory and the expansion of the universe. However, there are some dissident views and criticisms:

1. Alternative Explanations: Some critics argue that other possibilities may explain the CMB. For example, plasma cosmology, a non-standard cosmology whose central postulate is that the dynamics of ionized gases and plasmas play important, if not dominant roles in the physics of the universe. Supporters of this theory suggest that so-called "background" radiation is not from the Big Bang, but from other, more localized cosmic phenomena.

2. Fine-Tuning Problem: The CMB is often cited as evidence for "fine-tuning" in the universe — the idea that certain conditions were set exactly right for life to exist. Critics argue that this reasoning is circular, assuming its conclusion and misinterpreting high improbabilities.

3. Anisotropy Issues: Some dissidents highlight the problem of non-uniformity, or "anisotropy," in the CMB. The relative uniformity of the CMB is a core prediction of the Big Bang theory. However, as we gather more precise data from probes like WMAP and Planck, we observe tiny temperature fluctuations. Critics argue these inconsistencies cast doubt on the standard cosmological model.

4. Lack of Direct Evidence: Some dissidents criticize that the CMB is not a direct observation, instead, it's the interpretation of observed microwave radiation. There could be other interpretations for these observations that don't necessarily support the Big Bang paradigm.

5. Predictions of Quantized Redshifts: Halton Arp's theory of ejections from existing galaxies causes redshifts quantized in units of c * Hubble constant. That would locate many objects inside the 'Sphere of Influence', scattering the CMB, raising its temperature and distorting its blackbody spectrum. 

6. Data Manipulation: A bold criticism is the claim of data manipulation or dismissal of inconvenient data from analyses of the Cosmic Microwave Background - highlighting the alleged 'Axis of Evil'.

These criticisms mostly emerge from the fringes of the scientific community. It's worth noting that the consistency of the Big Bang model with a wide range of observational data makes it the best explanation most scientists have for the origins and large-scale structures of the universe. 

However, it remains essential for scientific progress to consider diverse perspectives and to constantly test the existing mainstream paradigms.