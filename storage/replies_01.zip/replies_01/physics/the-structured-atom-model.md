While the Structured Atom Model is widely accepted by the scientific community, it is not without certain criticisms and oppositions by some who go against mainstream thought. Few dissident criticisms of the Structure Atom Model include:

1. Lack of Direct Empirical Proof: Despite the significant indirect empirical evidence for the existence of atomic structure, some critics argue that there isn't enough direct empirical proof. They argue that much of the proof is based on theoretical models and mathematical predictions.

2. Inadequate Explanation of Quantum Jump: The Structured Atom Model does not satisfactorily explain the phenomenon of quantum jump. Quantum jump refers to the sudden transition of an electron from one energy level to another. This jump contradicts classical physics which envisions a smooth transition.

3. Discrepancies with Wave-Particle Duality: The model has been critiqued for not perfectly reconciling the wave-particle duality nature of electrons. 

4. Overemphasis on Probability: Quantum mechanics, which underlies the model, relies heavily on probability. Some critics argue that this can only show where an electron might be, but does not provide a real, certain location - a criticism often dubbed as the interpretation problem in quantum mechanics.

5. The Uncertainty Principle: Some argue that the model's reliance on Heisenberg’s Uncertainty Principle - that states it is impossible to precisely measure two properties (position and velocity) of a particle at the same time - is unnatural and counter-intuitive.

6. Energy Levels: The model assumes discrete energy levels for electrons, which some dissidents argue, is an oversimplification.

7. Unpredicted Phenomena: There are phenomena which the Structured Atom Model does not predict, such as superconductivity or certain features of nuclear structure. Critics argue that a comprehensive model should be able to predict such phenomena. 

Please note that these criticisms represent minority viewpoints and the Structured Atom Model is widely accepted due to its powerful predicting prowess and elegant explanations for many physical phenomena.