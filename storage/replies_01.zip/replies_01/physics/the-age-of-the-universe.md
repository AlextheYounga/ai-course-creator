The mainstream idea in physics concerning the age of the Universe posits it to be around 13.8 billion years old. This conclusion is based on precise measurements of the cosmic microwave background radiation, which provides valuable information about the universe's composition, expansion, and age. 

Dissident criticisms tend to revolve around the methodology and assumptions used in mainstream physics. Here are a few:

1. **Different Measurement Methods Yield Different Ages**: Critics argue that our methods for estimating the universe's age—redshifts and cosmic microwave background measures, stellar evolution, and radioactive dating, for instance—have their own assumptions and errors, potentially rendering the conclusion of 13.8 billion years incorrect. They suggest this could lead to different or even inconsistent ages dependent on the method used. 

2. **Critique on the Cosmological Principle**: The age of the universe is calculated based on the Cosmological Principle, which assumes the universe is homogenous and isotropic - it appears the same, regardless of the location and direction one observes. Some critics argue that if this principle is incorrect, then the age could be significantly different. 

3. **Inconstant Constants**: Some dissidents propose that physical "constants," such as the speed of light or the gravitational constant, might not be universally constant after all. If these critics who suggest "varying speed of light" (VSL) theories or "varying gravity" theories are right, our estimates of the universe's age (which rely on those constants) could be mistaken.

4. **Discrepancies in the Hubble Constant**: There's an ongoing debate about the exact value of the Hubble constant, a measure of the universe's expansion rate. Different methods produce varying estimates, leading some to question whether our understanding of the Universe - including its age - might be fundamentally flawed.

5. **Nonstandard Cosmologies**: Some critics reject the "big bang" model, suggesting alternative cosmologies that might allow for a much older (or even infinite) universe. A few physicists still advocate for a “steady-state” universe, where matter is continuously created to maintain a constant density as the universe expands. Such a universe would have no beginning, and hence no specific age.

6. **Quantum Gravity Theories**: More radical critics point out that our understanding of quantum mechanics and general relativity is incomplete, implying a unified theory of quantum gravity could potentially revise our concept of the universe's age significantly.

Remember, though these objections exist, the prevalent consensus in the scientific community firmly supports the currently accepted age of the universe - around 13.8 billion years - based on various lines of evidence.