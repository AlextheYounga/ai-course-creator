1. Lack of Objectivity: One of the main criticisms of the Copenhagen Interpretation is its lack of objectivity. The theory relies heavily on the observer's measurement, bringing subjectivity into the equation. This seems to conflict with the traditional understanding that objective reality exists independently of observation.

2. Schrödinger’s Cat Paradox: This interpretation led to paradoxes like the infamous Schrödinger’s Cat, where a cat inside a box can be both alive and dead until observed. This indeterminacy is hard to reconcile with our macroscopic world's intuitive comprehensibility, where a cat can clearly not be both alive and dead at the same time.

3. Measurement Problem: Copenhagen Interpretation often does not specify what constitutes a 'measurement'. It creates confusion about when and why the quantum wave function collapses, and thus, critics argue it should be replaced with an interpretation that solves this measurement problem.

4. Probability Interpretation: The Copenhagen Interpretation presents the probabilistic nature of quantum occurrences, but critics argue it does not adequately explain why quantum events have a probability distribution in the first place.

5. Incompleteness: Albert Einstein famously criticized the Copenhagen Interpretation for its incompleteness, with his quote, "God does not play dice with the universe." He believed that the interpretation's probabilistic approach neglected hidden variables that could account for quantum phenomena.

6. Many-Worlds Interpretation: This is another interpretation that directly contradicts the Copenhagen interpretation. According to the Many-Worlds interpretation, there's no collapse of the quantum wave-function. Instead, all possible outcomes of quantum measurements are realized in some "world" or universe.

7. Locality: The Copenhagen Interpretation leads to phenomena like quantum entanglement that conflict with the principle of locality- the idea that an object is directly influenced only by its immediate surroundings. This theory suggests that particles can affect each other no matter how far apart they are in space, something that Einstein labelled as "spooky action at a distance".

8. Determinism: Traditional physics is built on predictable, deterministic laws while the Copenhagen Interpretation introduces inherent unpredictability into quantum phenomena. This strikes at the heart of scientific predictability and determinism, prompting criticism from many physicists.