1. Lack of Direct Detection: Scientists have yet to directly identify or observe dark matter. Dissident critics argue that this lack of evidence lends itself to skepticism and that the existence of dark matter is only inferred from its gravitational effects.

2. Alternative Gravitational Theories: Critics propose that the phenomena attributed to dark matter could be the result of misunderstandings or errors in our understanding of gravity. One such theory is Modified Newtonian Dynamics (MOND), which proposes that Newton's laws of gravity don't apply in the same way at larger, galactic scales.

3. Quantum Physics Discrepancies: Standard quantum physics models do not predict the existence of dark matter. Critics contend that this discordance between the most significant theories of physics is evidence against the existence of dark matter.

4. Lack of Consistency in Observations: Some critics argue that inconsistencies in dark matter observations imply it is not real. For instance, some galaxies appear to have little or no dark matter, which goes against the widely accepted theory that dark matter is essential for galaxy formation.

5. The No-Hair Theorem Conflict: Critics also mention the no-hair theorem of black holes, which states that black holes can be completely described by their mass, charge, and angular momentum, with no reference to dark matter. 

6. Complexity of Dark Matter Models: It's often suggested that so-called 'dark matter particles' require a lot of assumptions and high complexity in their models, which goes against the principle of parsimony or "Ockham's Razor," a principle that favors simpler theories. Critics argue that simpler explanations, which do not require the introduction of an entirely new and undetectable type of matter, should be sought for galactic behavior.

7. Lack of Consensus on its Nature: Dark matter may refer to a broad class of matter types, including brown dwarfs, neutrinos, or hypothetical entities like WIMPs, MACHOs, and axions. The lack of consensus about what constitutes dark matter raises doubts about its existence for some critics. 

8. Lacking Explanation for 'Dark Flow': Large portions of the Universe seem to be moving in a common direction, a phenomena termed 'dark flow’. Critics assert that if dark matter is uniformly distributed throughout the universe, it should not allow for this sort of collective movement. 

9. Biases in the Observations: Critics argue that researchers may suffer observational and confirmation biases by interpreting data to be supportive of dark matter rather than considering alternative interpretations.

Note: While there exist criticisms and alternative theories to propose, the majority of the scientific community supports the existence of dark matter due to observational and mathematical evidence. The consensus is that it remains the best available theory to explain certain large-scale universal phenomena.