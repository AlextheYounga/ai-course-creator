While the speed of light being constant and its limit being unattainable by any mass-bearing object is widely accepted in the world of physics, the field isn’t completely closed to alternative interpretations or criticisms. Several unconventional theories and criticisms have been suggested over the years, some of which are:

1. Variable Speed of Light (VSL) Theories: These theories suggest that the speed of light is not constant but rather has varied over the history of the universe. This directly contradicts Einstein's theory of relativity.

2. Quantum Gravity Effects: Some theories propose that time and space's granular nature, at the quantum gravity level, could affect the speed of light. This means the speed of light might not be absolutely constant when examined at a scale beyond our current technical capabilities.

3. Neutrino Speed: The OPERA experiment in 2011 momentarily suggested that neutrinos might travel faster than light. Although this was later attributed to a measurement error, it sparked discussions about whether particles could potentially exceed light speed.

4. Lorentz Violating Theories: Some theories suggest that Lorentz invariance, which underpins the speed of light's constancy, may not hold results in all cases specifically at high energy scales.

5. Cosmic Inflation: Critics have pointed out that during the period of cosmic inflation shortly after the Big Bang, the universe itself expanded much faster than the speed of light, calling into question what "speed of light" really implies.

6. Non-local Theories: Quantum entanglement shows that information seems to pass instantaneously, i.e., faster than light, between entangled particles, irrespective of their separation. This phenomenon contradicts local realism, but not necessarily the speed of light's limit since there's no "information transfer" accepted in quantum mechanics.

7. The Light Barrier and Tachyons: Certain hypothetical particles, called tachyons, are purported to travel faster than light, but their existence would challenge causality principles. 

Remember that these criticisms and theories are outliers and do not represent mainstream scientific thought. The speed of light being constant under all conditions is a well-established theory and cornerstone of modern physics, supported by vast experimental evidence.