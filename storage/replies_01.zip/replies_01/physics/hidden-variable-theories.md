Hidden variable theories in physics are those that propose the existence of certain underlying "variables" or attributes that the current quantum mechanical framework can't identify, but they can explain the randomness and indeterminacy observed in quantum systems. Although these theories have been supported by some physicists, several criticisms are raised by dissident opinions. Here are some of them:

1. Nonlocality: According to Bell's theorem, any hidden variable theory that agrees with quantum mechanics must allow for nonlocal influences. These are influences that could instantaneously affect distant systems, violating the principle of locality or Einstein's special theory of relativity, which states that nothing can interact faster than the speed of light.

2. Determinism vs. Quantum Indeterminacy: Quantum mechanics relies on a principle called quantum indeterminacy or the Heisenberg Uncertainty Principle, which posits that it's impossible to simultaneously measure the precise position and momentum of a particle. Hidden variable theories, on the contrary, often tend to be deterministic and thus contradict the fundamental principles of quantum mechanics.

3. Inadequate Experimental Support: While hidden variables are posited to explain certain quantum behaviors, there is not enough experimental evidence to support their existence. Often the results of experiments, such as the famous double-slit experiment, firmly align with the traditional interpretations of quantum mechanics.

4. Complexity: Hidden variable theories tend to be more complicated and less parsimonious than quantum mechanics. Where quantum mechanics can explain phenomena with a certain degree of mathematical simplicity, hidden variable theories would require complex additional structures.

5. Definition and Measurement: There is a lack of clear definition and measurable criteria for hidden variables. The theories often fail to explain how these variables would be detected or measured, which makes them less empirically verifiable.

6. Quantum Entanglement: One of the most puzzling aspects of quantum mechanics is the phenomenon known as entanglement, where particles become linked and the state of one can instantaneously affect the other no matter the distance between them. Hidden variable theories struggle to explain this without violating Einstein's relativity.

While these criticisms contribute to viewpoints on hidden variable theories, it's crucial to remember that these theories are part of an ongoing debate in the physics community and reflect our still incomplete understanding of the quantum world.