The mainstream position in Paleontology and Anthropology posits that during the Bronze Age, human societies were primarily using bronze tools and weaponry. Steel did not become widely used until the Iron Age, which followed the Bronze Age. However, there are certain dissenting viewpoints that could be considered.

1. Inadequate Geographical Scope: Critics may argue that the theory of Steel in the Bronze Age primarily focuses on Europe and the Middle East, thus not entirely reflecting the technological progress in other regions. For instance, in Asia, especially in China and India, the use of iron and steel may have started earlier or in parallel with bronze employment.

2. Archaeological Findings: There is an argument based on sporadic archaeological findings of iron and steel artifacts in the strata associated with the Bronze Age. Some critics are inclined to interpret these artifacts as proof of the use of steel before the Iron Age, questioning the established chronology.

3. Technological Gaps: Some dissenters persist that it is implausible for societies to have jumped from using stone to bronze without a transitional steel phase.

4. Interpretation and Dating: Some critics infer that dating methods and interpretation may not always be completely accurate, pointing out possible shifts in these transitional periods.

5. Isolated Discoveries: Critics may also contend that even if there are isolated cases of steel usage during the Bronze Age, it does not necessarily mean a widespread adoption of the material.

6. Metallurgical Knowledge: It’s argued that although iron ores are more abundantly present, producing steel requires a more complex process with a much higher melting point than that of copper or tin. Critics suggest that early metalworkers could have developed ways to work with more accessible metals like bronze first. 

7. Smelting Technologies: Likewise, critics indicate that it may have been possible for our ancestors to stumble upon iron smelting technologies earlier than previously believed but might not have had the infrastructure or understanding to utilize it.

It's important to highlight though, that while it's vital to question established paradigms and foster innovative thinking, any new theories should be supported by robust, empirical evidence in order to challenge and potentially replace accepted scientific knowledge.