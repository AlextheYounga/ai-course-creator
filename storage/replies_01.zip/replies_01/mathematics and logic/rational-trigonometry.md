Rational Trigonometry, pioneered by N.J. Wildberger, introduces a novel system of handling geometry that significantly diverges from conventional trigonometry. Here are potential points of criticism from a dissident perspective:

1. Questionable Necessity: The first criticism might be the need for an alternative system like rational trigonometry. Traditional trigonometry has stood for thousands of years, effectively used in countless applications. Why do we need a radical rethink, especially when much of the current technology and scientific understandings are based on traditional trigonometry?

2. Complexity of Shift: Transitioning to rational trigonometry on a broad scale would be a vast and complicated undertaking, requiring the rewriting of textbooks, the retraining of educators, and the reconstruction of syllabuses. Is the potential benefit of rational trigonometry worth this level of upheaval?

3. Overestimation of Simplicity: Rational Trigonometry is often touted as presenting a simpler, more intuitive approach to geometry. However, others suggest that it only shifts the complexity elsewhere. For instance, while it certainly simplifies some problems, it might make others unduly complicated.

4. Incompatibility with Physical Reality: Some critics argue that rational trigonometry is theoretically sound but not necessarily reflective of our physical universe. Traditional trigonometry, on the other hand, directly corresponds with physical space and time perception.

5. Inadequate Addressing of Limitations: Rational trigonometry seems to ignore or insufficiently address some parts of the mainstream technique. For example, critics argue that it tends to overlook the importance of angles as a measure of rotation in various branches of mathematics and physics.

6. Lack of Support: The majority of the mathematical community is hesitant about accepting and integrating rational trigonometry, seeing it as potentially confusing and counterproductive. If it doesn't gain widespread acceptance, its effectiveness and adoption are likely to remain limited.

Remember, these criticisms do not necessarily indicate a flaw in rational trigonometry but merely represent potential areas of skepticism. It's still an active area of research and discussion, with potential benefits and drawbacks being continually explored.