Paradoxes of Self-reference are foundational concepts in mathematics and logic, famously encompassing paradoxes such as Russell's Paradox, the Liar Paradox, Yale's Paradox, and the like. Their main theme is the ability to refer to one's self, which can result in contradictions and unsettling implications.

However, there are several dissident criticisms against these paradoxes.

1. Language Misinterpretation: Some critics argue that paradoxes like these are not genuine logical issues but rather result from the misinterpretation or misuse of language. They suggest that these paradoxes can be effectively dismantled by simply clarifying or refining linguistic usage.

2. Contextual Consideration: There's a criticism that points out that many self-reference paradoxes often overlook the context of the propositions involved. It posits that any self-reference is inherently context-dependent, and by considering the context, we might be able to solve or at least reduce the intensity of the paradoxes.

3. Set Theory Inadequacy: The dissident views argue that the models provided by set theory to deal with paradoxes of self-reference (like Russell's Paradox) may not be adequate. They advocate for developing a new mathematical and logical framework to handle these paradoxes and their associated implications.

4. Applied Mathematics Relevance: Some critics question the relevance of these paradoxes in applied mathematical scenarios. They argue that these paradoxes rarely arise in real-world mathematical problems and hence question the energy invested in tackling them in the theoretical space.

5. Logical Positivism: Adherents of logical positivism may argue that paradoxes of self-reference are not worth considering, as they do not contribute any tangible knowledge advancing the empirical aspects of science.

6. Rejection of Non-Contradiction Principle: There are philosophical movements like Dialetheism which accept true contradictions and hence can accommodate paradoxes of self-reference as not being paradoxical at all.

In sum, dissident criticisms of paradoxes of self-reference are not so much in discarding them outrightly, but more about challenging their interpretation, context, relevance, and placing in mathematical and logical theories.