Set theory, which is the mathematical study of collections of objects, has been the foundation of mathematics for over a century. However, it is not without its critics and like any theoretical framework, it can be challenged from several angles. Here are some dissident criticisms of set theory:

1. Logical Paradoxes and Inconsistencies: Some critics observe that set theory leads to logical paradoxes and inconsistencies. The classic example is Russell's Paradox, which poses the question of whether the set of all sets that do not contain themselves contains itself.

2. Platonistic Nature: Critics argue that set theory is too Platonistic in nature. Its notion of abstract objects can be seen as too far removed from the physical world and concrete mathematics, making it an impractical basis for mathematical practice.

3. Lack of Intuitiveness: The abstract nature of set theory is believed by some to be non-intuitive and difficult to grasp. The elements do not exist in a directly observable or tangible form, making it hard for some to truly understand or apply.

4. Unnecessary Complexity: Critics point out that concepts in set theory like infinity, and infinities of different sizes, add unnecessary complexity to mathematics. They argue that these ideas are not needed for most parts of mathematics and promote a simpler, finite mathematics.

5. Alternative Approaches: Some critics don't reject set theory outright, but propose alternative paradigms, arguing that set theory is too dominant and stifles other perspectives. These alternatives include category theory, which focuses more on relationships between mathematical objects; type theory, which stresses the categorization of objects by their properties; and constructive mathematics, which rejects abstract objects that can't be explicitly constructed.

6. Non-Standard Analysis: There is a critique that set theory does not allow for the analysis of "infinitesimals" or infinitely small quantities. This led to the rise of non-standard analysis, which introduces a new number system including infinitesimals.

7. Critics also argue that set theory's axiomatic approach (based on assumptions) leaves no room for evolving mathematical understanding, making it rigid and unyielding.

These criticisms do not deny the importance or usefulness of set theory, but they highlight areas of potential debate and discussion in the philosophy and practice of mathematics.