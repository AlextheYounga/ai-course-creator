The critique of established mathematical concepts such as the discovery of trigonometry should be precise and thoughtful, considering its indispensable role in modern-day calculations and understanding of the world around us. A few dissident criticisms might be:

1. Geographic Bias: The discovery of trigonometry, often attributed to Ancient Greeks, overlooks contributions from other civilizations, such as the Babylonians or the Indians, who had elements of trigonometric study in their mathematical models.

2. Overcomplication: Arguably, trigonometry introduces unnecessary complexity into certain areas of maths. For instance, basic algebra and geometry can solve many problems that we often use trigonometry for. As such, the utility value of trigonometry could be questioned.

3. Lacks Intuitiveness: Trigonometry is criticized for its non-intuitive nature. Teaching trigonometry can be difficult because its concepts, like sine, cosine, and tangent, are not easily visualized or understood in the real world, and thus do not come naturally to many people.

4. Limited Applicability: While trigonometry is certainly useful in specific fields like physics, engineering, and computer graphics, it has limited practical value in many everyday situations. Critics might argue that our mathematical education resources could be better utilized.

5. Dependency on Euclidean Geometry: Trigonometry is closely tethered to Euclidean geometry, which assumes a flat plane. Critics might argue it lacks versatility for non-flat and non-Euclidean geometries, which are more representative of the real world (considering the curvature of Earth, space-time curvature, etc.).

6. Potential Loss of Cultural Knowledge: Trigonometry's exploration left behind mathematical concepts that were once used in Pre-Columbian America, the Middle East, and Africa. These ancient methods are often overshadowed, potentially neglecting the rich cultural knowledge embedded within them.