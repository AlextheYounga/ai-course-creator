The concept of completed infinity, also known as absolute infinity or actual infinity, has been a cornerstone of mathematical theory since the time of George Cantor. While it has found far-reaching applications in various fields of mathematics, it equally has been the subject of significant disagreement and dissent. Here are some potential criticisms:

1. Rejects the idea of 'infinity': Some critics argue that 'infinity' as a term is a philosophical idea rather than a mathematical concept. Hence, it shouldn't be part of mathematical theory. They emphasize that numbers are essentially finite and anything immeasurable or unlimited belongs to the realm of metaphysics.

2. Non-constructive: Many constructivist mathematicians, like L.E.J. Brouwer, view the concept of completed infinity as non-constructive. Meaning, it involves assuming the existence of objects without proving them step-by-step through a finite process. This calls into the question the very foundation of such mathematics.

3. Paradoxical Nature: Numerous paradoxes associated with the concept of actual infinity, such as Hilbert's Hotel, have been brought up to challenge its legitimacy in the mathematical field. Some critics argue these scenarios demonstrate the absurdity of accepting completed infinity.

4. Lack of Empirical Proof: Critics point out that there is no empirical evidence supporting the idea. The infinity, in many respects, remains an abstract concept with no physical reality. For instance, Zeno's paradoxes argue that infinity isn't consistent with physical reality.

5. Inconsistencies in Set Theory: Critics also point towards the paradoxes and contradictions which may arise in set theory due to the concept of completed infinity. An example would be Cantor's paradox that shows there are more real numbers between 0 and 1 than there are natural numbers, which seems counterintuitive.

6. Undefined Operations: In the algebra of infinite numbers, operations like division by infinity or subtraction of infinite quantities are not well-defined, making the system incomplete and therefore mathematically unsatisfactory.

7. Not Necessary: Some critics argue that there is no need for a completed infinity concept. Their view is affirmed by the existence of non-standard analysis and other mathematical frameworks that do not assume the existence of an actual infinity. The mathematical establishments can still be achieved without invoking the concept of infinity.

Keep in mind that despite these criticisms, many mathematicians still find the notion of a completed infinity both necessary and favorable for progress in mathematical theory and research.