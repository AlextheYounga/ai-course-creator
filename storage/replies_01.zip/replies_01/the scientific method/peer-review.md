1. Lack of Objectivity: Critics argue that peer review may be marred by bias, both on the part of the reviewers and the authors. Prejudice related to gender, affiliation, subject preference, or personal rivalry could negatively influence a reviewer's assessment. 

2. Openness to Innovation: Peer review can often function as a gatekeeper that restricts truly revolutionary ideas from gaining exposure. Reviewers grounded in traditional knowledge and approaches might reject innovative concepts they don't understand or that contradict established theories.

3. Inconsistency: Different reviewers often have differing opinions on the same work, which can lead to inconsistent outcomes depending on who reviews the paper. This issue raises concerns about the reliability of the process.

4. Limited Accountablity: There is often little to no accountability for reviewers who abuse the system. Reviewers who delay reports, provide negligent reviews, or use their position for self-promotion often face no repercussions.

5. Lack of Transparency: Peer review process is generally confidential, making it opaque to outsiders. Critics assert that this lack of transparency can hide potential bias or misconduct.

6. Time-consuming: Peer review can slow down the publication process, potentially delaying the dissemination of vital research findings. In fast-paced research areas, this can impede scientific progress.

7. Not Comprehensive: Peer review isn't foolproof and can often fail to detect errors or fraud. Case studies show that several studies with fabricated or flawed data were approved by peer review, raising questions about its effectiveness.

8. Limited Representativeness: Peer reviewers ideally should represent a broad cross-section of relevant expertise, but this isn’t always the case. Specialists in a niche area of study may not comprise the reviewer pool, which could compromise the quality of the review.

9. Economic Inefficiency: Unpaid peer reviewing and the administrative costs associated with managing the process can be viewed as economically inefficient. The system may rely excessively on unremunerated work by academics.

10. Publication Bias: Studies with positive results are more likely to be accepted, which can lead to a trend known as "publication bias". Peer review could indirectly contribute to this issue if reviewers show a bias towards more 'exciting' positive findings. 

It’s worth noting these criticisms do not diminish the considerable benefits of peer review in ensuring rigorous scientific discussion, but they do however highlight potential areas for improvement to adapt to evolving research needs.