1. Placebo Effects Are Overrated: This assertion questions the idea that placebo effects are responsible for as significant an amount of therapeutic outcomes as some studies suggest.

2. Lack of Standardization: Critics argue that placebo effects can be misleading due to the absence of a universal methodology on how they should be harnessed, measured, or interpreted.

3. Undervaluing Healing Power: Some critics believe that attributing improvements to the placebo effect undervalues the natural healing power of the human body, attributing it to false causes.

4. Ethical Questions: Placebos inherently involve a level of deception that some critics argue is fundamentally unethical for practitioners, regardless of the therapeutic outcomes.

5. Unscientific Foundation: Critics argue that though the placebo effect is widely referenced in science, it's based on something essentially unscientific, as it relies on belief - a subjective, immeasurable factor.

6. The Nocebo Effect: This argues that negative expectations can lead to worse health outcomes, illustrating that mindset can dictate health in ways beyond positive 'placebo' effects.

7. Replication Failure: Some critics point out that studies demonstrating a strong placebo effect are often difficult to replicate, questioning the validity of these results.

8. Over-Emphasis on Psychology: Critics often highlight the heavy psychological component of the placebo effect, arguing that it detracts from the physiological factors that also play a significant role in health.

9. Disparities in Effect: Critics note the varying effects of placebos across different diseases and populations, undermining the notion that the placebo effect is a universally valid concept.

10. Potential for Misuse: Some caution that an over-reliance on the placebo effect can lead to the limitation of research into actual, effective treatments, or could be used to justify ineffective treatments.