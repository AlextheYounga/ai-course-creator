1. Applicability: Critics have argued that not everything that is credible can be proven false or has the potential to be proven false. Some theories may not have observable evidence that would result in their falsification. Moreover, some concepts, particularly in the field of human sciences like psychology or sociology, are subjective and cannot be definitively proven right or wrong.

2. Purposeful Rejection: Falsifiability can be too simplistic. It often fails to take into account religious, philosophical, ethical, and cultural beliefs that don't adhere to the method's strict measures. Hence, depending upon the context, falsifiability may reject some valuable insights.

3. Ethical Limits: Falsifiability can lead to testing morally or ethically controversial ideas, and this has led to questions about its applicability. This can be seen with testing on animals, for instance.

4. Induction Problem: Critics also argue that falsifiability fails to solve the problem of induction, which states that no amount of empirical data can definitively prove a theory without a shadow of a doubt. A theory might pass all falsification tests at one point, but later evidence could still render it incorrect.

5. Inter-dependence of Theories: Many theories in science are interdependent. The falsification of one may consequently lead to the collapse of many others, which complicates the process of falsification.

6. Absoluteness: Falsifiability prescribes that a theory should be completely discarded if falsified. Critics argue that this is too rigid as some theories can still provide valuable albeit imperfect representations of reality.

7. Practicality: In some cases, falsification might need resources (like time, effort, technology) which might not be practically available. This restricts its applicability by making it an idealistic approach rather than a pragmatic one.

8. Relativity to Evidence: Falsifiability is criticized for its heavy reliance on empirical data and physical evidence. Many argue that more abstract and theoretical concepts that do not have immediate or directly observable evidence but have implicit implications should not be relegated behind.

9. Falsifiability Bias: The focus on proving things wrong may create a bias against the exploration of new, untested, or unconventional theories and ideas. This conservative approach might hinder scientific advancement. 

10. Universality Assumption: Falsifiability assumes that what holds true in one context will apply universally. However, this is not always the case, especially in more complex or nuanced fields of study.