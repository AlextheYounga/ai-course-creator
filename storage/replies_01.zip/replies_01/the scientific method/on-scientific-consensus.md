1. Stifling of Innovation: One criticism is that the concept of "scientific consensus" can discourage revolutionary ideas and limit scientific progress. Consensus can lead to a rejection of new or radical theories that conflict with established thoughts, even though these theories might prove to be correct when carefully examined.

2. Suppression of Dissent: Scientific consensus can be used as a means of silencing and ostracizing those who hold divergent views, even when they have valid criticisms or alternative hypotheses. This can lead to a monolithic scientific community, where diversity of thought, essential for growth and innovation, is punished.

3. Misuse for Political or Ideological Gain: There is a risk that scientific consensus can be misconstrued or exploited for political or ideological gain. This can result in misinformation and potentially harmful public policies.

4. Mistaken Consensus: The history of science documents numerous times when scientific consensus was wrong, such as the geocentric model of the universe. This suggests that a consensus at any given time might change in the future as new evidence or perspectives come to light.

5. Risk of Groupthink: The pressure to conform and the desire for cohesion within the scientific community can lead to groupthink, where consensus is reached without critical analysis of alternative viewpoints.

6. Dependence on Limited Evidence: In many cases, a scientific consensus arises from the available evidence at a certain point in time. It doesn't necessarily mean that consensus is correct but rather recognizes the best conclusion based on current evidence. In the future, new information might challenge the consensus.

7. Disallows Public Skepticism: Another criticism argues that scientific consensus can discount the importance of healthy skepticism and open debate in science. It can create an aura of infallibility, leaving no space for public discourse, which is crucial for democratic societies.

8. Potential for Bias and Corruption: It is possible that scientific consensus can be influenced by vested interests or corrupt practices, leading to skewed results and misleading conclusions. 

Remember, the goal is not to reject scientific consensus but to recognize potential pitfalls and ensure that it is based on rigorous, transparent analysis and critical discussion, and remains open to re-evaluation in the light of new evidence.