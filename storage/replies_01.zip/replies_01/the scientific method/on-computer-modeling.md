1. Oversimplification: One criticism on computer modeling is that it can oversimplify the complexities of the natural world. The real world is multi-layered and deeply interconnected, with numerous variables that are often hard to identify, measure, or simulate. Despite the advances in computer technology, there are still limitations to the model's ability to accurately represent the intricate details of reality.

2. Dependence on Initial Conditions: Computer models, especially in fields such as climate science or economics, are highly dependent on the initial conditions that they are set up with. A small error or uncertainty in the input can lead to huge discrepancies in the output, a phenomenon known as 'chaos theory'.

3. Over-reliance on Models: There is also a risk of over-reliance on computer models at the expense of observational data and field studies. This can lead to misplaced confidence in the models' predictions and conclusions, and potentially a failure to recognize, validate and address their limitations, biases, and errors.

4. Subjectivity and Bias: Computer models are created by humans, and so they are prone to potential human biases and subjectivity. The model creator chooses what factors to include and exclude, how to weight different factors, and the structure of the model, all of which can influence the model’s conclusions.

5. Lack of Transparency: Computer models, particularly in some fields, have been called out for their lack of transparency. The underlying algorithms, methodologies, and assumptions are not always made clear or open to review and scrutiny. This can make it hard for other scientists to understand, validate, or replicate the model and its results.

6. Predictive Limitations: Frequently, computer models are used to predict future events or behaviors. However, critics believe these models can only provide probability estimates and are unable to provide definite predictions because of the inherent limitations and uncertainty in their design and inputs.

7. Reification Fallacy: This is more of a misuse of models but still a valid criticism. Sometimes models are mistaken for the reality they are attempting to portray. This logical error is when an abstract concept is treated as if it were a concrete, real event or physical entity.

8. Ethical and Societal Impact: There is a growing concern about the ethical and societal impact of reliance on computer models, especially in sensitive areas like AI, machine learning, data science. From privacy issues to the potential for manipulation and bias, the ethical dimensions of computer modeling are increasingly under scrutiny.