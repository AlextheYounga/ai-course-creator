1. Reductionism: One major criticism of RCTs is their inherent reductionist nature. They are traditionally designed to isolate and test single variables, which might not adequately capture the complexity of real-world conditions or interactions.

2. Influence of Funding: Some studies suggested that RCTs funded by pharmaceutical or medical companies show a bias towards positive findings. This can lead to skewed research results, giving an illusionary superiority to certain treatments.

3. Lack of External Validity: RCTs might fail to provide generalizable findings suitable to all populations, cohorts, or settings. The tight controls maintained in these trials could limit real-world applicability of the results.

4. Ethical Considerations: Ethical issues are often raised about RCTs, especially when participants are assigned to placebo or control groups. In some cases, participants may not receive treatment altogether, which can be morally and ethically problematic.

5. Lack of Individualized Treatment: The one-size-fits-all approach in RCTs fails to take into account that everyone is unique and may react differently to treatments.

6. Time Constraints: Conducting RCTs is a lengthy procedure. The requirement of follow-ups for long-term effects exposes the inherent delay in getting crucial data which might be detrimental in emergent or rapid research fields.

7. Cost Issues: RCTs are usually expensive due to the multiple layers of testing and validation involved. This often limits the capacity and ability of lower-income countries to conduct their own trials.

8. Inherent Uncertainties: Despite its rigorous nature, uncertainties in RCTs stem from factors like patient non-compliance, lost-to-follow-up, cross-over, etc.

9. Overemphasis on Quantitative Data: RCTs prioritize empirical data collected through measurements, thereby neglecting important qualitative aspects of health and illness which may be critical in understanding the broader dimensions of the condition and treatment responses.

10. Variability in Trial Quality: There is a wide range of quality in how RCTs are conducted and this can affect the reliability and validity of results. Some trials may have flaws in design, execution or reporting, which can lead to inaccurate conclusions.