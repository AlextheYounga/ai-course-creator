1. Stifles Innovation: One of the most dissenting criticisms of intellectual property law is that it often hampers innovation. This perspective holds that a legal system in which ideas can be owned might discourage individuals and businesses from developing new concepts for fear of infringing on existing intellectual property rights.

2. Monopolization of Knowledge: Critics argue intellectual property rights create monopolies over knowledge and cultural expressions. This may hinder the free exchange of ideas necessary for cultural, technological, and scientific progress.

3. Access to Resources: Intellectual property law might restrict access to resources. Pharmaceuticals are a pronounced example where patents can seriously limit access to potentially life-saving drugs in underprivileged areas or in developing countries.

4. Complexity and the Cost of Enforcement: Intellectual property law is complex and often difficult to understand, making it a costly affair for small and medium-sized enterprises (SMEs). They may lack the knowledge or financial resources to protect their ideas, making them vulnerable to exploitation.

5. Inequality: Intellectual property can also contribute to inequality. Wealthy entities are often better positioned to patent their ideas, leading to a concentration of intellectual wealth. The disparity becomes more visible on the international front as developed nations typically hold a larger portion of worldwide intellectual property rights.

6. Obstacle to Learning: A dissident view is that intellectual property poses restrictions on learning and education. Copyright laws, for instance, may prevent scholars and students from accessing published works, limiting their educational opportunities.

7. Over-Protection: Critics argue that modern intellectual property law often over-protects privileged rights holders. This over-protection can hinder competition and impede the later development of related or dependent ideas and technologies. 

8. Cultural Appropriation: Another criticism is that intellectual property laws, particularly pertaining to traditional knowledge and cultural expressions, sometimes allow for their appropriation by outsiders, often without the original creators sharing in any financial gains.