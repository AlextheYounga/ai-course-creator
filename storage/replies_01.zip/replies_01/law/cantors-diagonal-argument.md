Cantor's Diagonal Argument is actually a mathematical, not a legal, proposition. It's renowned in the field of set theory and proves that not all infinities are created equal - some are larger than others. However, despite its significance and general acceptance in the mathematical community, some criticisms have been raised over time. 

1) Finite Model: Often the most mentioned criticism is that Cantor's diagonal proof, while logically sound, only applies to models of mathematical reality - not to physical reality. Some critics maintain that because we can't physically exist an actual infinite sequence, the diagonal argument is a purely abstract notion with no grounding in the 'real' world.

2) Self-Referential Argument: Some critics argue that Cantor's Diagonal Argument is self-referential or circular. They claim the argument uses the conclusion (that there are more real numbers than natural numbers) implicitly in its premise.

3) Misapplication of Infinity: Critics such as the infamous intuitionist, L.E.J. Brouwer, claimed that Cantor's use of finished/actual infinity instead of potential infinity was a basic error, leading to controversial and unintuitive results.

4) Role of Cardinal Numbers: Cardinal numbers (used to compare the size of sets) play a significant role in Cantor's argument. Critics argue that Cantor’s conception of size – and particularly, infinite size - might not be as intuitive nor as universally accepted as suggested.

5) Constructivist’s Critiques: The constructivist school of thought believes that to speak of existence, you must be able to construct or find the entity in question. The diagonal argument doesn't construct an actual new number, which challenges its validity from the constructivist perspective.

6) Diaconis’ Critique: Persi Diaconis, a renowned mathematician, has criticized diagonal arguments for their non-universality, implying they seemingly work against any set of numbers, ultimately leading to contradictions. 

The primary challenge in countering Cantor's diagonal argument is constructing a solid, logical opposition considering the abstract and ultimately self-contained nature of mathematical proof. However, these critiques suggest different perspectives on the concept of infinity and the nature of mathematical proofs.