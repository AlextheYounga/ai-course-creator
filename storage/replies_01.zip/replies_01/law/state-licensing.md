1. Erosion of Individual Liberties: Critics argue that state licensing infringes on individual liberties to partake in lawful economic activities and to select their preferred service providers, not regulated by governmental entities. It is seen as an overreach by the state, infringing on personal freedom.

2. Monopoly: State licensing could create monopoly-like situations. When only certain entities are licensed by the state, those without licenses are not able to compete, thus stifling competition. This can lead to higher prices and potentially poorer services.

3. Barrier to Innovation: State licensing also forms a barrier to innovation and entrepreneurship, as the elaborate process for obtaining permits requires significant resources that many startups may lack. This could stifle innovation and economic dynamism.

4. Regulatory Capture: There's a risk of regulatory capture, where the regulated actor manipulates the regulator to act in the interest of the regulated, rather than in the interest of the public. For instance, established players could use licensing requirements to keep new competitors out.

5. Inequality: Licensing requirements could disproportionately disadvantage marginalized or less privileged groups. Acquiring licenses often needs financial resources and certain educational qualifications that not everyone may have access to.

6. Inefficiency: The processing time and bureaucracy involved in obtaining governmental licenses could delay the implementation of projects and lead to inefficiencies. Also, the allocation of licenses may not reflect the actual market demand but rather the bureaucracy's perception of it.

7. Lack of Adaptability: The rules and regulations associated with licensing often cannot keep up with the fast-paced evolution of certain industries, especially in the technology sector, potentially stifling growth and innovation.

8. Quality of Service: There is an argument that bureaucratic licensing might not adequately ensure the quality of service, as it often focuses on paper qualifications rather than practical competence. 

9. Corruption: State licensing systems are often criticized for being prone to corruption, with licenses at times being awarded based on connections rather than merit.

10. Obsolete Regulations: Some critics argue that many licensing requirements are anchored in obsolete regulations that no longer apply to the modern world. Removing these could stimulate economic activity and innovation.