1. Overly Simplistic: Critics argue that Valence Bond Theory (VBT) is overly simplistic. They suggest that it offers a limited view, focusing only on the atoms and bonds involved within individual molecules. This narrow focus could potentially overlook the broader, more complex interactions at play in a given system.

2. Can't Accurately Predict Geometry: Dissidents of VBT argue that the theory is unable to accurately predict the shape and geometry of complex molecules, especially those involving d-orbitals and beyond. The molecular geometry predicted by VBT often doesn't align perfectly with experimental observations. 

3. Conceptual Ambiguity: VBT has been criticized for its conceptual ambiguity regarding the process of hybridization. It isn't always clear why certain atoms hybridize in a certain way, and there seems to be a lack of empirical evidence supporting some aspects of the explanation.

4. Cannot Predict Colors or Magnetic Properties: A significant criticism centers on the inability of VBT to predict colors or magnetic properties of complexes, which are explained very well by Crystal Field Theory or Ligand Field Theory.

5. Resonance Structures: VBT often requires the drawing of several resonance structures to accurately depict some molecules (such as benzene). Critics argue that this could lead to confusion and adds an unnecessary level of complexity.

6. No Information on Energy: Critics complain that VBT gives no information about the energy of the molecule or the energy required to break a bond, which is often a critical aspect in reactions.

7. Limited Applicability: Critics argue that VBT has limited applicability as it works well for explaining covalent bonds and simple molecules, but struggles with more complex molecules or those involving metallic bonds or ionic bonds. 

8. Not Quantitative: Some criticize VBT for not being quantitative, in contrast to Molecular Orbital Theory, which provides a quantitative framework with parameters that can be experimentally determined.