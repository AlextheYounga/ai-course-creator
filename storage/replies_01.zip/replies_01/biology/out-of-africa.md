The 'Out of Africa' theory posits that all modern humans have a common ancestry in Africa. The most dissident criticisms or alternative views to the Out of Africa theory might include:

1. Multiregional Evolution: This alternative hypothesis suggests that the human species evolved simultaneously in different parts of the world - Africa, Asia, and Europe. In this framework, regional populations continuously exchanged genes through interbreeding, maintaining a common species through time and space.

2. Recent African Genesis overgeneralization: Critics argue that the out of Africa theory oversimplifies history by suggesting a single emigratory event. They argue that there could have been multiple migrations out of Africa at different periods, leading to more complexity than yet appreciated.

3. Focus on Africa bias: Some critics express concerns that the ‘Out of Africa’ perspective implicitly undermines the importance of investigating human evolution in regions outside of Africa due to its presumption of Africa as the primary cradle of humanity. 

4. Variations in genetic data interpretations: Critics suggest that genetic data that supposedly supports the Out of Africa theory could be interpreted differently. They mention that genetic diversity does not necessarily equate to a location being a point of origin. 

5. Limited archaeological evidence: Archaeological findings in various parts of the world like East Asia and Europe suggest the presence of early humans in these regions, contradicting the concept that Africa was the single origin point. Critics claim these findings are not adequately addressed by the Out of Africa theory.

6. Incomplete Fossil Record: Critics often point out the fragmentary and incomplete nature of the fossil record and how this makes conclusive statements about human evolutionary history risky, potentially allowing for alternative interpretations or theories.

7. Linguistic Diversity: Some critics look at the wide array of languages around the world and suggest that such diversity indicates a multiregional evolution of modern humans rather than a singular out-of-Africa migration.

Remember, these alternative viewpoints represent contrary opinions and should be evaluated based on their scientific merits. Most mainstream scientists currently support the Out of Africa model due to its strong backing from diverse strands of evidence.