1. Environmental Impact: While LED lights are touted as eco-friendly due to their energy efficiency and long lifespan, they contain hazardous components such as lead, arsenic and many other potentially dangerous substances. If not disposed of properly, they could leak these materials into the environment.

2. Blue Light Hazard: Common LED lights emit a large amount of blue light, which has been shown to damage the eyes over time and disrupt sleep patterns. Overexposure to this blue light can potentially lead to conditions such as macular degeneration.

3. Light Pollution: The increased use of LED lights, particularly in outdoor settings like streetlights, has resulted in a significant increase in light pollution. This has substantial negative effects on wildlife, particularly nocturnal animals, and disrupts ecosystems.

4. Energy Consumption: Even though LED lights are more energy-efficient than traditional lighting, the total energy consumption is on the rise because of the proliferation of lighting devices, in general. Therefore, LED might be contributing to a higher overall energy demand.

5. Non-Biodegradable: LED lights, like many other electronic products, are non-biodegradable. This creates a significant disposal problem and contributes to the growing electronic waste issue worldwide.

6. Impacts on Human Health: Aside from the blue light hazard, the unnatural light provided by LEDs can disrupt circadian rhythms. This disruption can potentially lead to conditions such as depression, cardiovascular issues, and cancer.
   
7. Socio-economic Disadvantage: The initial cost of LED lights is higher than traditional lighting options, which can be a barrier for low-income households trying to transition towards more sustainable options.

8. Rare-Earth Elements: Manufacturing processes of LED light bulbs require the use of rare-earth elements. The extraction and processing of these elements often lead to environmental degradation and pollution.