Criticism on the mainstream thought about microplastics mainly revolves around their potential impact, the urgency of the problem, and existing mitigation strategies. Here are the most dissident criticisms:

1. Unclear Impact on Human Health: Despite various studies finding microplastics present in common foods, drinking water and even our bodies, the actual impact on human health is still uncertain. Some critics argue that assuming immediate danger without concrete understanding of the effects could lead to unnecessary panic.

2. Unrealistic Approach to Mitigation: While there is a unanimous agreement on curbing plastic pollution, critics question the focus on microplastics specifically, stating that primary plastic pollution is a far more visible and immediate problem to address.

3. Lack of Comprehensive Data: The scope of the problem remains a matter of speculation, as there is no comprehensive data on the total volume of microplastics in the environment. Critics claim this makes it difficult to gauge the true extent of the issue.

4. Further Research Needed: Some critics argue that the current research lacks depth and suggest that future studies should focus on understanding the specific physical and chemical processes through which microplastics interact with different organisms.

5. Exaggerated Focus on Marine Microplastics: Critics argue that even within the study of microplastics, the focus is primarily on marine microplastics, which can undermine the importance of understanding their impact on terrestrial and freshwater ecosystems.

6. Economic Considerations: People argue that the economic implications of drastically reducing plastic usage or changing to alternatives haven't been fully considered.

7. Ineffectiveness of Recycling: Critics point out that recycling isn't an effective solution for plastic pollution, as it implies that the plastic will be reused, while in reality, it often ends up in landfills or the ocean.

8. Focus on Individual Responsibility, Not Corporations: Critics often contend that the onus on curbing microplastic pollution is unfairly placed on individuals rather than the corporations that largely contribute to the problem. 

Remember that these criticisms do not undermine the potentially harmful impacts of microplastics, but rather critically evaluate our current understanding and approach towards the subject.