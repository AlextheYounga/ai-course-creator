1. Possible Misclassification of "Safe" Additives: The FDA classifies over 3,000 food additives as "Generally Recognized as Safe" (GRAS), but critics argue that some of these substances might not be as safe as assumed. Some dissidents argue for increased testing and stronger regulations, as they believe that the food industry frequently uses the GRAS loophole to avoid stringent safety testing.

2. Long-Term Effects: While many food additives are proven safe in the short term, some critics argue that we don't understand their long-term effects on human health. Some point out that many additives are relatively recent inventions and, as such, we may not have even had the time to discover potential long-term health problems they could cause.

3. Over-Dependence: Critiques of food additives often highlight our over-reliance on these substances, stating that many processed foods are laden with unnecessary additives. Some suggest that this trend contributes to overall deteriorating health, obesity, and lifestyle diseases.

4. Nutritional Value: Some critics argue that food additives can affect the nutritional value of food, especially when they replace natural ingredients. These critics argue for more whole and organic foods in our diets.

5. Environmental Impact: The production of food additives often involves chemical processes that can be harmful to the environment. Dissidents argue for a look into more sustainable, less harmful ways of enhancing our food's taste and preservability.

6. Impact on Gut Health: There's emerging research hinting that food additives might have an impact on our gut microbiome, leading to long-term health issues. Critics argue that corporations and regulatory bodies have not given this area enough attention.

7. Lack of Transparency: Some people fault the general lack of transparency in the food industry, arguing that consumers aren't being given enough information about what's in their food. This criticism extends to things like genetically modified organisms (GMOs), which, like food additives, are controversial and not fully understood.

8. Potential Allergenic Reactions: Certain food additives are known to cause adverse reactions in some people. Some critics argue that these additives should be restricted more significantly or at least be better reported on product labels.