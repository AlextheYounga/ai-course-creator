1. Conceptual Misunderstanding: Critics argue that the term "Dirty Electricity" itself is misleading and allows for misconceptions. It refers to electromagnetic pollution, like radio waves, microwaves and others that naturally exist in the environment. Labeling it as unnatural or dirty can be considered fear-mongering.

2. Inadequate Evidence: While some researchers believe in a connection between electromagnetic fields (EMFs) and health problems, critiques suggest that scientific evidence to support this claim is lacking or at best inconsistent. There is no definitive proof that the low-frequency EMFs produced by electrical devices have any significant adverse effect on human health.

3. Pseudoscience Claims: Critics also argue that the increased hype and fear about dirty electricity apparatus amount to pseudoscience. Some firms capitalize on fear by selling protective gadgets with no proven effectiveness.

4. Misinterpreted Correlation: Studies pointing to correlations between dirty electricity and health outcomes often fail to properly account for confounding factors. Critics argue that these correlations may be incidental and do not necessarily reflect causation.

5. Inconsistent Measurement Standards: The measurement and standards used for dirty electricity are inconsistent, with no central authority or internationally recognised regulatory body. This lack of clear and consistent measurement can undermine the credibility of claims made about the harm of dirty electricity.

6. Focus on More Significant Environmental Factors: Some critiques argue that the panic over dirty electricity diverts attention and resources away from other more immediate and verifiable environmental issues such as air and water pollution, global warming, and deforestation.

7. Fear and Paranoia: Critics believe the focus on dirty electricity fuels fear and paranoia about modern life and technology. This results in a stress response which is arguably more harmful than the alleged impact of dirty electricity.

8. Economic Inducements: Sometimes, a claim of health problems purportedly caused by dirty electricity is seen as an excuse to oppose certain economic activities such as the setting up of mobile base stations and power lines, which could be economically beneficial to a community.

9. Lack of Personalization in Risk Assessment: Critics argue that risks associated with dirty electricity are often generalized, ignoring the fact that sensitivity to EMFs can vary from person to person. It fails to account for individual differences in terms of immunity, health status, and lifestyle factors. 

10. Overemphasis on Technology: The criticism over dirty electricity places too much focus on the potential harm of modern electrical devices, instead of emphasizing the enormous benefits that technology brings to society. It undermines the importance of technology in improving our standards of living.