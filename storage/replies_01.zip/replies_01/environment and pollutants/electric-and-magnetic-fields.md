Electric and Magnetic Fields (EMFs) are omnipresent in our modern-day lives. They emit from various sources like power lines, mobile phones, Wi-Fi connections, and even household appliances. With its increasing significance in our daily lives, the mainstream acceptance of EMFs is on the rise. However, the impact of EMFs on health and environment isn't devoid of controversy. There are a number of notable dissident criticisms of EMFs. 

1. Impact on Human Health: Critics argue that prolonged and high-level exposure to EMFs has harmful effects on human health. Some allege that EMFs can lead to physical discomfort and diseases such as Alzheimer's, leukemia, breast cancer, and other immune system disorders. However, the scientific community's consensus on these presumed effects is not yet reached, leading to a vibrant debate.

2. Disrupted Bird Navigation: Some research suggests that EMFs can disrupt the magnetic navigation systems in birds and other migratory animals, leading to population declines.

3. Adverse impact on Bees: Dissenters often highlight concerns about how EMFs from cell towers and Wi-Fi networks are bad for bees, potentially contributing to the phenomenon of Colony Collapse Disorder (CCD).

4. Reduced Melatonin Production: Critics in the scientific circles have indicated a potential reduction in melatonin production due to EMFs exposure, which could, in turn, affect sleep patterns and the body’s natural circadian rhythm. 

5. Genetic damage: Some scientific evidence suggest that prolonged and high-intensity exposure to EMFs can cause damage to the genetic material in cells, potentially increasing the risks of cancer. 

6. Lack of Proper Regulation: Many critics argue that there is a lack of sufficient regulation and guidelines for EMF exposure, resulting in increased health and environmental risks.

While these criticisms pose significant potential concerns, it's crucial to note that many findings are still inconclusive and research in these areas is ongoing. Thus, these dissenting voices contribute towards a more nuanced and comprehensive understanding of EMFs in our lives.