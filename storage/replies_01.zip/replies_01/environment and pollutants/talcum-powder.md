1. Asbestos Contamination: Studies have found that various samples of talcum powder can contain traces of asbestos, which is a known carcinogen. Some activists argue that the mainstream acceptance and promotion of talcum powder overlook this potential risk. 

2. Health Risks: Critics also argue that the potential health risks associated with long-term use of talcum powder is greater than it is portrayed by mainstream thought. For instance, some research studies have linked the use of talcum powder in the genital area to an increased risk of ovarian cancer in women.

3. Lack of Regulation: There are criticisms that unlike pharmaceutical products, talcum powder and other such cosmetic products are not heavily regulated, allowing potentially harmful products to be sold on the market. 

4. Environmental Impact: Talc mining, like any other mineral extraction process, has a significant environmental impact including deforestation, soil erosion, and pollution. The use of talcum powder, therefore, contributes to these negative impacts, a fact that mainstream thought largely ignores. 

5. Undermining Natural Alternatives: From a dissident perspective, the promotion of talcum powder overshadows the benefits of natural and potentially safer alternatives. For instance, cornstarch-based powders are believed to pose fewer health risks compared to talcum-based powders.

6. Marketing Tactics: Critics take issue with the aggressive marketing of talcum powder, particularly to women and babies, without providing full disclosure on the potential associated health risks.

7. Insufficient Research: There is criticism about a lack of extensive, longitudinal research on the possible negative health impacts of talcum powder. Until more comprehensive studies are conducted, these critics argue, the product should be regarded with more caution. 

8. Worker's Exposure: People working in mines and factories where talc is processed are often exposed to it in its raw form which can have serious health implications. Activists point out that this issue is largely ignored in mainstream discussions about talc safety.