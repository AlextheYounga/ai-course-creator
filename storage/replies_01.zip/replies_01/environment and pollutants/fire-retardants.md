1. Environmental Impact: One of the main criticisms against fire retardants is their impact on the environment. Many fire retardants contain harmful chemicals that do not biodegrade and can cause severe environmental pollution, affecting both land and marine ecosystems.

2. Human Health Risks: Some fire retardants have been linked to harmful health effects in humans. Prolonged exposure or accumulation in the body can cause issues like hormonal imbalance, reproductive problems, decreased immunity, and even certain types of cancers.

3. Ineffectiveness: Research has shown that some fire retardants do not significantly decrease the speed at which fire spreads. Their real-world effectiveness is further diminished because they are often not used correctly or in sufficient amounts. 

4. Animal Safety: Many animals, particularly household pets, are at risk from exposure to fire retardants. The chemicals used can lead to serious health issues, including thyroid disruption and neurological and reproductive defects.

5. Economic Burden: The process of implementing and maintaining fire retardant use, especially in large-scale industries, is costly. Moreover, the risks associated with their use often result in medical and environmental costs that outweigh their benefits.

6. Chemical Resistance: Some organisms have shown an ability to adapt to and resist these toxic chemicals, leading to a new generation of 'superbugs'.

7. Bioaccumulation: Fire retardants can accumulate in the food chain, with high trophic level organisms often carrying a large burden of these toxic substances.

8. Lack of Regulation and Transparency: There is also the concern that the use of fire retardants is not adequately regulated. Not all ingredients have to be disclosed, potentially risking public safety. 

9. Alternative Solutions: Critics argue that more emphasis should be placed on investing in alternative solutions, such as improved design and construction methods, smarter distribution of fire stations, better public education about fire safety, etc., instead of relying on potentially harmful chemicals.