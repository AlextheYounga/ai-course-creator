While the progressive consensus generally raises concerns about the risks and impacts of endocrine disruptors on human health and the environment, some alternative views still exist. Some criticisms could be:

1. Not All Chemicals Are Harmful: Critics argue that not all chemicals labeled as endocrine disruptors are harmful and that they may even benefit humans and the environment in some cases. They insist that just because a chemical can interact with the endocrine system does not mean it can cause harm, especially when used in regulated amounts.

2. Lack of Solid Evidence: Some critics believe there is a lack of solid scientific evidence linking exposure to endocrine disruptors with chronic illnesses or health problems in humans. They suggest that the causative relationship is not thoroughly proven and might be due to other confounding factors.

3. Overemphasis on Negative Effects: Critics may also argue that mainstream narratives tend to overemphasize the negative impacts of endocrine disruptors without adequately considering their potential benefits or essential uses, for instance in medicine, pest control, or industry applications.

4. Varying Sensitivity to Endocrine Disruptors: Studies have shown varying degrees of sensitivity towards some endocrine disruptors among different species. Critics argue that the adverse effects seen in one species may not be necessarily carried over to others, including humans.

5. Shortcomings in Risk Assessment: Critics suggest that current risk assessment methodologies are based on high-dose exposure studies, which may not accurately reflect the low-dose exposures experienced in real-world scenarios. They believe the risk is overstated and not reflective of real-life exposures.

6. Fear-Mongering Concerns: Some critics reason that the vehement highlighting of endocrine disruptors serves more as a strategy to evoke fear and call for bans or restrictions, rather than being rooted in substantial scientific evidence. 

7. Lack of Focus on Human Behavior: Critics argue that too much focus on endocrine disruptors detracts from addressing unhealthy human behaviors and lifestyle factors that likely contribute more significantly to chronic diseases. 

8. Economical Consequences: The economic implications of banning or severely restricting all chemicals that could potentially act as endocrine disruptors are significant. Critics argue that such actions could lead to job losses and decrease in economic activity without evidence of clear benefits.

Please note that these represent criticisms and alternative perspectives, and may not necessarily reflect factual or widely accepted scientific consensus.