1. Lack of Replication: Some studies that initially showed priming effects failed to replicate under rigorous testing conditions. This calls into question the overall validity and reliability of priming as a psychological construct.

2. Overreliance on Laboratory Experiments: Priming has been criticized for being largely studied in artificial experimental conditions that may not reflect real-world situations. Critics argue that priming effects may not occur or may be significantly diminished in non-laboratory contexts.

3. Unconscious Priming: Critics question the notion of unconscious priming, believing that participants in experiments are often aware of the priming stimuli and their intended effects, which may consciously influence their behaviour.

4. Cherry-Picked Results: Some critics suggest that researchers have often highlighted positive findings that support their studies while neglecting those that do not, leading to an overestimation of the priming effect.

5. Experimenter Bias: Critics have pointed out that the researchers may inadvertently influence participants to display desired behaviours or responses, thereby skewing the results.

6. Vague Theoretical Foundations: Critics argue that the theoretical foundations underlying various types of priming (semantic, perceptual, etc.) are vague and do not offer clear, testable predictions.

7. Variability of Findings: The effects of priming have been observed to vary greatly across different studies, raising questions about the consistency and generalizability of priming effects.

8. Inconclusive Impact on Behaviour: Critics challenge the claim that priming significantly impacts people’s attitudes and behaviours outside of lab settings, pointing out that there's no solid evidence supporting the claim.

9. Publication Bias: There have been concerns raised that studies showing significant priming effects are more likely to be published than those that do not, leading to a skewed scientific record that exaggerates the prevalence and power of priming.

10. Lack of Mechanistic Explanation: Critics have also argued that while the existence of priming as a psychological phenomenon might be accepted, its precise biological or neural mechanisms remain largely unknown. This absence of a clear explanation for how priming works at a physical level casts doubt on its scientific maturity.