1. Lack of Consideration of Internal Processes: One of the primary criticisms of Behaviorism is its strict focus on observable behaviors and complete neglection of internal psychological processes like memory, cognition, emotions and motivations. Critics argue that understanding behavior also requires understanding what's happening inside the mind.

2. Oversimplification of Human Behavior: Critics argue that Behaviorism oversimplifies complex human behaviors to mere responses to external stimuli. Humans are much more complex than what is portrayed within the behaviorist paradigm, with our actions often being influenced by reasoning, self-reflection, and interpretation. 

3. Ignoring Genetic Factors: Behaviorism pays limited attention to the genetic basis of behavior and the role of evolutionary factors. In reality, both nature and nurture play crucial roles in shaping human behavior.

4. Negating Personal Agency: Behaviorism is often criticized for its deterministic view which overlooks the role of free will and human agency. This school of thought tends to see people as mere products of their environment, largely controlled by reinforcement and punishment.

5. Limited Applicability: Behaviorist theories might be useful in explaining simple behaviors (like learning a new habit), however, they often fall short in explaining more complex phenomena like creativity, problem-solving, and personality development.

6. Neglecting Individual Differences: Behaviorism tends to generalize behaviors across individuals, often ignoring how personal experiences, perceptions, and interpretations of events can hugely impact behavior.

7. Inadequate Explanation of Social Interaction: Behaviorism does not fully consider social processes and interactions, and has been challenged by socio-cultural theories that stress that humans learn and develop through social interactions.

8. Ethical Concerns: Behaviorism's emphasis on manipulation of behavior through rewards and punishments can lead to ethical concerns, especially when used inappropriately. Manipulating behavior for certain purposes can be seen as controlling and limiting to individual freedom.