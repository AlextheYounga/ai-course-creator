# Objects and Key-Value Pairs

When learning JavaScript, or any programming language for that matter, one of the first complex types you'll encounter is the `Object`. Understanding objects is like getting to know the compartments of a toolbox; each compartment can hold a specific tool or item, similarly, objects can keep your data organized with key-value pairs, where each key is unique and corresponds to a value.

Think of a social media profile. It contains a user's name, age, bio, and a bunch of other personal details. Each piece of information is associated with a specific aspect—user's name to their actual name, age to their current age, and so on. In JavaScript, we could represent this profile as an object where each detail is a key-value pair.

Here's a basic example:
```javascript
let userProfile = {
    name: 'Alex',
    age: 27,
    bio: 'Enthusiast of all things tech!',
};
```
In this snippet, `userProfile` is an object that contains three key-value pairs. `name`, `age`, and `bio` are the keys, and the associated strings and number are the values. To access any of these values, we can use a dot notation, like `userProfile.name`, which will give us `'Alex'`.

Objects are incredibly flexible. You can nest them inside each other, creating a multi-layered structure. Imagine a filing cabinet—each drawer can contain folders, and each folder can contain files, and so on. Similarly, a JavaScript object can contain another object as a value.

Let's add a nested object:
```javascript
userProfile = {
    ...userProfile,
    contactInfo: {
        email: 'alex@techmail.com',
        phoneNumber: '123-456-7890'
    }
};
```
Now `userProfile` has a nested object `contactInfo` which itself has two key-value pairs: `email` and `phoneNumber`. To access Alex's email, we'd use `userProfile.contactInfo.email`.

<div id="answerable-multiple-choice">
    <p id="question">If we wanted to access the phoneNumber from userProfile, what line of code would we write?</p>
    <select id="choices">
        <option>userProfile['phoneNumber']</option>
        <option>userProfile.phoneNumber</option>
        <option>userProfile.contactInfo</option>
        <option id="correct-answer">userProfile.contactInfo.phoneNumber</option>
    </select>
</div>

Besides offering a way to structure data, objects in JavaScript are essential for things like configuration options for functions, managing state in applications, and interacting with data structures from external APIs. For example, many web APIs will send data back in JSON format, which is essentially a text-based representation of JavaScript objects.

Understanding objects and their key-value pairs allow for managing application settings, user preferences, or game scores, to name a few. They're fundamental building blocks for creating interactive and dynamic web applications. With JavaScript objects, you're laying down the groundwork for more advanced structures and functionality, which you can carry over to other programming languages and concepts as well.