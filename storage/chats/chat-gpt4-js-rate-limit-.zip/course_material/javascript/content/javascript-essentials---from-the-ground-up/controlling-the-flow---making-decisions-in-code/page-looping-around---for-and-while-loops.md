# Looping Around - For and While Loops

Imagine you're at the gym, and your coach tells you to do ten push-ups. You don't just drop down and push up once and then stand back up - nope, you repeat the motion, up and down, ten times. In coding, especially in JavaScript, sometimes we need to repeat actions just like push-ups. This is where loops come in handy.

Loops in JavaScript are built-in constructs that allow us to execute a block of code as many times as we need. It's like telling the computer, "Hey, do this thing a set number of times," or sometimes "Keep doing this until I tell you to stop." There are a few different types of loops, but today we're going to focus on the 'for' and 'while' loops because they're kind of like the bread and butter of looping in JavaScript.

Let's start with the 'for' loop. A 'for' loop is great when you know exactly how many times you want to run your code. It's like saying, "I want to eat exactly three cookies," and then you go ahead and eat cookie one, cookie two, and cookie three. Here's what a 'for' loop might look like:

```javascript
for (let i = 0; i < 3; i++) {
    console.log('Nom nom, cookie number ' + (i + 1));
}
```

In the code above, `i` starts at 0, the loop runs until `i` is no longer less than 3, and `i` gets incremented by 1 each time through the loop. 

Now let's talk 'while' loops. A 'while' loop is your go-to when you want to keep running code as long as a certain condition is true. It's a bit like saying, "Continue eating cookies as long as the cookie jar isn't empty." A simple example looks like this:

```javascript
let cookiesLeft = 5;
while (cookiesLeft > 0) {
    console.log('Hmm, still got cookies. Let’s eat one more!');
    cookiesLeft--; // We eat a cookie, so we have one less.
}
```

Here, `cookiesLeft` keeps track of how many cookies we've got, and as long as it's more than zero, we keep eating cookies (and printing a message each time). The `cookiesLeft--;` is a short way of saying `cookiesLeft = cookiesLeft - 1;`.

Now it's your turn to get hands-on with loops. Let's see what you've learned!

<div id="answerable-multiple-choice">
    <p id="question">What will be the output of the following 'for' loop code snippet?</p>
    <pre>
for (let i = 0; i < 5; i++) {
    if (i % 2 === 0) {
        console.log(i);
    }
}
    </pre>
    <select id="choices">
        <option>0 1 2 3 4</option>
        <option>1 3 5</option>
        <option id="correct-answer">0 2 4</option>
        <option>1 2 3 4</option>
    </select>
</div>

In this example, the loop prints out each number from 0 to 4, but the `if` statement inside the loop checks whether the number is even (by using the modulo operator `%` which gives the remainder of division by 2). If the number is even, it’s printed out—hence, the correct output would be only the even numbers: 0, 2, and 4.

Loops are powerful tools, and understanding how to control their operation will make you a more efficient and creative JavaScript programmer. Whether you're iterating over items in a shopping cart or cycling through messages in a chat app, loops are everywhere in programming. Your mission, should you choose to accept it, is to conquer the art of looping!