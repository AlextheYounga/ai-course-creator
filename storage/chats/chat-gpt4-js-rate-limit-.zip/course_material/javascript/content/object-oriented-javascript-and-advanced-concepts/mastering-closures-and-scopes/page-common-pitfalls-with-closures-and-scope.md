Page Title: Common Pitfalls with Closures and Scope

---

When diving into the world of JavaScript, closures and scope present themselves a bit like magic at first. One moment everything's working fine, and suddenly you're lost in a labyrinth of variables and functions, wondering where you took a wrong turn. Let's get our bearings and navigate through some common pitfalls that developers often stumble upon when working with closures and scope.

Imagine you're at a concert with your friends, and you're trying to save spots for them. The area where you are is the `local scope`, and your friends, who are yet to arrive, are like variables that are yet to be declared. Everything inside that area can be easily accessed by you and your friends, but to those outside, it's a no-go zone. This is akin to local variables within a function's scope—they are not accessible from the outside world.

Now, think of closures as your friend with a VIP pass who can get in and out of the concert area, including the local scope. They can remember and bring in stuff from the outside. In JavaScript, a closure is a function that remembers its outer variables and can access them. That’s powerful, but with great power comes great responsibility.

### Problem 1: Accidental Global Variables

Let's start off with a common mistake of unintentionally creating global variables. This occurs when you forget to use the `var`, `let`, or `const` keyword to declare your variables. The variable immediately gets hoisted to the global scope, like a balloon that escapes your grasp and floats up into the sky, for everyone to see—and modify.

Here's an example of this mishap:

```javascript
function foo() {
    accidentalGlobal = "I am now part of the window object. Oops!";
}
foo();
console.log(accidentalGlobal); // Outputs "I am now part of the window object. Oops!"
```

<div id="answerable-multiple-choice">
    <p id="question">Which keyword can prevent the creation of a global variable inside a function?</p>
    <select id="choices">
        <option>global</option>
        <option>local</option>
        <option id="correct-answer">var</option>
        <option>public</option>
    </select>
</div>

### Problem 2: Overwriting inner scope

Another pitfall is shadowing variables from an outer scope by declaring a local variable with the same name. It's like when someone else at the concert puts down a blanket right over yours—your blanket is still there, but it's inaccessible.

```javascript
var celebrity = "Beyonce";

function localStage() {
    var celebrity = "Local Artist";
    console.log(celebrity); // Outputs "Local Artist"
}

localStage();
console.log(celebrity); // Outputs "Beyonce"
```

In the code above, the `celebrity` inside `localStage()` overshadows the outer `celebrity`, but only within the scope of that function.

### Problem 3: Loops and Closures

Many programmers have been burned by this one. You're creating a series of buttons and setting up an event listener for each. It's like handing out flyers for different concert afterparties, but by mistake, every flyer points to the same location.

```javascript
for (var i = 1; i <= 5; i++) {
    document.getElementById('button' + i).addEventListener('click', function() {
        alert('You clicked button ' + i);
    });
}
```

Every button will incorrectly alert 'You clicked button 6', because the variable `i` gets hoisted and shared across all the event listeners, settling at its final value after the loop ends.

<div id="answerable-code-editor">
    <p id="question">Refactor the above code using closures to correctly alert the button number when clicked.</p>
    <p id="correct-answer">// Example correct solution
for (var i = 1; i <= 5; i++) {
    (function(index) {
        document.getElementById('button' + index).addEventListener('click', function() {
            alert('You clicked button ' + index);
        });
    })(i);
}</p>
</div>

Avoiding these pitfalls will help keep your code clean and predictable. Just like at a concert, being aware of your surroundings (scopes) and who has access to what (closures) can prevent a lot of confusion and ensure a great experience—or in JavaScript terms—a well-functioning program. Keep practicing, and soon you'll be handling closures and scopes like a pro, maybe even with some crowd-surfing along the way!