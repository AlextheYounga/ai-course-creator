# Adding Event Listeners

When we want our web pages to respond to user interaction, we need to add event listeners. These are like attentive little workers who are constantly on the lookout for specific actions, such as clicking a button, hovering over an element, or pressing a key. Once they detect the specified action, they trigger the associated function to handle the event.

### Event Listener Setup

To add an event listener to an HTML element, you must first select the element using JavaScript. This can be done by using methods like `getElementById`, `getElementsByClassName`, `querySelector`, `querySelectorAll`, etc. Once you have the reference to the element, you can add an event listener to it.

Let's say we have a button with the id "myButton" in our HTML:

```html
<button id="myButton">Click Me</button>
```
To add a click event listener to this button, we can do the following in JavaScript:

```javascript
const button = document.getElementById('myButton');
button.addEventListener('click', () => {
  // Do something when the button is clicked
});
```

The `addEventListener` method takes in two arguments:
1. The type of event to listen for, in this case, 'click'.
2. The function (or reference to a function) to call when the event is detected.

### Practical Example

Think of event listeners as subscribers to a newsletter. When a new newsletter (event) is published, all the subscribers (event listeners) are notified and can then read the content (trigger the function).

Imagine an online store that changes the product image when you hover over a thumbnail. The image update is triggered by an event listener monitoring the mouse hover action.

### Understanding Event Flow

When adding event listeners to elements nested within other elements, it's important to understand the event flow and how it can affect event handling. This knowledge helps in preventing unexpected behavior and enables precise event management.

Now, let's practice setting up event listeners with a quick multiple choice question.

## Multiple Choice
<div id="answerable-multiple-choice">
    <p id="question">What method is used to add an event listener in JavaScript?</p>
    <select id="choices">
        <option>bindEvent</option>
        <option>attachEventListener</option>
        <option id="correct-answer">addEventListener</option>
        <option>listenForEvent</option>
    </select>
</div>