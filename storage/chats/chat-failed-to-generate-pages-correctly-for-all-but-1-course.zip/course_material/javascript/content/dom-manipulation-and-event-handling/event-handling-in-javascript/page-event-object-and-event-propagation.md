# Event Object and Event Propagation

Welcome to the fascinating world of event handling in JavaScript! In this section, we'll delve into the intriguing concepts of the event object and event propagation. These concepts are crucial to understand if you want to master DOM manipulation and event handling in JavaScript.

## The Event Object

When an event is triggered, JavaScript creates an **event object** which contains pertinent information about the event. This object provides details such as the type of event, the element it was triggered on, and the coordinates of the mouse at the time of the event.

Imagine attending a music concert. The event object is like a backstage pass that gives you access to behind-the-scenes information about the concert, such as the setlist, the performers, and the stage setup. Similarly, the event object in JavaScript gives you backstage access to all the important details about the event.

### Event Propagation

Now, let's talk about **event propagation**. When an event occurs on a DOM element, such as a click on a button inside a `<div>`, the event can "propagate" or "bubble" up through the DOM tree, triggering event handlers on ancestor elements. Additionally, events can also "capture" down through the DOM tree from the top-level ancestor to the target element.

To better grasp this concept, think of a family gathering. When a celebration is happening in a large family, the news of the celebration might propagate to all the relatives, starting from the eldest family members down to the youngest, or sometimes the excitement may capture the attention of the younger generation and move upwards through the family tree.

Understanding event propagation is vital when you need to manage event handling on multiple nested elements, as it allows you to control which event handler should respond to an event first.

## Interactive Element

<div id="answerable-multiple-choice">
    <p id="question">What is the purpose of the event object in JavaScript?</p>
    <select id="choices">
        <option>To propagate events</option>
        <option id="correct-answer">To provide information about the event</option>
        <option>To control event propagation</option>
        <option>To style DOM elements</option>
    </select>
</div>

Now that you've gained an understanding of the event object and event propagation, let's explore some practical examples and learn how to work with these concepts in JavaScript.