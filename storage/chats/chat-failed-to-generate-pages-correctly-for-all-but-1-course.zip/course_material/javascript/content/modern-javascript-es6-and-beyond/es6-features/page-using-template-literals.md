# Using Template Literals

Welcome to the world of template literals in JavaScript! In this section, we will explore how template literals provide a more flexible and readable way to work with strings in JavaScript.

## What are Template Literals?

Template literals, introduced in ES6, are a new way to work with strings in JavaScript. They are enclosed by backticks **(\`)** instead of single or double quotes. One of the key features of template literals is the ability to embed expressions directly within the string, making it easier to create dynamic content.

Let's take a look at a simple example to understand the syntax of template literals:
```javascript
const name = 'Alice';
const greeting = `Hello, ${name}!`;
console.log(greeting); // Output: Hello, Alice!
```

In the above example, `${name}` is an expression that gets evaluated and embedded within the string.

## Multi-line Strings

Template literals also make it convenient to create multi-line strings without the need for concatenation or special characters:
```javascript
const multiLineString = `
This is a 
multi-line 
string
`;
console.log(multiLineString);
// Output:
// This is a
// multi-line
// string
```

Template literals provide a more elegant way to define multi-line strings compared to traditional string literals.

## Embedded Expressions

One of the powerful features of template literals is the ability to embed expressions directly within the string. This can be especially useful when constructing complex strings or generating dynamic content.

```javascript
const item = 'coffee';
const price = 3.50;
const quantity = 2;
const totalPrice = `The total cost of ${quantity} ${item}(s) is $${price * quantity}`;
console.log(totalPrice); // Output: The total cost of 2 coffee(s) is $7
```

Template literals allow us to include variables and expressions within the string, making it easier to create dynamic content.

Now, let's put your knowledge to the test with a quick challenge.

## Fill in the Blank

<div id="answerable-fill-blank">
    <p id="question">What are the opening and closing characters for a template literal in JavaScript?</p>
    <p id="correct-answer">Backticks ( \` )</p>
</div>