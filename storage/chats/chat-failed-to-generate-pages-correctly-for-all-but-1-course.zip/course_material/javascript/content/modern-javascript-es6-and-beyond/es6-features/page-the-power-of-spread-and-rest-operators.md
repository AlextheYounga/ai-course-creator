# The Power of Spread and Rest Operators

Welcome to the exciting world of JavaScript ES6! In this section, we're going to delve into the powerful concepts of spread and rest operators. These are valuable tools that can greatly enhance your code and make your programming life much easier.

## Understanding Spread Operator

The spread operator, denoted by three dots (`...`), is a convenient way to expand elements of an array or properties of an object. It allows us to expand an iterable (like an array) into individual elements.

For example, imagine you have an array of fruits: 
```javascript
const fruits = ['apple', 'banana', 'orange'];
```

Now, using the spread operator, you can easily create a new array by adding more fruits to the original array, like this:
```javascript
const moreFruits = [...fruits, 'pineapple', 'mango'];
```

The `moreFruits` array will now contain all the fruits from the `fruits` array, plus the additional `"pineapple"` and `"mango"`.

## Applying Rest Operator

On the other hand, the rest operator, also represented by three dots (`...`), allows us to represent an indefinite number of arguments as an array. It captures multiple elements and converts them into an array.

Let's say we have a function that takes in a variable number of arguments and returns their sum. We can use the rest operator to capture all the arguments into an array, like this:
```javascript
function sum(...numbers) {
  return numbers.reduce((total, num) => total + num, 0);
}

const result = sum(1, 2, 3, 4, 5);
```

In this example, the `numbers` parameter in the `sum` function will capture all the values passed into the function and store them as an array. The `reduce` method then computes the sum of all the numbers.

## Interactive Component

## Multiple Choice
<div id="answerable-multiple-choice">
    <p id="question">What is the output of the following code?</p>
    <pre><code>const numbers = [1, 2, 3];
const moreNumbers = [...numbers, 4, 5, 6];
console.log(moreNumbers);</code></pre>
    <select id="choices">
        <option>[1, 2, 3, 4, 5, 6]</option>
        <option id="correct-answer">[1, 2, 3, 4, 5, 6]</option>
        <option>[1, 2, 3, [4, 5, 6]]</option>
        <option>Error</option>
    </select>
</div>

Great work! Understanding the spread and rest operators is crucial for writing concise and efficient code. These operators are widely used in modern JavaScript development and are vital for anyone working with frameworks like React, Vue, and Angular. So, let's dive deeper into using these operators to enhance your coding skills!