# Practice Skill Challenge for Classes and Modules

Congratulations on making it to the practice skill challenge for Classes and Modules! This is your chance to put your knowledge to the test and solidify your understanding of the concepts covered in this chapter.

## True/False

<div id="answerable-multiple-choice">
    <p id="question">In JavaScript, classes are merely syntactic sugar over the existing prototype-based inheritance.</p>
    <select id="choices">
        <option id="correct-answer">True</option>
        <option>False</option>
    </select>
</div>

## Coding Challenge

Now, let's dive into a coding challenge to reinforce what you've learned. Your task is to create a simple class using ES6 syntax.

```javascript
// Your code here
```

Your challenge is to create a class called `Car` with properties like `make`, `model`, and a method `startEngine()` that logs "Engine started" to the console.

## Multiple Choice

<div id="answerable-multiple-choice">
    <p id="question">Which keyword is used to import a module in ES6?</p>
    <select id="choices">
        <option>import</option>
        <option>require</option>
        <option>include</option>
        <option id="correct-answer">import</option>
    </select>
</div>

## Fill in the Blank

<div id="answerable-fill-blank">
    <p id="question">Modules in JavaScript help to keep code organized and ____________.</p>
    <p id="correct-answer">encapsulated</p>
</div>

By completing this practice skill challenge, you're not only solidifying your understanding of Classes and Modules in JavaScript, you're also preparing yourself to tackle real-world projects with confidence.

Now, go ahead and take on the challenge! Remember, practice makes perfect. Good luck!