# Practice skill challenge: Server-side JavaScript with Node.js

Congratulations on making it to the practice skill challenge! This is where you get to put your skills to the test and solidify your understanding of server-side JavaScript with Node.js. Don't worry, you've got this!

## Let's Get Started

Imagine you're building a simple weather application that fetches current weather data from a third-party API and displays it to the user. As part of this challenge, you'll be using Node.js to create a server that interacts with the API and serves the weather data to your application.

## Your Challenge

Your task is to write a Node.js program that creates a server, makes a request to a weather API, and then serves the retrieved weather data to a client.

### Coding Challenge
<div id="answerable-code-editor">
    <p id="question">Write a Node.js program that creates a server and sends a simple "Hello, World!" response to the client for any incoming request.</p>
    <p id="correct-answer"> 
    const http = require('http'); 
    const server = http.createServer((req, res) => { 
        res.writeHead(200, {'Content-Type': 'text/plain'}); 
        res.end('Hello, World!'); 
    }); 
    server.listen(3000, '127.0.0.1', () => {
        console.log('Server running at http://127.0.0.1:3000/');
    });
    </p>
</div>

Remember, in the real world, you'd be handling much more complex data and requests, but this is a foundational step in understanding how server-side JavaScript with Node.js can be used.

Once you've completed this challenge, you'll have a clearer understanding of how Node.js can be used to create powerful and efficient servers. Good luck, and happy coding!