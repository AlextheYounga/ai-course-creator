# Practice skill challenge: jQuery Fundamentals

Congratulations on reaching the practice skill challenge for jQuery fundamentals! This is where you get to put your knowledge to the test and solidify your understanding of the concepts we've covered so far. Don't worry, though; I'll be here to guide you through.

## Making Sense of jQuery

Imagine jQuery as a toolbox full of useful tools. Each tool has its unique purpose, making it easier for you to build and manipulate elements on your website. As we've learned, jQuery simplifies JavaScript code, making it more efficient and enjoyable to work with.

Now, let's dive into the challenge!

## Challenge #1:

What is the correct syntax to select an element with the id "example" using jQuery?

<div id="answerable-multiple-choice">
    <p id="question">What is the correct syntax to select an element with the id "example" using jQuery?</p>
    <select id="choices">
        <option>$("#example")</option>
        <option>$(.example)</option>
        <option id="correct-answer">$("#example")</option>
        <option>getElementById("example")</option>
    </select>
</div>

## Stretching Your jQuery Muscles

A real-world analogy for jQuery is like using a remote control to navigate a TV. You can change channels, adjust the volume, and switch on the power without having to walk up to the TV. Similarly, with jQuery, you can modify and manipulate elements on your webpage without having to write extensive lines of vanilla JavaScript code.

Now, let's move on to the next challenge.

## Challenge #2:

What jQuery method is used to hide an element on a webpage?

<div id="answerable-fill-blank">
    <p id="question">What jQuery method is used to hide an element on a webpage?</p>
    <p id="correct-answer">.hide()</p>
</div>

Keep up the great work, and remember, practice makes perfect!