Understanding Variables and Data Types

Welcome to the "Understanding Variables and Data Types" section of our JavaScript Fundamentals course! In this section, we'll dive into the building blocks of JavaScript and learn about one of the most fundamental concepts in programming: variables and data types.

### Variables: The Containers of Programming

Imagine variables as containers that hold different types of information. You can think of them as labeled boxes where you store different items. For example, you might have a box labeled "age" where you keep the value 25, and another labeled "name" where you keep the value "Alice."

In JavaScript, we use variables to store data that can be referenced and manipulated in our programs. These can be anything from numbers to text, boolean values, arrays, or even more complex objects.

### Data Types: Categorizing Information

Data in JavaScript can be classified into different types:

- **Numbers**: These are numeric values, like 42 or 3.14.
- **Strings**: Textual data enclosed in single or double quotes, such as "Hello, World!".
- **Booleans**: These represent logical values - true or false.
- **Arrays**: A collection of items, like a list.
- **Objects**: These can hold key-value pairs and represent more complex data structures.

### Declaring Variables and Assigning Values

To create a variable in JavaScript, we use the keyword "let" or "const" followed by the variable name and then assign a value to it using the "=" (assignment) operator.

For example:
```javascript
let userName = "Alice";
const userAge = 25;
```

Here, we've declared two variables: `userName` of type string and `userAge` of type number.

### Interactive Element

Let's reinforce what we've learned:

<div id="answerable-multiple-choice">
    <p id="question">Which keyword is used to declare a variable whose value cannot be reassigned?</p>
    <select id="choices">
        <option>var</option>
        <option>let</option>
        <option id="correct-answer">const</option>
        <option>def</option>
    </select>
</div>

Great! Understanding variables and data types is crucial for any JavaScript developer. It forms the foundation upon which all our future programs will be built. In the next section, we'll explore how to work with operators and expressions in JavaScript.