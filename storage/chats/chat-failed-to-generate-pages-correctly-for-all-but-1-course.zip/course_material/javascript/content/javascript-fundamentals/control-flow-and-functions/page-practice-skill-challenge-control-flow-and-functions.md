Alright, let's tackle the "Practice Skill Challenge: Control Flow and Functions" page. 

---

Great job getting this far! Now it's time to put your skills to the test with a skill challenge. You'll have the opportunity to apply your knowledge of control flow and functions in JavaScript. This will help reinforce everything you've learned and build your confidence in using these fundamental concepts.

Here's where the rubber meets the road. Are you ready?

## Practice Skill Challenge: Control Flow and Functions

### Question 1
What will the following code output?
```javascript
let num = 10;

if (num > 5) {
  console.log("Greater than 5");
} else {
  console.log("Less than or equal to 5");
}
```
<details>
  <summary>Click to see the correct answer</summary>
  The code will output: "Greater than 5"
</details>

### Question 2
Which of the following loops is more suitable when the number of iterations is known?
- for loop
- while loop
- do...while loop

### Question 3
Fill in the blank: A function in JavaScript is like a _______ in a recipe; it contains a set of instructions for performing a specific task.

### Question 4
What is the output of the following code?
```javascript
function greet(name) {
  console.log("Hello, " + name);
}

greet("Alice");
greet("Bob");
```
<details>
  <summary>Click to see the correct answer</summary>
  The output will be:
  ```
  Hello, Alice
  Hello, Bob
  ```
</details>

### Question 5
True or False: The "break" statement is used to terminate the current loop.

---
Well done! Take your time to carefully work through these questions. Each question is designed to reinforce a specific aspect of control flow and functions in JavaScript. Good luck!