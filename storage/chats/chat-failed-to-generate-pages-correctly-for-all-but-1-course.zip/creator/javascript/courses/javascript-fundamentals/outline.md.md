```json
[
    {
        "chapterName": "Basic Programming Concepts",
        "pages": [
            "Chapter Introduction Page - Welcome to Basic Programming Concepts",
            "Understanding basic programming concepts (variables, loops, functions)",
            "Understanding data types (strings, numbers, arrays, objects)",
            "Practice Skill Challenge - Basic Programming Concepts"
        ]
    },
    {
        "chapterName": "Control Flow and DOM",
        "pages": [
            "Chapter Introduction Page - Control Flow and the Document Object Model (DOM)",
            "Understanding control flow (if statements, switch statements)",
            "Understanding the Document Object Model (DOM)",
            "Practice Skill Challenge - Control Flow and DOM"
        ]
    }
]
```