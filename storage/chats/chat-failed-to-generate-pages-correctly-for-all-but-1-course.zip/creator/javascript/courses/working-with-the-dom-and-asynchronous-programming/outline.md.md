```json
[
    {
        "chapterName": "Working with the DOM",
        "pages": [
            "Introduction to Manipulating the DOM using JavaScript",
            "Selecting DOM Elements",
            "Modifying DOM Elements",
            "Creating and Removing DOM Elements",
            "Handling Events in the DOM",
            "Practice Skill Challenge - Working with the DOM"
        ]
    },
    {
        "chapterName": "Asynchronous Programming",
        "pages": [
            "Understanding Asynchronous Code in JavaScript",
            "Using Callbacks for Asynchronous Operations",
            "Working with Promises for Asynchronous Operations",
            "Chaining Promises and Handling Errors",
            "Async/Await Syntax for Asynchronous Operations",
            "Practice Skill Challenge - Asynchronous Programming"
        ]
    }
]
```