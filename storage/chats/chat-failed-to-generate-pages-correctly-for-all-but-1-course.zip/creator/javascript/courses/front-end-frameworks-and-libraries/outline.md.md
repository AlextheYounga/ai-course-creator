```json
[
    {
        "chapterName": "Client-Side Frameworks",
        "pages": [
            "Chapter Introduction: Welcome to Client-Side Frameworks",
            "What are Front-End Frameworks?",
            "Understanding React",
            "Understanding Angular",
            "Understanding Vue",
            "Practice Skill Challenge: Client-Side Frameworks"
        ]
    },
    {
        "chapterName": "Front-End Libraries",
        "pages": [
            "Chapter Introduction: Exploring Front-End Libraries",
            "Introduction to jQuery",
            "Utilizing jQuery for DOM Manipulation",
            "Introduction to lodash",
            "Managing Data with lodash",
            "Practice Skill Challenge: Front-End Libraries"
        ]
    }
]
```