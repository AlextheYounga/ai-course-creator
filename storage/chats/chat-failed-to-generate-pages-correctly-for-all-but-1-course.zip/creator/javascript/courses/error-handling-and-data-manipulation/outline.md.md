```json
[
    {
        "chapterName": "Error Handling and Debugging",
        "pages": [
            "Introduction to Error Handling and Debugging in JavaScript",
            "Understanding Common JavaScript Errors",
            "Strategies for Debugging and Troubleshooting JavaScript Code",
            "Practice Skill Challenge: Error Handling and Debugging Exercises"
        ]
    },
    {
        "chapterName": "Working with Data",
        "pages": [
            "Introduction to Working with Data in JavaScript",
            "Handling and Manipulating Arrays in JavaScript",
            "Understanding JSON and Working with JSON Data",
            "Practice Skill Challenge: Data Manipulation Exercises"
        ]
    }
]
```