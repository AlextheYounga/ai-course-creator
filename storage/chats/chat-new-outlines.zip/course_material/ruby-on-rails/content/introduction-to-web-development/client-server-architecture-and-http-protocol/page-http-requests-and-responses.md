# HTTP Requests and Responses

When you open a web page in your browser, a series of events occur behind the scenes to deliver the content to your screen. This process is driven by HTTP requests and responses. Let's dive into understanding how this exchange of information happens.

## Understanding HTTP Requests

Imagine you're at a restaurant, and you want to order your favorite dish. In this scenario, you are like the client, and the kitchen staff is like the server. When you place your order with the server, you are making a request. Similarly, when a web browser (the client) wants to access a web page, it sends an HTTP request to the server hosting the website.

HTTP requests consist of several components, including the request method, URL, headers, and sometimes a message body. The request method describes the action the client wants to perform, like GET to retrieve a resource or POST to submit data to the server.

Now, let's take a look at an example of an HTTP request:

```http
GET /example-page HTTP/1.1
Host: www.example.com
User-Agent: Mozilla/5.0
Accept: text/html
```

In this example:
- The request method is GET
- The URL being requested is "/example-page"
- The Host header specifies the domain
- The User-Agent header indicates the type of web browser making the request
- The Accept header specifies the type of content the client can accept

## Handling HTTP Responses

Once the server receives an HTTP request, it processes the request and generates an HTTP response. Continuing with the restaurant analogy, when the kitchen staff prepares your dish and brings it to your table, they are serving your order, which is like the server sending a response to the client.

HTTP responses contain information about the status of the request, along with the requested content. The status code is a three-digit number that gives a brief information about the outcome of the request. For example, a status code of 200 indicates that the request was successful, while a 404 status code indicates that the requested resource was not found.

Let's examine an example of an HTTP response:

```http
HTTP/1.1 200 OK
Content-Type: text/html
Content-Length: 1247

<!DOCTYPE html>
<html>
<head>
    <title>Welcome to Example Page</title>
</head>
<body>
    <h1>Hello, World!</h1>
    <p>This is an example page.</p>
</body>
</html>
```

In this example:
- The status code is 200 OK, indicating a successful response
- The Content-Type header specifies that the content is in HTML format
- The Content-Length header indicates the size of the content

## Interactive Component

### Multiple Choice

What does the status code "404" indicate in an HTTP response?

<select id="choices">
    <option>Request Timeout</option>
    <option id="correct-answer">Resource Not Found</option>
    <option>Server Error</option>
    <option>Document Moved</option>
</select>

By understanding how HTTP requests and responses work, developers can better optimize the performance and functionality of web applications. Keep this knowledge in mind as we move ahead to explore the intricacies of web development.