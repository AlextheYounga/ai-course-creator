# Recap and Quiz

Congratulations on making it through the material on understanding web technologies! Now, let's recap what we've learned and test your knowledge with a short quiz.

## Recap

We've covered the fundamental building blocks of the web, including the roles of HTML and CSS, and how web servers and browsers interact. Understanding these concepts is crucial for anyone looking to embark on a career in web development or anyone who simply wants to have a better understanding of how the internet works.

The combination of HTML and CSS can be likened to the structure and design of a house. HTML forms the foundation, providing the structure and layout, while CSS acts as the interior designer, adding colors, styles, and decorative elements.

On the other hand, the interaction between web servers and browsers can be thought of as a conversation between a client and a waiter at a restaurant. The client (browser) makes a request to the server (waiter), and the server responds by delivering the requested resources, just like the waiter bringing the food and drinks to the table.

## Quiz

### Multiple Choice

<div id="answerable-multiple-choice">
    <p id="question">What are the fundamental building blocks of the web?</p>
    <select id="choices">
        <option id="correct-answer">HTML, CSS, and JavaScript</option>
        <option>C++, Python, and Java</option>
        <option>Photoshop, Illustrator, and Sketch</option>
    </select>
</div>

### Fill in the Blank

<div id="answerable-fill-blank">
    <p id="question">HTML provides the _____ of a web page.</p>
    <p id="correct-answer">structure</p>
</div>

### Code Editor/Code Executor

<div id="answerable-code-editor">
    <p id="question">Write a simple CSS code to add a red background color to a website's header.</p>
    <p id="correct-answer">```css
    header {
        background-color: red;
    }
    ```</p>
</div>

Feel free to tackle the quiz to test your understanding. Good luck!