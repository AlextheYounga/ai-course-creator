# Working with Models in Rails

When working with Ruby on Rails, models are a fundamental part of the application. They represent the data and business logic of the application and are used to interact with the database. In this section, we'll explore how to work with models in Rails, including creating and using them to perform various operations.

## Understanding Models

Think of a model in Rails as a digital version of a real-world object. For example, if you were building an e-commerce website, you might have a `Product` model to represent the products you are selling. This model would store information such as the product name, price, and description. Just like how in the real world, a product might have attributes like name, price, and description.

## Creating a Model

In Rails, creating a model is relatively straightforward. You use the Rails generator to create a new model file, and Rails takes care of the heavy lifting, generating the necessary files and folder structure.

```ruby
rails generate model Product name:string price:decimal description:text
```

In this example, we're creating a `Product` model with attributes for `name`, `price`, and `description`. The `name:string`, `price:decimal`, and `description:text` are the data types of each attribute. It's similar to setting up the blueprint for the `Product` object in our digital e-commerce world.

## Querying the Database

Once the model is created, you can use it to perform various operations on the database, such as querying for specific data, creating new records, updating existing records, and deleting records. These operations can be performed using Rails' built-in methods, making it easy to interact with the database without writing raw SQL queries.

Now, let's put your knowledge to the test:

## Multiple Choice

What command would you use to generate a new model called `User` with attributes for `username` (string) and `email` (string)? 

<select id="choices">
    <option>rails g model User username:string email:string</option>
    <option id="correct-answer">rails generate model User username:string email:string</option>
    <option>rails model User username:string email:string</option>
    <option>rails make model User username:string email:string</option>
</select>

Remember, models in Rails are like the digital counterparts of real-world objects, helping us interact with the data in our application. Understanding how to create and work with models is essential for building robust and functional web applications.