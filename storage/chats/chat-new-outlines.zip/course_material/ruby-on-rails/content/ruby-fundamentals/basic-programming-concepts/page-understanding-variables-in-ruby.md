# Understanding Variables in Ruby

In Ruby, variables are like containers that hold data. Just imagine them as labeled boxes where you can store different types of things like numbers, words, or even whole sentences.

### Declaring Variables

When you declare a variable in Ruby, you're basically putting a label on a box and deciding what type of thing that box can hold. Let's take a look at an example:

```ruby
student_name = "Alex"
```

In this case, we've declared a variable called `student_name` and assigned the value "Alex" to it.

### Naming Conventions

In Ruby, variable names should start with a lowercase letter and use underscores to separate words. This convention is known as snake_case. 

### Data Types

Just like in real life, not all things can fit into the same type of box. In Ruby, we have different types of data that we can store in our variables:

- **Strings**: These are sequences of characters, like "Hello, World!".
- **Numbers**: These can be whole numbers, like 7, or decimal numbers, like 3.14.
- **Boolean**: This is a type that can only be one of two values: `true` or `false`.
- **Nil**: This represents "nothing" or "no value".

### Interactive Example

Let's test your understanding!

<div id="answerable-multiple-choice">
    <p id="question">Which naming convention is used for variables in Ruby?</p>
    <select id="choices">
        <option>pascalCase</option>
        <option>camelCase</option>
        <option id="correct-answer">snake_case</option>
        <option>kebab-case</option>
    </select>
</div>

Remember, understanding variables is fundamental to programming! It allows us to store and manipulate data, which is crucial in software development.

Now, armed with this knowledge, you're ready to explore how variables are used in real-world Ruby applications.