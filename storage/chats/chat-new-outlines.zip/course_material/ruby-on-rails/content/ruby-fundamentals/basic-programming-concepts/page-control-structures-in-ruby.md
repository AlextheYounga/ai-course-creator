### Control Structures in Ruby

Control structures are essential in programming as they allow us to dictate the flow of our code, making decisions, and repeating actions based on different conditions. In Ruby, control structures include if statements, case expressions, and loops. Let's dive into each of these and explore how they are used.

#### If Statements
Imagine you are creating a login system for a website. You want to display a personalized message to the user based on their subscription level. If the user is a premium member, you display a special welcome message; otherwise, you display a standard message. This is where if statements come into play.

```ruby
subscription_level = "premium"

if subscription_level == "premium"
  puts "Welcome, premium member!"
else
  puts "Welcome!"
end
```

In this example, the code checks if the `subscription_level` is "premium". If it is, it displays the special welcome message. If not, it displays the standard one.

Now, let's incorporate an interactive element.

## Multiple Choice
<div id="answerable-multiple-choice">
    <p id="question">What message will be displayed if the subscription level is "basic"?</p>
    <select id="choices">
        <option>Welcome, premium member!</option>
        <option id="correct-answer">Welcome!</option>
        <option>Invalid subscription level</option>
    </select>
</div>

#### Case Expressions
Case expressions are useful when you want to check multiple conditions. Just picture a vending machine. You have different choices, but based on the number you input, you get a different item. That's how case expressions function in Ruby.

```ruby
grade = "B"

case grade
when "A"
  puts "Excellent job!"
when "B"
  puts "Good work!"
else
  puts "Keep it up!"
end
```

The code checks the value of `grade` and then outputs a message based on the condition. If "B" is the grade, it outputs "Good work!".

#### Loops
Loops are like the repeat button on a music player. They allow you to execute a block of code multiple times. A common example is iterating through elements in an array.

```ruby
fruits = ["apple", "banana", "orange"]

fruits.each do |fruit|
  puts "I love #{fruit}s!"
end
```

In this example, the loop iterates through each fruit in the array and outputs "I love [fruit]s!".

Now, let's put our knowledge to the test with a coding challenge.

## Code Editor/Code Executor
<div id="answerable-code-editor">
    <p id="question">Write a program that outputs numbers from 1 to 5 using a loop in Ruby.</p>
    <p id="correct-answer">1
2
3
4
5</p>
</div>

Understanding control structures in Ruby is crucial for writing efficient and organized code. They provide the flexibility needed to handle different scenarios, making your code more dynamic and adaptable.