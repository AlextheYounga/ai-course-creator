# Exploring Data Types in Ruby

In programming, data types are essential because they tell the computer how to interpret and handle the data we use in our programs. Understanding data types is crucial for building robust and efficient code. In Ruby, a dynamic, object-oriented language, data types play a significant role. Let's dive into the different data types and their usage in Ruby.

## Numbers

Ruby supports integers and floating-point numbers for numeric values. Integers are whole numbers, while floating-point numbers can have decimal points. For example, `5` is an integer, and `3.14` is a floating-point number. Let's consider a scenario using numbers:

```ruby
# Calculating the area of a circle
radius = 5
area = Math::PI * (radius ** 2)
```

In this example, the variable `radius` holds an integer value, and the variable `area` will hold a floating-point number after the calculation, showcasing how different data types can be utilized in a real-world context.

## Strings

Strings are used to represent text in Ruby. They are enclosed in single or double quotes. For example, `"Hello, World!"` is a string. Let's consider a practical use case for strings:

```ruby
# Concatenating strings
first_name = "John"
last_name = "Doe"
full_name = first_name + " " + last_name
```

Here, the variables `first_name` and `last_name` store string values, and their concatenation results in the variable `full_name`, demonstrating the usage of strings in a simple context.

## Arrays

Arrays are used to store collections of items in Ruby. They can contain any combination of data types. For instance, `[1, 2, 3, 4]` is an array of integers, while `["apple", "banana", "cherry"]` is an array of strings. Let's explore a basic application of arrays:

```ruby
# Accessing elements in an array
fruits = ["apple", "banana", "cherry"]
second_fruit = fruits[1]
```

In this case, the variable `second_fruit` will contain the string `"banana"`, illustrating how arrays are used to store and access multiple values of the same or different data types.

Now, let's have a quick check on understanding data types in Ruby.

## Multiple Choice
<div id="answerable-multiple-choice">
    <p id="question">Which data type is suitable for representing text in Ruby?</p>
    <select id="choices">
        <option>Integers</option>
        <option id="correct-answer">Strings</option>
        <option>Floating-point numbers</option>
        <option>Arrays</option>
    </select>
</div>

Understanding data types in Ruby is fundamental to writing effective code. It allows developers to manipulate and utilize different kinds of data in their programs efficiently.