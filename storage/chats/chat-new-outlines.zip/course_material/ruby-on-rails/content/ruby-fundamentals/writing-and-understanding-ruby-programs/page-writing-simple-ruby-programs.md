# Writing Simple Ruby Programs

In the previous section, we started by getting to know the Ruby programming language. Now, it's time to roll up our sleeves and start writing some simple Ruby programs. Let's dive in!

## Variables and Data Types

In Ruby, just like in real life, we use variables to store information that can change. Imagine a variable as a container that holds different things at different times. For example, think of a box where you can put an apple, then a banana, and then a pair of socks. Similarly, a variable in Ruby can hold a number, a word, or even a whole list of things.

Here's an example of a simple Ruby program that uses variables and different data types:
```ruby
# Define a string variable
greeting = "Hello, world!"

# Define an integer variable
age = 25

# Output the value of the variables
puts greeting
puts age
```

That was easy, right? We used the `String` data type to store the greeting and the `Integer` data type to store the age.

Now, let's test your understanding with a quick question.

<div id="answerable-multiple-choice">
    <p id="question">Which data type was used to store the greeting in the example?</p>
    <select id="choices">
        <option id="correct-answer">String</option>
        <option>Integer</option>
        <option>Boolean</option>
        <option>Array</option>
    </select>
</div>

## Getting User Input

Sometimes we want our programs to interact with users. For instance, think of a vending machine that waits for you to make a selection. In Ruby, we can achieve this by getting input from the user using the `gets` method.

Let's see how it works in Ruby:
```ruby
# Ask the user to enter their name
print "What's your name? "
user_name = gets.chomp

# Greet the user
puts "Hello, #{user_name}! Nice to meet you."
```

In this example, the `gets.chomp` method is used to get the input from the user and remove the trailing newline character.

Now, it's time for a quick challenge!

<div id="answerable-fill-blank">
    <p id="question">What Ruby method is used to get input from the user and remove the trailing newline character?</p>
    <p id="correct-answer">gets.chomp</p>
</div>

Great job! Now you've learned how to work with variables, data types, and getting user input in Ruby. These are the building blocks for creating more complex and useful programs. Keep practicing and you'll be a Ruby pro in no time!