# Working with Embedded Ruby (ERB)

When we talk about web development with Ruby on Rails, it's essential to understand how to work with Embedded Ruby (ERB). ERB allows us to embed Ruby code within HTML, enabling us to create dynamic web pages. This means that we can seamlessly embed Ruby logic and data within our HTML, making our web pages interactive and responsive to user actions. 

Let's dip our toes into understanding how ERB works and its significance in Ruby on Rails.

## Understanding ERB Syntax

ERB uses `<% %>` and `<%= %>` tags to embed Ruby code within an HTML file. The `<% %>` tags are used for embedding Ruby logic, while the `<%= %>` tags are used for embedding Ruby expressions to output content.

For example, suppose we have a variable `name` in our Ruby code. We can embed it within an HTML file using ERB like this:

```erb
<!DOCTYPE html>
<html>
  <head>
    <title>Welcome</title>
  </head>
  <body>
    <h1>Welcome, <%= name %>!</h1>
  </body>
</html>
```

In this example, the `<%= name %>` tag will be replaced with the value of the `name` variable when the web page is rendered.

## Interactive Element

Let's test our understanding with a quick multiple choice question:

<div id="answerable-multiple-choice">
    <p id="question">What tags are used to embed Ruby expressions to output content in ERB?</p>
    <select id="choices">
        <option><% %></option>
        <option id="correct-answer"><%= %></option>
        <option><%# %></option>
        <option><& %></option>
    </select>
</div>

Understanding ERB is crucial for building dynamic and responsive web applications. Imagine you have an e-commerce application, and you want to personalize the shopping experience for each user by displaying their name on the homepage. Using ERB, you can easily embed Ruby code to achieve this level of customization.

In the next section, we'll delve deeper into creating dynamic content with ERB.

Now, let's take our ERB skills up a notch!