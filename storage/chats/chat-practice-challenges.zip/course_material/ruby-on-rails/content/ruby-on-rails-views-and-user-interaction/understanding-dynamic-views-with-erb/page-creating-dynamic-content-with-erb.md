### Dynamic Content with ERB

When it comes to web development, creating dynamic content is essential for building interactive and personalized user experiences. In the context of Ruby on Rails, Embedded Ruby (ERB) provides the tools to integrate dynamic content into your views. It allows you to embed Ruby code directly into your HTML files, making it seamless to generate dynamic content based on the underlying application logic.

Let's dive into the process of creating dynamic content with ERB.

#### Integrating Ruby Code into HTML

Imagine you have an e-commerce website where the displayed prices need to be dynamically adjusted based on the user's location. With ERB, you can embed Ruby code to fetch the user's location and then apply the corresponding price adjustments within your HTML template. This ensures that the displayed prices are always up-to-date and relevant to the user's context.

```html
<p>Welcome to our store! The current price for this item is <%= @item.price %>.</p>
```

In this example, `<%= @item.price %>` is the ERB syntax that allows you to embed Ruby code to fetch and display the current price.

#### Conditional Rendering

Consider a social media platform where user profiles are personalized based on their activity. Using ERB, you can incorporate conditional rendering to display different profile components based on the user's interaction history. For instance, you can show a "Recent Activity" section only if the user has engaged with the platform within the last 24 hours.

```html
<% if @user.recent_activity? %>
  <div class="recent-activity">
    <h3>Recent Activity</h3>
    <!-- Display recent activities here -->
  </div>
<% end %>
```

The `<% if @user.recent_activity? %>` and `<% end %>` tags allow you to conditionally render the "Recent Activity" section based on the user's activity status.

#### Interactive Element

Let's test your understanding of integrating Ruby code into HTML with ERB.

<div id="answerable-multiple-choice">
    <p id="question">Which of the following is the correct syntax to embed Ruby code into an HTML template using ERB?</p>
    <select id="choices">
        <option><%= code_here %></option>
        <option><%: code_here %></option>
        <option id="correct-answer"><%= code_here %></option>
        <option><%- code_here %></option>
    </select>
</div>

By mastering the art of creating dynamic content with ERB, you gain the ability to build engaging and responsive web applications that cater to diverse user needs and interactions.