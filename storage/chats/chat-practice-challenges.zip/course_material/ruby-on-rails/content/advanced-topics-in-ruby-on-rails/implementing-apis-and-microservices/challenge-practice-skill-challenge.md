# Practice Skill Challenge

## Question 1

**Multiple Choice**
<div id="answerable-multiple-choice">
    <p id="question">Which of the following is a common analogy to explain APIs?</p>
    <select id="choices">
        <option>Highway systems</option>
        <option id="correct-answer">Restaurant menus</option>
        <option>Human language translation</option>
        <option>Library card catalog</option>
    </select>
</div>

## Question 2

**Fill in the Blank**
<div id="answerable-fill-blank">
    <p id="question">Microservices are like a skilled team of specialists working together to accomplish a task, where each team member handles a specific _____.</p>
    <p id="correct-answer">task</p>
</div>

## Question 3

**Multiple Choice**
<div id="answerable-multiple-choice">
    <p id="question">What role do APIs play in software development?</p>
    <select id="choices">
        <option id="correct-answer">They allow different software systems to communicate with each other</option>
        <option>They design user interfaces</option>
        <option>They control hardware components</option>
        <option>They manage database structures</option>
    </select>
</div>

## Question 4

**Multiple Choice**
<div id="answerable-multiple-choice">
    <p id="question">What is one of the benefits of integrating microservices with Ruby on Rails?</p>
    <select id="choices">
        <option>Decreased modularity</option>
        <option id="correct-answer">Greater flexibility in technology choice</option>
        <option>Reduced communication overhead</option>
        <option>Isolation of services</option>
    </select>
</div>

## Question 5

**Fill in the Blank**
<div id="answerable-fill-blank">
    <p id="question">What is the keyword used to queue a job in Delayed::Job?</p>
    <p id="correct-answer">enqueue</p>
</div>

Great job completing the practice skill challenge! You've mastered the foundational concepts of APIs, microservices, asynchronous processing, background jobs, and third-party integrations in the context of Ruby on Rails. Keep up the excellent work!