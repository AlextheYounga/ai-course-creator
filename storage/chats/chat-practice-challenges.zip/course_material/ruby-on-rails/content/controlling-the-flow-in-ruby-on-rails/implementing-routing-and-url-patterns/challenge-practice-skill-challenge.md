# Practice Skill Challenge

## Question 1

What is the role of controllers in a Ruby on Rails application?

1. Handling user authentication
2. Directing incoming requests to the appropriate controller actions
3. Rendering views directly
4. Executing background jobs

## Question 2

What type of filter runs before the controller action is executed in Ruby on Rails?

1. After_action filter
2. Before_action filter
3. Around_filter
4. None of the above

## Question 3

What file do you need to modify in a Ruby on Rails application to enable session management?

## Question 4

Which of the following best describes Rails Helpers?

A. Elements that control access to web pages  
B. Reusable methods and logic for views  
C. Features that enhance database performance  
D. Modules used for routing requests  

## Question 5

What can cookies be used for in Ruby on Rails?

1. Only for storing static data
2. Maintaining session state
3. Handling server-side logic
4. Executing complex calculations

Submit your answers once you've completed all the questions!