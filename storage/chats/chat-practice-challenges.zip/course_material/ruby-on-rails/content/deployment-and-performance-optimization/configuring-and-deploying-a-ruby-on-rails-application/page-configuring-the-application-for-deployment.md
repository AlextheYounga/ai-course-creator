# Configuring the Application for Deployment

Now that we've set up Ruby on Rails for deployment, the next step is to configure our application for deployment. Think of it as preparing a dish for presentation after cooking it. You want to make sure that it looks appealing, is well-packaged, and can be easily served to your guests. Similarly, configuring the application for deployment involves optimizing it for the production environment, ensuring security measures, and implementing any necessary adjustments to make it perform efficiently.

## Environment Variables

One crucial aspect of configuring the application for deployment is managing environment variables. These are like secret ingredients that your application needs to function properly. However, you don't want to openly display these ingredients to everyone. Instead, you protect them and only reveal them to the authorized personnel.

In a Ruby on Rails application, you can manage environment-specific variables in the `config/secrets.yml` file. These variables might include API keys, database credentials, or any sensitive information that shouldn't be hardcoded into the application.

Let's say you have an API key for a payment gateway. You wouldn't want this key to be easily accessible in your codebase. Instead, you can store it as an environment variable and access it securely when needed.

```yaml
production:
  secret_key_base: <%= ENV["SECRET_KEY_BASE"] %>
  payment_gateway_api_key: <%= ENV["PAYMENT_API_KEY"] %>
```

### Quiz Time!
What is the purpose of managing environment variables in a Ruby on Rails application?

<div id="answerable-multiple-choice">
    <p id="question">What is the purpose of managing environment variables in a Ruby on Rails application?</p>
    <select id="choices">
        <option>To increase application complexity</option>
        <option id="correct-answer">To securely store sensitive information</option>
        <option>To share data with third-party services</option>
        <option>To reduce the application's scalability</option>
    </select>
</div>

## Database Configuration

Another critical part of preparing the application for deployment is configuring the database settings to align with the production environment. This involves ensuring that the production database is properly connected, secure, and optimized for the application's performance.

In the `config/database.yml` file, you can define separate database configurations for different environments such as development, test, and production. This allows you to tailor the database setup to suit the specific requirements of each environment.

By configuring the database appropriately, you ensure that the application can seamlessly interact with the production database and handle real-world traffic efficiently.

### Challenge Zone!
Complete the following line of code in the `database.yml` file by filling in the blank with the correct database adapter:
```yaml
production:
  adapter: <fill in the blank>
  database: production_db
  username: <%= ENV['DB_USERNAME'] %>
  password: <%= ENV['DB_PASSWORD'] %>
  host: localhost
```
<div id="answerable-fill-blank">
    <p id="question">Complete the following line of code in the `database.yml` file: `adapter: <fill in the blank>`</p>
    <p id="correct-answer">postgresql</p>
</div>

In the next section, we'll learn about the essential steps involved in deploying the Ruby on Rails application to a web server.