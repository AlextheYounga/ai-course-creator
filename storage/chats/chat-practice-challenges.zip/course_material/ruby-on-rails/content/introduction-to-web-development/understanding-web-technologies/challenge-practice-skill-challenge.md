# Practice Skill Challenge

Great! Now that we've covered the fundamental concepts of web development and Ruby on Rails, it's time to test your understanding with some practice problems. Try your hand at the following questions to reinforce your learning.

## Question 1
### Multiple Choice
What is the primary purpose of HTML in web development?
- Styling the website
- Adding interactivity
- Defining the structure and content of the web page
- Managing server-side operations

## Question 2
### Fill in the Blank
Create a hash called "book" containing the keys "title", "author", and "year" with corresponding values for a book of your choice.

## Question 3
### Multiple Choice
Which of the following is a data type in programming?
- Toolbox
- Integer
- Recipe
- Jar

## Question 4
### Code Editor/Code Executor
Create an array called "months_of_year" containing the names of the months.

## Question 5
### Multiple Choice
What helper method is used to create a form in Ruby on Rails?
- form_tag
- form_for
- input_form
- submit_form

Test your skills by attempting these questions. Once you're ready, you can check your answers below. Good luck!