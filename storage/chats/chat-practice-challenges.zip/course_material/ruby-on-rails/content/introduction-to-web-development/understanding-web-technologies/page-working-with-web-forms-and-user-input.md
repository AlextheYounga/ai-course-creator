# Working with Web Forms and User Input

When you use a website to create an account, fill out a survey, or buy something online, you're interacting with web forms. Web forms are crucial for collecting user input, and they are an essential part of web development. In this section, we'll explore how to work with web forms and user input in the context of Ruby on Rails.

## Understanding User Input

Imagine a physical suggestion box placed in the lobby of a company's office. People can write down their suggestions on pieces of paper and drop them into the box. Later, someone empties the box and reads the suggestions. This is similar to how web forms work on a website. Users input their information, such as their name, email, or feedback, and this information is submitted to the web server for processing.

In web development, we use web forms to collect various types of user input, from simple text to file uploads. This input is then processed by the server to perform actions like registering a user, submitting a comment, or making a purchase.

## Building a Simple Form

Let's take a look at a basic example of how to create a form in Ruby on Rails. Below is an example of a form to collect a user's feedback on a website:

```ruby
<%= form_for @feedback do |f| %>
  <div class="field">
    <%= f.label :comment %>
    <%= f.text_area :comment %>
  </div>
  
  <div class="actions">
    <%= f.submit %>
  </div>
<% end %>
```

In this example, `form_for` is a Rails helper method that creates a form for a specific object (in this case, the `@feedback` object). The form includes a text area for the user to type their feedback and a submit button to send the feedback to the server.

## Handling User Input

Once the user submits the form, the input is sent to the server for processing. In Ruby on Rails, we can access the submitted data through the `params` hash. For example, if the form input is stored in a `feedback` table, we can access the user's comment using `params[:feedback][:comment]`.

This user input can then be validated, processed, and stored in a database or used for various actions within the web application.

Now, let's check our understanding about working with web forms and user input.

## Question Time!

<div id="answerable-multiple-choice">
    <p id="question">What helper method is used to create a form in Ruby on Rails?</p>
    <select id="choices">
        <option>form_tag</option>
        <option id="correct-answer">form_for</option>
        <option>input_form</option>
        <option>submit_form</option>
    </select>
</div>

By understanding how to work with web forms and user input, you'll be able to create interactive and user-friendly web applications that can collect and process information from users effectively.