# Practice Skill Challenge

## Question 1

Using a version manager like RVM or rbenv allows you to:
A) Uninstall Ruby from the machine
B) Delete all Ruby applications
C) Install and manage multiple versions of Ruby
D) Write Ruby code

## Question 2

What command do you use to install Rails?
A) gem install ruby
B) gem install rails
C) rails install
D) ruby install rails

## Question 3

What is the main reason for learning how to set up Ruby on Rails?
A) It's a fun programming language
B) Ruby on Rails is widely used in the industry
C) To develop robust web applications
D) It's a requirement for all developers

## Question 4

What is the role of the Model in the MVC pattern?
A) Manages user interactions
B) Presents the user interface
C) Encapsulates data and its manipulation logic
D) Acts as the mediator between the Model and the View

## Question 5

What can the Rails console help you with?
A) Visual design
B) Database management
C) Testing and debugging
D) User interface development

Let's test your knowledge! Select the correct answers to the questions above.