# Creating a New Ruby on Rails Application

When it comes to creating a new Ruby on Rails application, it's like building a new, customized car from scratch. You have the power to choose the color, the features, and the overall design. Similarly, with Ruby on Rails, you can tailor your application to meet the specific needs of your project.

## Setting Up the Basics

Before we dive into coding, we need to make sure we have the necessary tools. In the world of Ruby on Rails, a popular gem known as "Rails" provides us with the framework to build web applications. It's like having a set of high-quality tools in your garage, specifically designed for building cars.

Let's assume you already have Ruby and RubyGems installed. If not, make sure to do that first. Once you have Ruby and RubyGems, you can install Rails using the command: 

```bash
gem install rails
```

This command will fetch and install the Rails gem along with its dependencies. 

Now that we have Rails installed, we can proceed to create our new application.

## Creating the Application

To create a new Ruby on Rails application, we use the following command in the terminal:

```bash
rails new myapp
```

In this command, "myapp" is the name you choose for your application. It's like naming your custom-built car. The "rails new" command generates all the files and folders necessary to start building your application.

Once the command is executed, Rails creates the application structure, installs all the required dependencies, and sets up a basic working environment for your project.

Now, let's put your knowledge to the test.

<div id="answerable-multiple-choice">
    <p id="question">What command do you use to install Rails?</p>
    <select id="choices">
        <option>gem install ruby</option>
        <option id="correct-answer">gem install rails</option>
        <option>rails install</option>
        <option>ruby install rails</option>
    </select>
</div>

Now that you know how to set up a new Ruby on Rails application, let's move on to the exciting part - actually building something amazing!

Remember, just like a car, your Rails application can take you on incredible journeys in the world of technology.