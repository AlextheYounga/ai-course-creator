## Practice Skill Challenge

Great job learning about user authentication, managing user roles and permissions, and securing sensitive information in Ruby on Rails applications! Now, let's put your knowledge to the test with these practice problems.

### Question 1

**Fill in the Blank**

What gem can be used in Ruby on Rails to easily encrypt sensitive data?

<details>
  <summary>Click to reveal the answer</summary>
  The correct answer is "attr_encrypted".
</details>

### Question 2

**Multiple Choice**

What method can be used to convert user passwords into an irreversible scrambled string in Ruby on Rails?

1. Encryption
2. Hashing
3. Salting
4. Encoding

<details>
  <summary>Click to reveal the answer</summary>
  The correct answer is "Hashing".
</details>

### Question 3

**Multiple Choice**

Which method adds an extra layer of security by requiring users to provide a second form of identification?

<details>
  <summary>Click to reveal the answer</summary>
  The correct answer is "Two-Factor Authentication (2FA)".
</details>

### Question 4

**Fill in the Blank**

Write a program that calculates 10 multiplied by 5

<details>
  <summary>Click to reveal the answer</summary>
  The correct answer is "50".
</details>

### Question 5

**Multiple Choice**

What does Devise provide for authentication in Ruby on Rails?

1. User registration and session management
2. All of the above
3. Password reset
4. None of the above

<details>
  <summary>Click to reveal the answer</summary>
  The correct answer is "All of the above".
</details>

Great work! You're well on your way to mastering user authentication and security in Ruby on Rails. Keep practicing to reinforce your understanding.