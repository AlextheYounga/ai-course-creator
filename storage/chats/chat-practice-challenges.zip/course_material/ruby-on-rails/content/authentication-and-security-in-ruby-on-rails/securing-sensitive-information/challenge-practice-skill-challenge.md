Certainly! Here's the "Practice Skill Challenge" page with 5 practice problems testing your understanding of the materials provided:

---

# Practice Skill Challenge

Great job learning about user authentication, managing user roles and permissions, and securing sensitive information in Ruby on Rails applications! Now, let's put your knowledge to the test with these practice problems.

### Question 1

**Fill in the Blank**

<div id="answerable-fill-blank">
    <p id="question">What gem can be used in Ruby on Rails to easily encrypt sensitive data?</p>
    <p id="correct-answer">attr_encrypted</p>
</div>

<details>
  <summary>Click to reveal the answer</summary>
  The correct answer is "attr_encrypted".
</details>

### Question 2

**Multiple Choice**

<div id="answerable-multiple-choice">
    <p id="question">What method can be used to convert user passwords into an irreversible scrambled string in Ruby on Rails?</p>
    <select id="choices">
        <option>Encryption</option>
        <option id="correct-answer">Hashing</option>
        <option>Salting</option>
        <option>Encoding</option>
    </select>
</div>

<details>
  <summary>Click to reveal the answer</summary>
  The correct answer is "Hashing".
</details>

### Question 3

**Multiple Choice**

<div id="answerable-multiple-choice">
    <p id="question">Which method adds an extra layer of security by requiring users to provide a second form of identification?</p>
    <select id="choices">
        <option>Username and Password</option>
        <option id="correct-answer">Two-Factor Authentication (2FA)</option>
        <option>Single Sign-On (SSO)</option>
    </select>
</div>

<details>
  <summary>Click to reveal the answer</summary>
  The correct answer is "Two-Factor Authentication (2FA)".
</details>

### Question 4

**Fill in the Blank**

<div id="answerable-code-editor">
    <p id="question">Write a program that calculates 10 multiplied by 5</p>
    <p id="correct-answer">50</p>
</div>

<details>
  <summary>Click to reveal the answer</summary>
  The correct answer is "50".
</details>

### Question 5

**Multiple Choice**

<div id="answerable-multiple-choice">
    <p id="question">What does Devise provide for authentication in Ruby on Rails?</p>
    <select id="choices">
        <option>User registration and session management</option>
        <option id="correct-answer">All of the above</option>
        <option>Password reset</option>
        <option>None of the above</option>
    </select>
</div>

<details>
  <summary>Click to reveal the answer</summary>
  The correct answer is "All of the above".
</details>

Great work! You're well on your way to mastering user authentication and security in Ruby on Rails. Keep practicing to reinforce your understanding.

---