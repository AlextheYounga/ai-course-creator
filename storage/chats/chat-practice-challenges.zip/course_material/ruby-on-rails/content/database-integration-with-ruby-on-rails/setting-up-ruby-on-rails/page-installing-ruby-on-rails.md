# Installing Ruby on Rails

When it comes to working with Ruby on Rails, the first step is to ensure that you have Ruby and Rails installed on your system. In this section, we'll walk through the process of installing Ruby and Rails so that you can start building amazing web applications.

## Checking Your Ruby Installation

Before diving into Rails, it's important to check if you have Ruby installed. You can do this by opening a terminal and running the following command:

```bash
ruby -v
```

If you see a version number in the output, then Ruby is already installed. If not, you'll need to download and install Ruby before proceeding with Rails.

## Installing Ruby Version Manager (RVM)

One convenient way to manage different versions of Ruby on your system is by using Ruby Version Manager (RVM). This tool allows you to easily switch between different Ruby versions and gemsets.

To install RVM, you can use the following command:

```bash
\curl -sSL https://get.rvm.io | bash -s stable
```
Once RVM is installed, you can use it to install a specific version of Ruby, for example:

```bash
rvm install ruby-3.0.1
```

## Installing Ruby on Rails

Once you have Ruby set up, installing Rails is a breeze. Use the following command to install the latest version of Rails:

```bash
gem install rails
```

Now, you can verify the Rails installation by running:

```bash
rails -v
```

If the installation was successful, this command should display the version of Rails you just installed.

## Interactive Component

<div id="answerable-multiple-choice">
    <p id="question">Which command do you use to install the latest version of Rails?</p>
    <select id="choices">
        <option>rails install latest</option>
        <option id="correct-answer">gem install rails</option>
        <option>install latest version</option>
        <option>install rails latest</option>
    </select>
</div>

Now that we have Ruby and Rails installed, we're ready to dive into creating a new Ruby on Rails application in the next section!