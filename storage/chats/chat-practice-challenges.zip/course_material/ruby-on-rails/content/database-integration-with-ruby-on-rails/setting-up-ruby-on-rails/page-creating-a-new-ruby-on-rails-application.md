# Creating a New Ruby on Rails Application

When starting a new project in Ruby on Rails, creating a new application is the first step. Think of it like laying the foundation for a house before you start building it. 

To create a new Ruby on Rails application, open your terminal and navigate to the directory where you want to create the application. Once you're in the desired directory, use the `rails new` command followed by the name of your application. 

```bash
rails new my_new_app
```

In this example, we're naming our application "my_new_app," but you can substitute that with the name of your choice. 

One important thing to consider when creating a new Rails application is the database you'll be using. By default, Rails uses SQLite3 for development, but you can specify a different database like PostgreSQL or MySQL by adding the `-d` flag followed by the name of the database. For instance:

```bash
rails new my_new_app -d postgresql
```

This command tells Rails to set up the application to use PostgreSQL as the database. 

Why is this important? Well, different databases have different strengths and weaknesses. PostgreSQL, for example, is known for its reliability and robustness, making it a popular choice for production applications. Understanding this from the start allows you to set up your application for success.

After running the `rails new` command, Rails will generate all the necessary files and directories for your new application. It will also set up the default database and install any required dependencies using Bundler.

Remember, setting up a new Rails application is like preparing the workspace for a new project. It creates the structure and environment for your application to grow and thrive.

Now, let's dive into an interactive challenge to reinforce what we've learned.

## Multiple Choice

What is the default database that Rails uses for development?

<select id="choices">
    <option>SQLite3</option>
    <option id="correct-answer">PostgreSQL</option>
    <option>MySQL</option>
    <option>SQL Server</option>
</select>