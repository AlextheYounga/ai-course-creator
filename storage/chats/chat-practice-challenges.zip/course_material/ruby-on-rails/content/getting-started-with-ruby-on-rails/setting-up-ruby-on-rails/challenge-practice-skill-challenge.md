# Practice Skill Challenge

Now that you've explored the key concepts of Ruby on Rails, it's time to put your understanding to the test with the following practice problems.

## Practice Problem 1
### Multiple Choice
<div id="answerable-multiple-choice">
    <p id="question">What command do you use to open the Rails console?</p>
    <select id="choices">
        <option>ruby on_rails</option>
        <option id="correct-answer">rails console</option>
        <option>rails start</option>
        <option>ruby interact</option>
    </select>
</div>

## Practice Problem 2
### Fill in the Blank
<div id="answerable-fill-blank">
    <p id="question">The Controller in the MVC pattern acts as the _______ between the Model and the View.</p>
    <p id="correct-answer">intermediary</p>
</div>

## Practice Problem 3
### Multiple Choice
To install Ruby on Rails, which command do you use with the RubyGems package manager?
<div id="answerable-multiple-choice">
    <p id="question">Which command is used to install Rails with RubyGems?</p>
    <select id="choices">
        <option>gem install ruby</option>
        <option id="correct-answer">gem install rails</option>
        <option>rails install</option>
        <option>ruby install rails</option>
    </select>
</div>

## Practice Problem 4
### Fill in the Blank
<div id="answerable-fill-blank">
    <p id="question">What component of the MVC pattern represents the underlying data structure of the application?</p>
    <p id="correct-answer">Model</p>
</div>

## Practice Problem 5
### Multiple Choice
<div id="answerable-multiple-choice">
    <p id="question">Which component of the MVC pattern represents the user interface?</p>
    <select id="choices">
        <option>Model</option>
        <option>View</option>
        <option id="correct-answer">Controller</option>
    </select>
</div>


Great job! Take your time to answer each question. Once you've completed the challenge, you'll have a stronger grasp of the fundamental concepts of Ruby on Rails.