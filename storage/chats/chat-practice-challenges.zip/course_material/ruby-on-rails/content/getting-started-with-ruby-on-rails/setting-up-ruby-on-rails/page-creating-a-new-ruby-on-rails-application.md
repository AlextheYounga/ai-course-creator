# Creating a New Ruby on Rails Application

When you're ready to start building a web application using Ruby on Rails, it's time to create a new project. In this section, we'll walk through the steps to create a new Ruby on Rails application from scratch.

## Getting Started
Imagine you're starting a new business and you want to build a professional website to showcase your products or services. You've heard that Ruby on Rails is a great framework for developing web applications quickly and efficiently. So, you've decided to use Ruby on Rails to create your business's website.

Now, let's dive into the process of creating a new Ruby on Rails application.

## Using the Command Line
In Ruby on Rails, we use the command line to create a new application. Open your terminal or command prompt and navigate to the directory where you want to create your new project.

Now, let's type the following command to create a new Rails application:

```bash
rails new my_business_website
```

In this command:
- `rails` is the command-line tool for creating and working with Rails applications.
- `new` is the subcommand for creating a new Rails application.
- `my_business_website` is the name of the new application.

## Configuring the Application
Once you run the command, Ruby on Rails will create all the necessary files and folders for your new application. It will also add the required configurations and dependencies to get your project up and running.

After the command finishes executing, you'll see a new directory called `my_business_website` containing all the files for your new Ruby on Rails application.

Congratulations! You've just created a new Ruby on Rails application.

Now, let's check your understanding with a quick question:

## Multiple Choice
<div id="answerable-multiple-choice">
    <p id="question">What is the command to create a new Ruby on Rails application?</p>
    <select id="choices">
        <option>rails generate my_business_website</option>
        <option id="correct-answer">rails new my_business_website</option>
        <option>rails build my_business_website</option>
        <option>rails create my_business_website</option>
    </select>
</div>

Understanding how to create a new Ruby on Rails application is a fundamental skill for any web developer using this powerful framework. Now that you have your project set up, you're ready to start building and designing your website.