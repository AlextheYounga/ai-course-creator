---
title: "While Loops: The Power of Condition-Based Iteration"
---

Imagine you're listening to your favorite playlist, and you want the music to keep playing as long as you're still awake. You wouldn't want it to stop after just three songs if you're planning to stay up all night, right? In the coding world, when you need a process to repeat as long as a certain condition holds true, you'd typically use a `while` loop.

A `while` loop in Python continually executes a block of code as long as a given condition is true. It's like telling your playlist, "Keep playing music **while** my eyes are open." The moment your eyes close, the playlist stops—this is the essence of condition-based iteration.

For example, let's say we're programming a simple game. We want the game to run as long as the player has more than 0 health points. Here's how that might look in Python:

```python
player_health = 10

while player_health > 0:
    # Game logic goes here
    # ...
    # Let's say the player loses 1 health point per round
    player_health -= 1
```

With this loop, the game would continue to run for 10 rounds, as the player loses one health point per round. Once `player_health` drops to 0, the condition `player_health > 0` is no longer true, so the loop stops and the game ends.

`While` loops are also great for reading through data when you don't know in advance how much data there will be. Imagine you've got a box of chocolates: you keep taking one out **while** there are still chocolates left in the box. In Python, instead of chocolates, there might be lines in a file or items in a list.

But here's a crucial piece of advice: always ensure that your while loop has a way to break out. Otherwise, you might end up with an infinite loop, kind of like being stuck in a time loop, doing the same thing over and over until the end of time—or until you force your program to stop, which is slightly less dramatic.

Now, it's your turn! Let's imagine we're creating a countdown for a rocket launch. We want to display each number starting from 5 and count down to 0, and then print "Liftoff!" Implement this countdown using a `while` loop in Python.

<div id="answerable-code-editor">
    <p id="question">Write a Python `while` loop that counts down from 5 and prints each number. When the countdown reaches 0, print "Liftoff!"</p>
    <p id="correct-answer"># You can use the following code snippet as a starting point:

count = 5
while count > 0:
    print(count)
    count -= 1
print("Liftoff!")
</p>
</div>

`While` loops are powerful tools in a programmer's arsenal, allowing for repetitive actions based on dynamic conditions—perfect for when the number of iterations needed isn't known from the outset. They're an essential construct used in all sorts of applications, from simple automation tasks to complex game development. By mastering `while` loops, you're truly unlocking a fundamental skill in Python programming. Make sure to design your loops wisely to keep your code efficient and avoid the dreaded infinite loop!