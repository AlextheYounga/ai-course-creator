# Practice Skill Challenge: Asynchronous JavaScript Mastery

## Problem 1: Crafting a Simple Promise

The essence of a Promise in JavaScript is its ability to represent a future value. Let's start with the basics - create a promise that will resolve to the string `'I am a Promise!'` after a delay of 2 seconds. Recall that you can use the `setTimeout` function to create this delay.

<div id="answerable-code-editor">
    <p id="question">Create a promise that resolves with the string <code>'I am a Promise!'</code> after a 2-second delay.</p>
    <p id="correct-answer">// Correct Code:
const simplePromise = new Promise((resolve, reject) => {
    setTimeout(() => {
        resolve('I am a Promise!');
    }, 2000);
});</p>
</div>

## Problem 2: Identifying Promise States

Promises have three distinct states: pending, fulfilled, and rejected. Given that `const examplePromise = new Promise((resolve, reject) => { ... });` is a newly created Promise object, what is the initial state of `examplePromise`?

<div id="answerable-multiple-choice">
    <p id="question">What is the initial state of a newly created Promise object before it is resolved or rejected?</p>
    <select id="choices">
        <option>Fulfilled</option>
        <option id="correct-answer">Pending</option>
        <option>Rejected</option>
        <option>Completed</option>
    </select>
</div>

## Problem 3: Handling Rejections with .catch()

Suppose the function `fetchDataFromServer()` returns a promise that either resolves with data or rejects with the error `'Network Error'`. How would you handle the rejection case to log the error message `'There was a problem with the request.'`?

<div id="answerable-code-editor">
    <p id="question">Write code to handle rejection from the promise returned by <code>fetchDataFromServer()</code> and log a specified error message.</p>
    <p id="correct-answer">// Correct Code:
fetchDataFromServer().catch(error => {
    console.log('There was a problem with the request.');
});</p>
</div>

## Problem 4: Asynchronous Functions with Async/Await

An `async` function implicitly returns a promise and allows you to write code using `await` to handle this promise without using `.then()`. Given a function `getUserProfile()` that returns a promise resolving with user profile data, write an `async` function named `displayUserProfile()` that tries to log the user profile data received from `getUserProfile()`.

<div id="answerable-code-editor">
    <p id="question">Use `async/await` syntax in the function <code>displayUserProfile</code> to get the user profile data from <code>getUserProfile()</code>.</p>
    <p id="correct-answer">// Correct Code:
async function displayUserProfile() {
    try {
        const profileData = await getUserProfile();
        console.log(profileData);
    } catch (error) {
        console.error('Error:', error);
    }
}</p>
</div>

## Problem 5: Chaining Multiple Promises

When we have a series of asynchronous operations that need to be performed one after another, we can chain promises. Suppose we have three asynchronous functions: `fetchUser()`, `processUserData()`, and `saveUserProgress()`. These functions return promises for their respective operations. Chain these functions together to handle the data accordingly.

<div id="answerable-code-editor">
    <p id="question">Chain the functions <code>fetchUser</code>, <code>processUserData</code>, and <code>saveUserProgress</code> using promise chaining.</p>
    <p id="correct-answer">// Correct Code:
fetchUser()
    .then(user => processUserData(user))
    .then(userData => saveUserProgress(userData))
    .catch(error => console.error('Error in promise chain:', error));
</p>
</div>

Take these problems as opportunities to flex your asynchronous JavaScript muscles and solidify your understanding of Promises, `async/await`, and error handling in JavaScript. Keep practicing, and you'll be able to write more functional and robust code for your future projects!