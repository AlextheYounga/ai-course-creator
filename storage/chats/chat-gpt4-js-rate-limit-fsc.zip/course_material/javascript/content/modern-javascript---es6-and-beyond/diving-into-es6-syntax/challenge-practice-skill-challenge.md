# Practice Skill Challenge

Now that we've explored some of the exciting features of ES6, it's time to put your newfound knowledge to the test. Below are five practice problems designed to assess your understanding of the concepts we've covered in our course. Each problem will challenge you to apply what you've learned in a practical scenario. Ready to flex those JavaScript muscles? Let's begin!

### Problem 1: Variable Scoping with `let`
When using `let`, variables are scoped to the block in which they are defined. Given this understanding, what will the following code output to the console?

```javascript
let fruit = 'apple';
if (true) {
    let fruit = 'banana';
}
console.log(fruit);
```

<div id="answerable-multiple-choice">
    <p id="question">What will the console output be?</p>
    <select id="choices">
        <option id="correct-answer">apple</option>
        <option>banana</option>
        <option>undefined</option>
        <option>ReferenceError</option>
    </select>
</div>

### Problem 2: Arrow Function Syntax
Arrow functions simplify function expressions and solve certain quirks with the `this` keyword. Can you rewrite the function below to use arrow function syntax correctly?

<div id="answerable-code-editor">
    <p id="question">Rewrite the following traditional function as an arrow function:</p>
```javascript
function sayHello(name) {
   return 'Hello, ' + name + '!';
}
```
    <p id="correct-answer">const sayHello = name => 'Hello, ' + name + '!';</p>
</div>

### Problem 3: String Interpolation with Template Literals
Using template literals, you can embed expressions into strings which makes code more readable and easier to work with. Generate a greeting message using template literals and the provided variables.

```javascript
const username = 'Morgan';
const day = 'Wednesday';
```

<div id="answerable-code-editor">
    <p id="question">Create a greeting message that says "Hello, Morgan! Happy Wednesday!" using template literals.</p>
    <p id="correct-answer">`Hello, ${username}! Happy ${day}!`</p>
</div>

### Problem 4: Block-Scoped Variables with `const`
Variables declared with `const` are also block-scoped, similar to those declared with `let`. Consider the code snippet below and decide what will be logged to the console.

```javascript
const pet = 'cat';
function showPet() {
    const pet = 'dog';
    console.log(pet);
}
showPet();
console.log(pet);
```

<div id="answerable-multiple-choice">
    <p id="question">What will be logged to the console after this code runs?</p>
    <select id="choices">
        <option>'dog' and then 'cat'</option>
        <option id="correct-answer">'dog' and then 'dog'</option>
        <option>'cat' and then 'cat'</option>
        <option>'cat' and then 'dog'</option>
    </select>
</div>

### Problem 5: Conciseness in Objects
ES6 introduces syntax that allows us to write more concise object literal properties and methods. Take the object below and refactor it using concise properties and method syntax.

```javascript
const book = {
    title: title,
    author: author,
    summary: function() {
        return this.title + ' written by ' + this.author;
    }
};
```

<div id="answerable-code-editor">
    <p id="question">Refactor the object to use concise properties and methods of ES6.</p>
    <p id="correct-answer">
const book = {
    title,
    author,
    summary() {
        return `${this.title} written by ${this.author}`;
    }
};
    </p>
</div>

Ready to see how you did? Go through each problem, apply your knowledge of ES6, and see your results. Keep practicing to sharpen those skills and deepen your understanding of JavaScript's ES6 features. Great job on completing these practice problems!