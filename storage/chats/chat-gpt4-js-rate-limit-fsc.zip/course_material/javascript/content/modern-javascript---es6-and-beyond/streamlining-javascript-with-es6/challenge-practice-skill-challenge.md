# Practice Skill Challenge

Welcome to the Practice Skill Challenge! Here you'll apply what you've learned about JavaScript ES6 features through practical problems. Remember, these questions are designed to test your understanding of destructuring, spread syntax, rest parameters, iterators, generators, and modules. Read each problem carefully and select or provide the correct answer to the best of your ability. Good luck!

### Problem 1: Destructuring Objects

You've been given an object that contains information about a social media profile. Using destructuring, create variables to extract the username and the platform.

```javascript
const socialMedia = {
    username: "tech_genius",
    platform: "Twitter",
    followers: 2500
};
```

<div id="answerable-code-editor">
    <p id="question">Write the code that destructures the socialMedia object to extract the username and the platform.</p>
    <p id="correct-answer">const { username, platform } = socialMedia;</p>
</div>

### Problem 2: Using Spread Syntax

Assume we have two arrays, one with front-end development languages and the other with back-end development languages. We want to merge these two arrays into a new array called `fullStackLanguages`.

```javascript
const frontEnd = ['HTML', 'CSS', 'JavaScript'];
const backEnd = ['Node.js', 'Python', 'Ruby'];
```

<div id="answerable-code-editor">
    <p id="question">Write the code that uses spread syntax to create a new array called fullStackLanguages.</p>
    <p id="correct-answer">const fullStackLanguages = [...frontEnd, ...backEnd];</p>
</div>

### Problem 3: Working with Rest Parameters

You are creating a versatile utility function that concatenates any given strings into a single message. Implement this function using rest parameters to accept an indefinite number of strings.

<div id="answerable-code-editor">
    <p id="question">Write the function that uses rest parameters to concatenate strings into a single message.</p>
    <p id="correct-answer">function concatStrings(...strings) {
    return strings.join(' ');
}</p>
</div>

### Problem 4: Iterating With Generators

Use a generator function to create an iterator over an array of tech gadgets. The array is defined below. Each call to `next()` should return the next gadget in the list.

```javascript
const gadgets = ['Smartphone', 'Laptop', 'Tablet', 'Smartwatch', 'Drone'];
```

<div id="answerable-code-editor">
    <p id="question">Write a generator function named gadgetGenerator that yields each gadget.</p>
    <p id="correct-answer">function* gadgetGenerator() {
    for (let gadget of gadgets) {
        yield gadget;
    }
}</p>
</div>

### Problem 5: Importing Modules

Given three module files named `add.js`, `subtract.js`, and `multiply.js`, each exporting a single function with the same name as the file (e.g., `add`), write the `import` statement to use these functions in your main program file, `calculator.js`, ensuring to prevent name conflicts.

<div id="answerable-code-editor">
    <p id="question">Write the import statement required to include the add, subtract, and multiply functions in the calculator.js file.</p>
    <p id="correct-answer">import { add } from './add.js';
import { subtract } from './subtract.js';
import { multiply } from './multiply.js';</p>
</div>

Once you've written your answers, be sure to run your code or check your answers against the given questions. This will not only enhance your understanding of ES6 features but also prepare you for real-world coding challenges. Keep practicing!