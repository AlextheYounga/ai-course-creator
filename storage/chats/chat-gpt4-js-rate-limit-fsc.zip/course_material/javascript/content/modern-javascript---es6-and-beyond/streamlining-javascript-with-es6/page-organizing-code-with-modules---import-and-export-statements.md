# Organizing Code with Modules - Import and Export Statements

When you're building a puzzle, it's wise to separate the edge pieces from the middle pieces, isn't it? It helps you focus on specific areas without getting overwhelmed. In JavaScript, we use modules to achieve a similar level of organization with our code. Just as sorting puzzle pieces makes the task manageable, modules help us organize, maintain, and scale our code in a manageable way.

JavaScript modules are standalone pieces of code that encapsulate specific functionality. They can be thought of as small, self-contained units that can be developed, tested, and debugged independently before being combined to form a larger application.

In the ES6 version of JavaScript, the `import` and `export` statements were introduced to facilitate module usage. Before ES6, we relied on script tags or third-party tools to manage modules, which was a bit like trying to complete a large puzzle without organizing the pieces first. Now, with native support for modules, we can easily manage dependencies, create reusable code, and keep the global namespace clean, which means no more accidentally overwriting variables.

Imagine we're building an application that deals with shapes. We have functions to calculate the area of a square, triangle, and circle. Without modules, we might have all these functions in one file, but with ES6, we can have a dedicated module for each shape.

Here’s how we can organize it:

**square.js**
```javascript
const area = (side) => side * side;

export { area };
```

**triangle.js**
```javascript
const area = (base, height) => (base * height) / 2;

export { area };
```

**circle.js**
```javascript
const area = (radius) => Math.PI * radius * radius;

export { area };
```

Our `area` functions are now neatly tucked away in their respective modules. Whenever we need to calculate the area of a specific shape in our application, we can just use the `import` statement to access the relevant function. For our main application file, let's say it's called **app.js**, we can write:

```javascript
import { area as squareArea } from './square.js';
import { area as triangleArea } from './triangle.js';
import { area as circleArea } from './circle.js';

console.log(squareArea(10)); // Output: 100
console.log(triangleArea(10, 5)); // Output: 25
console.log(circleArea(7)); // Output: approximately 153.93804002589985
```

We’ve given each imported area function a unique name such as `squareArea`, `triangleArea`, and `circleArea`. This way, we can avoid naming conflicts and still have a clear understanding of which function we're using.

So, why is understanding modules so important in the tech industry today? Well, think of any large-scale web application like Facebook or Google Maps. These applications are massive and complex. Without a good module system, managing the codebase would be a nightmare. By using modules, developers can split their work into smaller, more manageable pieces which can be developed in isolation, tested more easily, and then integrated into the larger application.

It's safe to say that modules are akin to the essential organization tools in a developer's toolkit enabling neat, understandable, and maintainable code construction.

Let’s reinforce what we’ve discussed with a quick interactive challenge:

<div id="answerable-multiple-choice">
    <p id="question">Which statement correctly imports the `area` function from "circle.js" and aliases it as `circleArea` so that it can be used without conflicts in a file that also uses area functions from other shape modules?</p>
    <select id="choices">
        <option>import { circleArea } from 'circle.js';</option>
        <option>import { area } as circleArea from 'circle.js';</option>
        <option>import * as circleArea from 'circle.js';</option>
        <option id="correct-answer">import { area as circleArea } from './circle.js';</option>
    </select>
</div>

Remember, as your project grows, you'll be fitting a lot more pieces together. Modules, with their `import` and `export` statements, ensure that you're organizing those pieces effectively. Just like a well-managed puzzle, a well-organized codebase is beautiful to look at and satisfying to build.