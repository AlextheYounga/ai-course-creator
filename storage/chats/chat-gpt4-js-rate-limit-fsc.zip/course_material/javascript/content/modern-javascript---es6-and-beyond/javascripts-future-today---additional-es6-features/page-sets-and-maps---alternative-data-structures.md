# Sets and Maps - Alternative Data Structures

JavaScript's traditional go-to for data storage has long been the trusty Object. Like a Swiss Army knife, the Object does a little bit of everything. But sometimes, you don't need a corkscrew or a tiny pair of scissors, you just need a solid knife. Enter Sets and Maps, introduced in ES6 as specialized data structures, honing in on doing certain things better and more efficiently than our catch-all friend, the Object.

Imagine you're organizing a library. An Object would be like using a register that lists every book you have by a unique code, alongside the book's information. Pretty standard. But what if you only want to keep track of whether you have a particular book, without any additional details? That's when you'd use a Set. It's like a guest list for a party; you're only interested in who's coming, not what outfit they're wearing.

On the other hand, let's say you want to keep a collection where you know exactly how many copies of each book you have, but you also need quick access to update these numbers as books are checked out and returned. This is where Maps shine. They're like your library catalog where not only can you find if you have the book, but also how many copies are available.

## Sets

A Set in JavaScript is a collection of values where each value must be unique. If you try to add a value that's already in the Set, it simply won't add a duplicate. This uniqueness makes Sets ideal when you're dealing with a list of items where duplication is a no-no, like in the guest list analogy, where you want to make sure no one gets invited twice.

Here's how you might use a Set in JavaScript:

```javascript
let guestList = new Set();

guestList.add('Alice');
guestList.add('Bob');
guestList.add('Charlie');
guestList.add('Alice'); // This won't be added, as 'Alice' is already present

console.log(guestList.size); // Outputs: 3 
```

## Maps

Maps are similar to Objects in that they hold key-value pairs. However, one superpower of Maps is that they remember the original insertion order of the keys, which can be quite handy in certain scenarios. Another big advantage is that in Maps, keys can be any data type, not just strings or symbols like in Objects. Want to use a function or an object as a key? Go for it, while an Object would just convert it into a string.

Here's a quick look at Maps in action:

```javascript
let library = new Map();

library.set('Pride and Prejudice', 3);
library.set('1984', 5);
library.set('The Hitchhiker's Guide to the Galaxy', 42);

console.log(library.get('1984')); // Outputs: 5
```

With these new structures, we can store and manipulate data more efficiently, depending on our needs. Now, before we move on, let's check how well you've grasped the concept of Sets and Maps.

<div id="answerable-multiple-choice">
    <p id="question">Which statement below is true about the key differences between Sets and Maps in JavaScript?</p>
    <select id="choices">
        <option>A Map can remember the original insertion order, but a Set cannot.</option>
        <option>Sets allow duplicate values, while Maps do not.</option>
        <option>A Set can have any data type as a key, while Map keys are limited to strings and symbols.</option>
        <option id="correct-answer">Maps hold key-value pairs and remember insertion order, while Sets only store unique values without key associations.</option>
    </select>
</div>

Remember, objects are the multitool of JavaScript's data structures, but Sets and Maps are the specialized tools designed to make certain tasks smoother and your code cleaner. They're not always the answer, but for the right job, they're the hero you need. Keep them in your coding toolbox and use them when the time is right!