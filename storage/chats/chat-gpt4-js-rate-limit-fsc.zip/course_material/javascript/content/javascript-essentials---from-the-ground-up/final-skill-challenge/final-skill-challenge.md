# Final Skill Challenge

Welcome to the ultimate test of your JavaScript knowledge! This final skill challenge spans 20 thought-provoking problems, designed to push your limits and gauge your understanding of all things JavaScript—from basic syntax and variables to advanced object manipulation and error handling.

The first 15 questions will build upon the foundational skills covered in the course. The last 5 questions are particularly challenging and will require a deeper understanding and application of the concepts learned. Remember to take your time and think through each problem.

Prepare your development environment, clear your mind, and let's get started!

---

**Question 1: Starting Simple with Strings**

What's the length of the string `'Hello, JavaScript!'` when computed using JavaScript?

<div id="answerable-multiple-choice">
    <p id="question">Determine the length of the string `'Hello, JavaScript!'`.</p>
    <select id="choices">
        <option>16</option>
        <option id="correct-answer">17</option>
        <option>18</option>
        <option>15</option>
    </select>
</div>

---

**Question 2: Variable Declarations**

Which keyword would you use to declare a variable in JavaScript that should remain constant throughout the program?

<div id="answerable-multiple-choice">
    <p id="question">Select the keyword that declares a constant variable.</p>
    <select id="choices">
        <option>let</option>
        <option id="correct-answer">const</option>
        <option>var</option>
    </select>
</div>

---

**Question 3: Working with Booleans**

In a conditional statement, what will `!true` evaluate to?

<div id="answerable-multiple-choice">
    <p id="question">What is the value of `!true`?</p>
    <select id="choices">
        <option id="correct-answer">false</option>
        <option>true</option>
    </select>
</div>

---

**Question 4: Action with Arrays**

Given the array `[1, 2, 3, 4, 5]`, use a JavaScript array method to double each element's value.

<div id="answerable-code-editor">
    <p id="question">Write the JavaScript code snippet to double each element's value in the array `[1, 2, 3, 4, 5]`.</p>
    <p id="correct-answer">
```javascript
var numbers = [1, 2, 3, 4, 5];
var doubledNumbers = numbers.map((num) => num * 2);
```
    </p>
</div>

---

**Question 5: Handling DataTypes**

You need to parse a string to a number before performing mathematical operations. Which function would you use for the string `'123'`?

<div id="answerable-multiple-choice">
    <p id="question">Choose the correct function to convert the string '123' to a number.</p>
    <select id="choices">
        <option>toString()</option>
        <option id="correct-answer">parseInt()</option>
        <option>valueOf()</option>
        <option>toFixed()</option>
    </select>
</div>

---

**Question 6: Conditions with Loops**

Assuming `i` is a positive integer, which loop statement will print `'The number is 0'` only once?

<div id="answerable-multiple-choice">
    <p id="question">Which loop statement correctly prints the phrase once?</p>
    <select id="choices">
        <option id="correct-answer">`while (i < 1) { console.log('The number is 0'); i++; }`</option>
        <option>`do { console.log('The number is 0'); } while (i < 1); i++;`</option>
        <option>`for (; i < 1; i++) { console.log('The number is 0'); }`</option>
        <option>All of the above</option>
    </select>
</div>

---

**Question 7: Function Declarations**

What will the function below return when called with `greet('Morning')`?

```javascript
function greet(timeOfDay) {
  var greeting = "Good " + timeOfDay;
  return greeting;
}
```

<div id="answerable-multiple-choice">
    <p id="question">What is the expected output of `greet('Morning')`?</p>
    <select id="choices">
        <option>'Good TimeOfDay'</option>
        <option>'Good Day'</option>
        <option id="correct-answer">'Good Morning'</option>
        <option>Good + timeOfDay</option>
    </select>
</div>

---

**Question 8: Objects in Depth**

Given an object `cat`:

```javascript
var cat = {
    name: "Whiskers",
    "fur color": "tabby"
};
```

Which line will correctly print the cat's fur color?

<div id="answerable-multiple-choice">
    <p id="question">Choose the line that prints the cat's fur color.</p>
    <select id="choices">
        <option>console.log(cat[name]);</option>
        <option>console.log(cat.name);</option>
        <option id="correct-answer">console.log(cat["fur color"]);</option>
        <option>console.log(cat.'fur color');</option>
    </select>
</div>

---

**Question 9: Advanced Array Methods**

How can you find the first number greater than 10 in the array `[2, 5, 8, 10, 13, 17]`?

<div id="answerable-multiple-choice">
    <p id="question">Select the method that finds the first number greater than 10.</p>
    <select id="choices">
        <option>map()</option>
        <option>forEach()</option>
        <option>filter()</option>
        <option id="correct-answer">find()</option>
    </select>
</div>

---

**Question 10: Interaction Between Objects and Arrays**

You have an array of user objects. How can you console.log the names of all users?

```javascript
let users = [
    { name: "Alice", age: 25 },
    { name: "Bob", age: 27 },
    { name: "Charlie", age: 30 }
];
```

<div id="answerable-code-editor">
    <p id="question">Write a JavaScript code block that logs the name of each user in the `users` array.</p>
    <p id="correct-answer">
```javascript
users.forEach(function(user) {
    console.log(user.name);
});
```
    </p>
</div>

---

->___Up to this point, the challenges have introduced you to a broad range of JavaScript scenarios. Now, the following questions are intended to stretch your capabilities. Prepare yourself for a series of exercises that will test the limits of your JavaScript skills.___

---

**Question 11: Ternary Operator Deconstruction**

Within a function, a ternary operator is used to check if a user's age is 18 or more. Refactor the function to use an `if...else` statement instead.

<div id="answerable-code-editor">
    <p id="question">Refactor this ternary operation into an `if...else` structure.</p>
    <p id="correct-answer">
```javascript
function checkAge(age) {
    return (age >= 18) ? 'Access granted' : 'Access denied';
}
```
    </p>
</div>

---

**Question 12: Higher-Order Function Crafting**

Write a higher-order function that applies a given function to every element in an array.

<div id="answerable-code-editor">
    <p id="question">Create a function that applies a function `fn` to each element of an array `arr`.</p>
    <p id="correct-answer">
```javascript
function applyToArray(arr, fn) {
    for (var i = 0; i < arr.length; i++) {
        arr[i] = fn(arr[i]);
    }
    return arr;
}
```
    </p>
</div>

---

**Question 13: Object Property Access with Error Handling**

You are accessing an API that sometimes returns incomplete user objects. Write a snippet that safely logs the user's email if it exists.

<div id="answerable-code-editor">
    <p id="question">Write JavaScript code that attempts to log a user's email but does not throw an error if the email property is not present.</p>
    <p id="correct-answer">
```javascript
let possibleUser = { /* ...user object that might have an email property */ };

if ('email' in possibleUser) {
    console.log(possibleUser.email);
} else {
    console.log('Email not provided');
}
```
    </p>
</div>

---

**Question 14: Challenging Loop Constructs**

Generate and log an array containing the Fibonacci series up to the 10th term, starting from 0.

<div id="answerable-code-editor">
    <p id="question">Write a loop in JavaScript that generates the first 10 Fibonacci numbers.</p>
    <p id="correct-answer">
```javascript
let fibonacci = [0, 1];
for(let i = 2; i < 10; i++) {
    fibonacci[i] = fibonacci[i - 1] + fibonacci[i - 2];
}
console.log(fibonacci);
```
    </p>
</div>

---

**Question 15: Regex Utilization**

Given a string of words separated by spaces, write a function that checks if the string contains any words over 10 characters in length using a regular expression.

<div id="answerable-code-editor">
    <p id="question">Create a function that returns `true` if a string contains any words exceeding 10 characters, or `false` otherwise.</p>
    <p id="correct-answer">
```javascript
function containsLongWord(string) {
    var longWordRegex = /\b\w{11,}\b/;
    return longWordRegex.test(string);
}
```
    </p>
</div>

---

**Question 16: Data Transformation**

Given the array:

```javascript
const data = [1.1, 2.2, 3.3, 4.4];
```

Transform the data using the `.map()` method to a corresponding array of integers.

<div id="answerable-code-editor">
    <p id="question">Write the JavaScript line of code using `.map()` to transform the `data` array into an array of integers.</p>
    <p id="correct-answer">
```javascript
const integers = data.map((element) => Math.floor(element));
```
    </p>
</div>

---

**Question 17: Advanced Object Property Iteration**

Create a function that accepts a user object, iterates over the user's properties, and prints out a greeting for each property that starts with an 'a' denoting an attribute (e.g., `user.age` or `user.address` but not `user.name`).

```javascript
const user = {
    age: 35,
    name: 'John Doe',
    address: '123 Main Street'
};
```

<div id="answerable-code-editor">
    <p id="question">Write a function that iterates over an object's properties and logs a greeting for each property starting with 'a'.</p>
    <p id="correct-answer">
```javascript
function greetAttributes(user) {
    for (const key in user) {
        if (key.startsWith('a')) {
            console.log(`Greetings, ${key} is now set to ${user[key]}`);
        }
    }
}
```
    </p>
</div>

---

**Question 18: Nested Data Access**

Access all 'active' property values in an array of user objects, and sum them up to find how many users are active.

```javascript
const users = [
      { name: 'John', active: true },
      { name: 'Jane', active: false },
      { name: 'Jim', active: true },
      // ...
];
```

<div id="answerable-code-editor">
    <p id="question">Write a JavaScript function that counts and returns the total number of active users in the provided array.</p>
    <p id="correct-answer">
```javascript
function countActiveUsers(users) {
    return users.reduce((total, user) => user.active ? total + 1 : total, 0);
}
```
    </p>
</div>

---

**Question 19: Complex Conditions with Logical Operators**

Determine the eligibility for a special discount. The discount is granted if the user has either 'gold' or 'platinum' membership and has at least 500 points or their account is over two years old.

<div id="answerable-code-editor">
    <p id="question">Assuming you have variables `membershipStatus` (string), `points` (number), and `accountAge` (number, representing years), write a JavaScript condition that evaluates if the user is eligible for the discount.</p>
    <p id="correct-answer">
```javascript
var membershipStatus, points, accountAge; // Assume these are defined elsewhere in your code

if ((membershipStatus === 'gold' || membershipStatus === 'platinum') && (points >= 500 || accountAge > 2)) {
    // Eligible for discount
}
```
    </p>
</div>

---

**Question 20: Data Handling and Error Prevention**

Suppose you have a function that sometimes receives data in JSON format and other times as a JavaScript object. It must return the 'status' property value, but sometimes 'status' is missing, and sometimes the input is undefined. Write the function with error handling.

<div id="answerable-code-editor">
    <p id="question">Construct a function `getStatus` that returns the 'status' property from either a JSON string or an object, accounting for potential issues such as missing properties or undefined inputs.</p>
    <p id="correct-answer">
```javascript
function getStatus(input) {
    try {
        if (typeof input === 'string') {
            input = JSON.parse(input);
        }
        if (input && typeof input.status !== 'undefined') {
            return input.status;
        }
        throw new Error("Status property is missing.");
    } catch (error) {
        // Handle any parsing errors or the custom error thrown above
        console.error(error.message);
        return null;
    }
}
```
    </p>
</div>

---

These 20 challenges should now give you a comprehensive understanding of your proficiency in JavaScript. The last five questions are designed to reflect real-world scenarios, pushing you to combine different JavaScript concepts to solve complex problems. Be proud of how far you've come, and keep practicing and honing your skills. Keep coding, keep learning, and enjoy the journey!