# Practice Skill Challenge

Let's put your JavaScript knowledge to the test! The following practice problems will challenge your understanding of control flows, loops, switch statements, error messages, and debugging, as covered in the course. Try to solve these problems on your own, and then check the answers provided. Ready? Let's begin!

### Problem 1: Control Flow with if...else
<div id="answerable-multiple-choice">
    <p id="question">What message will be displayed when the provided code is executed with `isUserLoggedIn` set to `false`?</p>
    <select id="choices">
        <option>Welcome back!</option>
        <option id="correct-answer">Access denied. Please log in.</option>
        <option>No account found.</option>
        <option>Logging out...</option>
    </select>
</div>

```javascript
let isUserLoggedIn = false;

if (isUserLoggedIn) {
    console.log('Welcome back!');
} else {
    console.log('Access denied. Please log in.');
}
```

### Problem 2: Iterating with for Loops
<div id="answerable-code-editor">
    <p id="question">Write a 'for' loop that prints all even numbers from 2 to 10, inclusive.</p>
    <p id="correct-answer">
```javascript
for (let i = 2; i <= 10; i += 2) {
    console.log(i);
}
```
    </p>
</div>

### Problem 3: Decision Making with switch
<div id="answerable-multiple-choice">
    <p id="question">Using the function provided, what will `getDayOfTheWeek(3)` return?</p>
    <select id="choices">
        <option>'Sunday'</option>
        <option>'Tuesday'</option>
        <option id="correct-answer">'Wednesday'</option>
        <option>'Invalid day'</option>
    </select>
</div>

```javascript
function getDayOfTheWeek(dayNumber) {
    switch (dayNumber) {
        case 0:
            return 'Sunday';
        case 1:
            return 'Monday';
        case 2:
            return 'Tuesday';
        case 3:
            return 'Wednesday';
        // Other cases would be added here
        default:
            return 'Invalid day';
    }
}
```

### Problem 4: Understanding Error Messages
<div id="answerable-multiple-choice">
    <p id="question">What error message will you get if you try to execute the following code without declaring the `totalSum` variable?</p>
    <select id="choices">
        <option id="correct-answer">Uncaught ReferenceError: totalSum is not defined</option>
        <option>Uncaught TypeError: Cannot read property 'totalSum'</option>
        <option>Uncaught SyntaxError: Missing initializer in const declaration</option>
        <option>Uncaught RangeError: Invalid array length</option>
    </select>
</div>

```javascript
console.log(totalSum);
```

### Problem 5: Debugging a Function
<div id="answerable-code-editor">
    <p id="question">Given the code below, identify the bug and provide a fix so that the function correctly calculates the sum of `num1` and `num2`.</p>
    <p id="correct-answer">
```javascript
function addNumbers(num1, num2) {
  if (typeof num1 !== 'number' || typeof num2 !== 'number') {
    throw new Error('Both arguments must be numbers.');
  }
  return num1 + num2;
}
```
    </p>
</div>

```javascript
function addNumbers(num1, num2) {
  return num1 - num2; // This line contains a bug
}
```

These challenges are meant to mimic the kind of errors and problems you can encounter while coding in JavaScript. Evaluating your ability to solve these will help solidify your understanding of key programming concepts. If you run into any difficulties, review the course materials for a refresher, and then give the problems another shot. Keep practicing, and happy coding!