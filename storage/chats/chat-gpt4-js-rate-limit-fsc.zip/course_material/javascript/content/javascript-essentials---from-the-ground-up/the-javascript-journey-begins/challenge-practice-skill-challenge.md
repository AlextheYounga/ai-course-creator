# Practice Skill Challenge

Test your understanding of the JavaScript concepts we've covered in this course with these 5 practice problems. Ensure you take time to think through each problem before looking at the answer choices. Good luck, and happy coding!

---

**Question 1: Essential Variables**

In web development, it's often necessary to keep track of user interactions. Let's say you have a button on a webpage that increments a counter every time it is clicked. Which kind of variable would you use in JavaScript to declare this counter that is expected to change with each click?

<div id="answerable-multiple-choice">
    <p id="question">Which type of variable declaration in JavaScript allows for a variable's value to change?</p>
    <select id="choices">
        <option id="correct-answer">let</option>
        <option>const</option>
        <option>var</option>
    </select>
</div>

---

**Question 2: Data Types in Action**

When registering for a new app, the user is asked to input their birth year. Considering this information will be used to calculate their age, what is the most appropriate data type to store this piece of data?

<div id="answerable-multiple-choice">
    <p id="question">What JavaScript data type should you use to store a user's birth year?</p>
    <select id="choices">
        <option id="correct-answer">Number</option>
        <option>String</option>
        <option>Boolean</option>
        <option>Array</option>
    </select>
</div>

---

**Question 3: Comparison Operators**

You’re creating a security feature that triggers an alert if the number of login attempts exceeds 3. Assuming `attempts` is a variable that tracks the number of tries, which operator will you use to check whether the alert should be triggered?

<div id="answerable-multiple-choice">
    <p id="question">Which comparison operator checks if the value of a variable is greater than a specified value in JavaScript?</p>
    <select id="choices">
        <option>&gt;</option>
        <option id="correct-answer">&gt;=</option>
        <option>&lt;</option>
        <option>&lt;=</option>
    </select>
</div>

---

**Question 4: Crafting Functions**

Consider a scenario where you're tasked to write a function that outputs "Good morning!" if the time provided is less than or equal to 11:59 am. Write a JavaScript function `greetMorning` that takes a parameter `hour` (in 24-hour format) and returns "Good morning!" if the condition is met.

<div id="answerable-code-editor">
    <p id="question">Write a JavaScript function named `greetMorning` that takes an `hour` parameter and returns "Good morning!" if the `hour` is less than or equal to 11.</p>
    <p id="correct-answer">function greetMorning(hour) {
  if (hour <= 11) {
    return "Good morning!";
  }
}</p>
</div>

---

**Question 5: Logical Operators and Program Flow**

You are programming a webpage where a special offer is displayed to users who are logged in and have accumulated more than 1000 points. The condition to display the offer relies on two variables: `isLoggedIn` and `points`. How would you check both of these conditions using JavaScript logical operators?

<div id="answerable-multiple-choice">
    <p id="question">Which logical operator would you use to check that a user is logged in (`isLoggedIn` is true) and has more than 1000 points in JavaScript?</p>
    <select id="choices">
        <option>||</option>
        <option id="correct-answer">&&</option>
        <option>!</option>
        <option>==</option>
    </select>
</div>

---

Once you have completed these practice questions, review your answers to ensure you understand why each solution is correct. These questions are designed to reinforce core JavaScript concepts and ensure a strong foundation for more advanced programming topics. Keep practicing, and you'll continue to level up your skills!