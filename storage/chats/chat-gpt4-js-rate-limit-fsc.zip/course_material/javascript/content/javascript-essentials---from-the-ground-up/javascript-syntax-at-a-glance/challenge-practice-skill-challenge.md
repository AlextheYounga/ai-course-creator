# Practice Skill Challenge

Welcome to the Practice Skill Challenge! Here you'll have the opportunity to apply what you've learned and test your knowledge of JavaScript. These exercises focus on the topics discussed in the course: variables, expressions, functions, and objects, as well as best practices for writing readable and maintainable code. Get ready to solidify your understanding and showcase your skills!

---

### Question 1: Declaring Variables with Proper Keywords

In JavaScript, choosing the right keyword to declare a variable is foundational. Decide which keyword would be best for a scenario where the variable will potentially be reassigned later in the code.

<div id="answerable-multiple-choice">
  <p id="question">Which keyword would you use to declare a variable that you plan to reassign?</p>
  <select id="choices">
    <option>const</option>
    <option id="correct-answer">let</option>
    <option>var</option>
    <option>assign</option>
  </select>
</div>

---

### Question 2: Expressions That Produce a Value

Expressions are critical in JavaScript as they are computations that the language interprets to produce a value. Identify the choice that is an expression.

<div id="answerable-multiple-choice">
  <p id="question">Which of the following is an expression in JavaScript?</p>
  <select id="choices">
    <option id="correct-answer">3 + 7</option>
    <option>let totalSum;</option>
    <option>if (totalSum > 10) { console.log("Sum is large!"); }</option>
    <option>return totalSum;</option>
  </select>
</div>

---

### Question 3: Crafting Functions for Repeating Tasks

Functions are like your own mini-programs within your code that handle a specific task, and can be called upon repeatedly. Create a simple function that adds two numbers.

<div id="answerable-code-editor">
  <p id="question">Write a function named `addTwoNumbers` that takes two parameters and returns their sum.</p>
  <p id="correct-answer">function addTwoNumbers(a, b) { return a + b; }</p>
</div>

---

### Question 4: Accessing Object Properties

JavaScript objects allow us to group related data. Using the dot notation or the bracket notation, we can access the values associated with each property. Retrieve the correct piece of information from the given object.

```javascript
let userProfile = {
  username: "jsCoder123",
  email: "coder123@example.com",
  accountAgeInDays: 100
};
```

<div id="answerable-multiple-choice">
  <p id="question">Which property of the `userProfile` object holds the user's email?</p>
  <select id="choices">
    <option>userProfile.username</option>
    <option id="correct-answer">userProfile.email</option>
    <option>userProfile.accountAgeInDays</option>
    <option>userProfile["email"]</option>
  </select>
</div>

---

### Question 5: Importance of Readable and Maintainable Code

One of the hallmarks of good coding practice is writing code that not only works but is also understandable to others (and your future self!). Which of the following options best represents a solid practice in maintaining such code?

<div id="answerable-multiple-choice">
  <p id="question">What is a good practice for ensuring your JavaScript code is maintainable?</p>
  <select id="choices">
    <option>Writing all code in a single line to reduce the number of lines in your codebase.</option>
    <option>Using cryptic variable names so that others must decipher the purpose of the code.</option>
    <option id="correct-answer">Writing descriptive comments for complex sections of code and using meaningful variable names.</option>
    <option>Avoiding the use of functions to keep the codebase simple and contained.</option>
  </select>
</div>

---

Make sure to analyze the questions carefully and apply the principles you have learned. Good luck, and may your syntax be error-free!