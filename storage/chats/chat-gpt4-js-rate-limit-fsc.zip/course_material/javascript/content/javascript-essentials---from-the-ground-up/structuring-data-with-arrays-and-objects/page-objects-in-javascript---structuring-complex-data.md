## Objects in JavaScript - Structuring Complex Data

When you organize a party, you have a list of items to buy, guests to invite, and tasks to complete. This collection of different types of information requires a more complex structure than a simple grocery list. Enter JavaScript objects—the perfect container for storing a varied collection of data.

In JavaScript, objects are a bit like your own virtual party planner. They hold data in the form of key-value pairs, where each key is like a label on a filing cabinet and the value is the information you've filed away. This system is incredibly handy when you have a lot of details to manage that don't neatly line up in a simple list.

Think of an online contact book. Each contact is an object, and they might have keys like "name," "email," "phone," and "address." These keys are consistent across all contacts, but the values are unique to each person.

Here's a small taste of what an object might look like for one contact:

```javascript
let contact = {
    name: "Charlie Brown",
    email: "charlie.brown@example.com",
    phone: "+1234567890",
    address: "123 Peanuts Avenue, Comic City, CA"
};
```

Objects aren't just static holders of data, either. They can also contain functions, known as methods, which can act on the data contained within the object. For example, you could have a `greet` method that sends a friendly message using the contact's name.

```javascript
contact.greet = function() {
    console.log("Hello, " + this.name + "!");
};
```

Now if we call `contact.greet();`, we'll see "Hello, Charlie Brown!" in the console.

In real-world applications, objects are indispensable. They're used to represent everything from user profiles on a social media site to products in an online store's inventory, or even complex configurations for a software application.

Let's put this into practice with a quick challenge:

<div id="answerable-code-editor">
    <p id="question">Add a 'birthday' property with the value "October 30" to the 'contact' object and then create a method 'celebrateBirthday' that outputs "Happy Birthday, [Name]!" using the console.log function.</p>
    <p id="correct-answer">// Your code should look something like this:
contact.birthday = "October 30";
contact.celebrateBirthday = function() {
    console.log("Happy Birthday, " + this.name + "!");
};</p>
</div>

Now, with a dash of imagination, you can see how objects can help keep our code neat and our data organized. They serve as the backbone of many JavaScript applications, giving structure and meaning to the diverse and complex data we work with every day.