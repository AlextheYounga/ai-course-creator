# Practice Skill Challenge

Put your JavaScript knowledge to the test with the following practice problems. These challenges will assess your grasp on arrays, objects, and JSON, based on the course material. Solve each problem by selecting the best option or writing the necessary code snippet.

## Challenge 1: Expanding the Grocery List
Imagine you have a grocery list stored in an array. You want to add another item to the list.

```javascript
var groceryList = ['milk', 'eggs', 'bread'];
```

<div id="answerable-code-editor">
    <p id="question">How would you add 'butter' to the end of the `groceryList` array using JavaScript?</p>
    <p id="correct-answer">groceryList.push('butter');</p>
</div>

## Challenge 2: Array Indexing
After a shopping spree, you want to find out what the third item in your cart is.

```javascript
var shoppingCart = ['shampoo', 'toothpaste', 'soap', 'deodorant'];
```

<div id="answerable-multiple-choice">
    <p id="question">What is the third item in the `shoppingCart` array?</p>
    <select id="choices">
        <option>shampoo</option>
        <option>toothpaste</option>
        <option id="correct-answer">soap</option>
        <option>deodorant</option>
    </select>
</div>

## Challenge 3: Modifying Object Properties
Suppose you are working with a user profile object in your application, and you need to update the user's address.

```javascript
var userProfile = {
    name: "Jamie Smith",
    email: "jamie.smith@example.com",
    address: "123 Maple Street"
};
```

<div id="answerable-code-editor">
    <p id="question">Write the JavaScript line of code to update the address in the `userProfile` object to "456 Oak Lane".</p>
    <p id="correct-answer">userProfile.address = "456 Oak Lane";</p>
</div>

## Challenge 4: Accessing Elements in Nested Arrays
Consider you have an array of arrays representing different product options in a store, and you need to access a specific option.

```javascript
var productOptions = [
    ['small', 'medium', 'large'],
    ['red', 'green', 'blue', 'yellow']
];
```

<div id="answerable-multiple-choice">
    <p id="question">Select the correct way to access the option 'green' from the `productOptions` array.</p>
    <select id="choices">
        <option>productOptions[0][1]</option>
        <option id="correct-answer">productOptions[1][1]</option>
        <option>productOptions[1][0]</option>
        <option>productOptions[2][1]</option>
    </select>
</div>

## Challenge 5: Parsing JSON
A server response comes in JSON format providing details about an event. You need to extract a piece of information from it.

```json
{
    "event": "Book Club Meeting",
    "date": "2023-05-10",
    "startTime": "18:00",
    "endTime": "20:00",
}
```

<div id="answerable-fill-blank">
    <p id="question">Fill in the blank with the correct JavaScript to obtain the `startTime` of the event from the JSON data.</p>
    <p id="correct-answer">data.startTime</p>
</div>

After attempting these challenges, you'll have a better understanding of where you stand with arrays, objects, and JSON in JavaScript. Embrace the process, and enjoy your journey into becoming a proficient coder!