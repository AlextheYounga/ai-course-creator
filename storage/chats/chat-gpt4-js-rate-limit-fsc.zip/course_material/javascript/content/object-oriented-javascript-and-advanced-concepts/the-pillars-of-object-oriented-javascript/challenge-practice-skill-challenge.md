# Practice Skill Challenge

Welcome to your Practice Skill Challenge! In this section, you'll apply your knowledge of JavaScript Object-Oriented Programming (OOP) to solve problems and strengthen your understanding. Please complete the following 5 practice questions based on the material covered so far in the course.

### Problem 1: Creating Objects in JavaScript
Using the object creation knowledge you've gained, complete the code below to create an object named `book` with properties `title`, `author`, and a method `displayInfo` that prints out the book title and author.

<div id="answerable-code-editor">
    <p id="question">Complete the 'book' object to include the necessary properties and method as described above.</p>
    <p id="correct-answer">let book = {
    title: 'The Great Gatsby',
    author: 'F. Scott Fitzgerald',
    displayInfo: function() {
        console.log(this.title + ' by ' + this.author);
    }
};
</p>
</div>

### Problem 2: Prototypes
Suppose you have a `Dog` constructor and you want to add a `bark` method to the `Dog` prototype so that all instances of `Dog` can use it. Fill in the blank to correctly add the method.

<div id="answerable-fill-blank">
    <p id="question">Fill in the blank to add the 'bark' method to the Dog prototype:</p>
    <pre>
function Dog(name) {
  this.name = name;
}

Dog.prototype.______ = function() {
  return this.name + " says woof!";
};
    </pre>
    <p id="correct-answer">bark</p>
</div>

### Problem 3: Accessing Object Methods
An object named `calculator` has a method called `add` that takes two numbers and returns their sum. Determine the correct way to call this method and pass to it the numbers 10 and 5.

<div id="answerable-multiple-choice">
    <p id="question">How do you call the 'add' method of the 'calculator' object with numbers 10 and 5?</p>
    <select id="choices">
        <option>calculator.add[10, 5];</option>
        <option>calculator{'add'(10, 5)};</option>
        <option>calculator->add(10, 5);</option>
        <option id="correct-answer">calculator.add(10, 5);</option>
    </select>
</div>

### Problem 4: Constructor Functions
What is the main purpose of a constructor function in JavaScript OOP?

<div id="answerable-multiple-choice">
    <p id="question">Select the main purpose of a constructor function:</p>
    <select id="choices">
        <option>To construct the DOM elements on a webpage.</option>
        <option id="correct-answer">To initialize new objects with predefined properties and methods.</option>
        <option>To construct new functions solely for calculation purposes.</option>
        <option>To connect to a database and create new entries.</option>
    </select>
</div>

### Problem 5: JavaScript Classes and Inheritance
Imagine you are creating a class called `Smartphone` that inherits from a class named `ElectronicDevice`. The `Smartphone` class has one additional property called `carrier`. Fill in the blanks to properly set up inheritance.

<div id="answerable-code-editor">
    <p id="question">Complete the 'Smartphone' class to inherit from 'ElectronicDevice' and include the 'carrier' property.</p>
    <p id="correct-answer">class Smartphone extends ElectronicDevice {
    constructor(brand, model, carrier) {
        super(brand, model);
        this.carrier = carrier;
    }
}
</p>
</div>

Once you've attempted all the questions, be sure to check your answers and ensure you've understood the core concepts of JavaScript OOP as this knowledge will be a valuable asset for your coding projects. Good luck!