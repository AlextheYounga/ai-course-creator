# Crafting Constructors and Prototypes

Constructors and prototypes are core concepts in JavaScript, playing a crucial role in creating objects and defining how they behave. Let's imagine you're running a car factory. Every car you produce has certain features—like wheels, doors, and engines—but each car also has unique properties, like color or horsepower. In JavaScript, a constructor is like the blueprint for your car; it defines the general features all cars share. The prototype, on the other hand, is like a shared set of customization options that all cars can inherit and modify.

## Constructors: The Blueprints
In JavaScript, a constructor function is what we use to create new objects. Think of it like a blueprint for a house. If you want to build a bunch of houses that all follow the same basic design, you'd use that blueprint as your starting point. Here’s how you create a constructor function in JavaScript:

```javascript
function Car(make, model, year) {
  this.make = make;
  this.model = model;
  this.year = year;
}
```

Now, if you want to create a new car, you'd use the `new` keyword followed by the name of your constructor. This is like telling your factory, "Build me a car with these specific details." Let's build our first car:

```javascript
var myFirstCar = new Car('Toyota', 'Corolla', 2020);
```

Here, `myFirstCar` will be an object with the properties `make` set to 'Toyota', `model` set to 'Corolla', and `year` set to 2020.

## Prototype: The Shared Customization Options
The prototype is an object that is associated with your constructor function. Think of it as a place where objects made from the constructor can "share" functions. This is like adding a special package of features to all houses designed from a blueprint without altering the blueprint itself.

For our `Car` constructor, we might want all cars to have the ability to honk, so we add a `honk` method to `Car`'s prototype like so:

```javascript
Car.prototype.honk = function() {
  return "Beep! Beep!";
};
```

Now, all cars created using the `Car` constructor can honk:

```javascript
var mySecondCar = new Car('Ford', 'Mustang', 2021);
mySecondCar.honk(); // Output: "Beep! Beep!"
```

<div id="answerable-multiple-choice">
    <p id="question">What will happen if we add a new method to the Car prototype after creating an instance of a car?</p>
    <select id="choices">
        <option>All existing and new car instances will have the new method.</option>
        <option id="correct-answer">Only new car instances created after adding the method will have the new method.</option>
        <option>Existing car instances will have the new method, but the new car instances will not.</option>
        <option>It will throw an error because the prototype is sealed after an instance is created.</option>
    </select>
</div>

In reality, however, even after you've created an instance of your car, adding a new method to the prototype will still mean that all existing and future cars will have access to that method. This is because in JavaScript, objects have a link to their prototype rather than a copy.

Having learned about constructors and prototypes, you now see how they work together to efficiently create objects with shared behaviors in JavaScript. This pattern is particularly powerful when it comes to inheritance, which we'll explore deeper in the following pages. Understanding these concepts will not only help you build your JavaScript applications but also allow you to better understand libraries and frameworks where these patterns are commonly used.