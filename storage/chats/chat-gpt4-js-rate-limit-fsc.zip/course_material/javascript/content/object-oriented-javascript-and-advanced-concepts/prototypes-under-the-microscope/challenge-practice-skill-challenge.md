# Practice Skill Challenge: JavaScript Prototypes

Welcome to the Practice Skill Challenge! In this section, you'll put your newfound knowledge of JavaScript prototypes to the test. Work through the following questions to ensure you understand how prototypes work in JavaScript. It’s important to note that these challenges are designed to assess your understanding of the prototype chain, extending built-in objects, overriding inherited properties and methods, and performance considerations using prototypes as covered in the course.

## Question 1: The Prototype Chain
<div id="answerable-multiple-choice">
    <p id="question">If an object created from a constructor function 'Bird()' does not have a method 'fly()', but its prototype has this method, what happens when you call 'sparrow.fly()' on an instance of 'Bird' named 'sparrow'?</p>
    <select id="choices">
        <option>The program throws a reference error</option>
        <option>The 'fly()' method is called from the prototype of 'Bird'</option>
        <option id="correct-answer">The 'fly()' method is executed from the prototype of 'sparrow'</option>
        <option>An undefined value is returned</option>
    </select>
</div>

## Question 2: Extending Built-in Objects
<div id="answerable-code-editor">
    <p id="question">Extend the String prototype in JavaScript to include a method 'exclaim()' that returns the string with an exclamation mark appended to it. For example, 'hello'.exclaim() should return 'hello!'.</p>
    <p id="correct-answer">String.prototype.exclaim = function() { return this + '!'; };</p>
</div>

## Question 3: Overriding Inherited Methods
<div id="answerable-multiple-choice">
    <p id="question">Why might you choose to override an inherited method in a JavaScript object?</p>
    <select id="choices">
        <option>To increase the execution time of the method</option>
        <option>To reduce the memory footprint of the object</option>
        <option id="correct-answer">To tailor the inherited method's behavior more closely to the child object's needs</option>
        <option>To inherit additional methods from another object</option>
    </select>
</div>

## Question 4: Performance and Prototype Chains
<div id="answerable-multiple-choice">
    <p id="question">As the length of a prototype chain increases, how does it affect the performance of property access in JavaScript?</p>
    <select id="choices">
        <option>Access time decreases as JS engine optimization improves</option>
        <option>Access time remains unchanged regardless of prototype length</option>
        <option id="correct-answer">Access time increases as the engine has to traverse a longer chain</option>
        <option>Access time varies randomly</option>
    </select>
</div>

## Question 5: Adding Methods to Prototypes
<div id="answerable-code-editor">
    <p id="question">Add a method called 'describe' to the 'Vehicle' prototype that logs 'This vehicle is a [make] [model].' when invoked, replacing [make] and [model] with the instance's make and model properties.</p>
    <p id="correct-answer">Vehicle.prototype.describe = function() { console.log('This vehicle is a ' + this.make + ' ' + this.model + '.'); };</p>
</div>

Consider this challenge as part of your training, giving you a stronger grasp on prototype-based programming in JavaScript. Good luck, and remember to test your solutions to ensure they work as expected!