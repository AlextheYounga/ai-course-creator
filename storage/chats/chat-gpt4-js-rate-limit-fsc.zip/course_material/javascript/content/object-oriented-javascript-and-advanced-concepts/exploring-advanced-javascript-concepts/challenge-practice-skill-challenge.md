# Practice Skill Challenge

Put your knowledge of JavaScript concepts such as closures, IIFEs (Immediately Invoked Function Expressions), and memory management to the test with the following practice problems. Make sure to read each question carefully and think about what you've learned in the course before answering.

### Problem 1: Understanding Closures

Given the following code snippet, what would be the output when calling `startEngine()`?

```javascript
function car() {
  var engineStatus = 'off';

  return {
    startEngine: function() {
      engineStatus = 'on';
      return 'Engine is ' + engineStatus;
    },
    stopEngine: function() {
      engineStatus = 'off';
      return 'Engine is ' + engineStatus;
    }
  }
}

var myCar = car();
```

<div id="answerable-multiple-choice">
    <p id="question">What is the output when `myCar.startEngine()` is called?</p>
    <select id="choices">
        <option>Engine is off</option>
        <option id="correct-answer">Engine is on</option>
        <option>Undefined</option>
        <option>'engineStatus'</option>
    </select>
</div>

### Problem 2: Applying Closures

Write a JavaScript function `createCounter` that returns a new function to count upwards every time it's called, starting with 1.

```javascript
// Example Usage:
// var counter = createCounter();
// counter(); // Should return 1
// counter(); // Should return 2
```

<div id="answerable-code-editor">
    <p id="question">Write the `createCounter` function as described above.</p>
    <p id="correct-answer">function createCounter() {
  var count = 0;
  return function() {
    count += 1;
    return count;
  };
}</p>
</div>

### Problem 3: IIFEs in Practice

Analyze the following code. What would be the output to the console when this script runs?

```javascript
var result = (function() {
  var name = 'Skywalker';
  return name;
})();

console.log(result);
```

<div id="answerable-multiple-choice">
    <p id="question">What is logged to the console?</p>
    <select id="choices">
        <option>'(function() { var name = 'Skywalker'; return name; })()'</option>
        <option id="correct-answer">'Skywalker'</option>
        <option>Undefined</option>
        <option>Nothing is logged</option>
    </select>
</div>

### Problem 4: Garbage Collection Understanding

If a function `createDocument` creates a large object but does not return a reference to it, what happens to the object after the function call is completed?

<div id="answerable-multiple-choice">
    <p id="question">What happens to the non-referenced object created by `createDocument` after the call completes?</p>
    <select id="choices">
        <option>The object is kept in memory until the page is refreshed.</option>
        <option>The object is stored in the window object for later use.</option>
        <option id="correct-answer">The garbage collector will reclaim the memory if there are no references to it.</option>
        <option>The object remains in memory indefinitely.</option>
    </select>
</div>

### Problem 5: Preventing Memory Leaks

Consider the following function:

```javascript
function eventListener() {
  var element = document.getElementById('myButton');
  element.onclick = function() {
    alert('Button clicked!');
  };
}
```

This function adds an event listener to an HTML button with id `myButton`. After the function is called, what can you do to prevent potential memory leaks involving the `element` variable?

<div id="answerable-multiple-choice">
    <p id="question">What is a good practice to minimize memory leaks after `eventListener` is executed?</p>
    <select id="choices">
        <option>Immediately remove the event listener after it's added.</option>
        <option>Set `element` to `null` after attaching the event listener.</option>
        <option id="correct-answer">Remove the event listener when it's no longer needed or when the element is removed from the document.</option>
        <option>Nothing; the browser will automatically clean it up.</option>
    </select>
</div>

Good luck with your practice, and remember to take your time to think through each problem thoroughly before answering!