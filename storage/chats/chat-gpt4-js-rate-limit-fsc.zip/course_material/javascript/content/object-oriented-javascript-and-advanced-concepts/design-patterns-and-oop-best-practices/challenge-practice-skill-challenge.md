## Practice Skill Challenge

### Problem 1: Design Patterns Recognition

You've learned that design patterns in JavaScript are templates for solving frequently encountered problems. Let's see how well you can recognize patterns by their description.

<div id="answerable-multiple-choice">
    <p id="question">Which design pattern restricts object creation for a class to only one instance?</p>
    <select id="choices">
        <option>Module Pattern</option>
        <option>Prototype Pattern</option>
        <option id="correct-answer">Singleton Pattern</option>
        <option>Observer Pattern</option>
    </select>
</div>

### Problem 2: Module Pattern

The Module Pattern is one of the fundamental design patterns in JavaScript. It helps to encapsulate and organize your code.

<div id="answerable-code-editor">
    <p id="question">Fix the following JavaScript code so that variable `mySecretNumber` remains private and cannot be accessed directly outside the `SecretNumberModule`.</p>
    <p id="correct-answer">// Corrected Module Pattern
const SecretNumberModule = (function() {
    let mySecretNumber = 42; // This is now private

    function revealSecret() {
        console.log(mySecretNumber); // This is public
    }

    return {
        reveal: revealSecret
    };
})();

console.log(SecretNumberModule.mySecretNumber); // should be undefined
SecretNumberModule.reveal(); // should output 42</p>
</div>

### Problem 3: Observer Pattern

The Observer Pattern is particularly useful for creating an event management system where you can subscribe and unsubscribe to certain events.

<div id="answerable-multiple-choice">
    <p id="question">When applying the Observer Pattern, what method would you typically use to notify all observers about a state change?</p>
    <select id="choices">
        <option id="correct-answer">notify()</option>
        <option>update()</option>
        <option>onStateChange()</option>
        <option>notifyObservers()</option>
    </select>
</div>

### Problem 4: Namespaces

Namespaces help organize blocks of code into well-defined segments, making it easier to maintain large codebases.

<div id="answerable-code-editor">
    <p id="question">Create a simple namespace called `MyApp` and inside it, a `Logger` module with one method `log` that takes a string message and console logs it with a prefix "[MyApp]".</p>
    <p id="correct-answer">var MyApp = MyApp || {};

MyApp.Logger = (function() {
    function log(message) {
        console.log("[MyApp] " + message);
    }

    return {
        log: log
    };
})();

MyApp.Logger.log('Hello World!'); // should output '[MyApp] Hello World!'</p>
</div>

### Problem 5: Encapsulation in OOP

Understanding encapsulation is crucial for creating objects that control the access to their internal state.

<div id="answerable-fill-blank">
    <p id="question">In JavaScript classes, which symbol is used before a method name to make it private and only accessible within the class?</p>
    <p id="correct-answer">#</p>
</div>

Feel free to take your time with these problems. They are designed to challenge your understanding of the concepts covered so far. Good luck!