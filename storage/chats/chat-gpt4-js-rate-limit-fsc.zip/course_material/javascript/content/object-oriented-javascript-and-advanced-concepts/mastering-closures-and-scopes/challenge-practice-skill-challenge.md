# Practice Skill Challenge

Great job making it to this point! Now it’s time to put your understanding of JavaScript scope and closures to the test. Below, you'll find five practice problems that will help solidify your knowledge of the concepts covered in the course. Each problem comes with an answerable component, allowing you to put your skills into action.

Let's get started and see how well you've mastered the art of scopes and closures!

---

### Problem 1: Understanding Global Scope

<div id="answerable-code-editor">
    <p id="question">Write the JavaScript code that declares a global variable named `concertLocation` and sets its value to "Central Park".</p>
    <p id="correct-answer">let concertLocation = "Central Park";</p>
</div>

---

### Problem 2: Function Scope Recognition

<div id="answerable-multiple-choice">
    <p id="question">Select the statement that will log `undefined` due to the variable's scope being limited to the function `backstageArea()`.</p>
    <select id="choices">
        <option>console.log(accessPass);</option>
        <option>console.log(backstagePass);</option>
        <option id="correct-answer">console.log(artistCredential);</option>
        <option>console.log(stageAccess);</option>
    </select>
</div>
> Context: Given the snippet below, assume the console.log statement is outside the function.
```javascript
function backstageArea() {
    let artistCredential = "VIP Pass";
    // More code...
}
```

---

### Problem 3: Local vs Global Variables

<div id="answerable-multiple-choice">
    <p id="question">If the function `setupStage()` is called, which console.log statement will print "Local Celebrity"?</p>
    <select id="choices">
        <option id="correct-answer">console.log(headliner); (inside the function)</option>
        <option>console.log(headliner); (outside the function)</option>
        <option>console.log(openingAct); (inside the function)</option>
        <option>console.log(openingAct); (outside the function)</option>
    </select>
</div>
> Context: Given the snippet below:
```javascript
let headliner = "Global Celebrity";

function setupStage() {
    let headliner = "Local Celebrity";
    // More code...
}
```

---

### Problem 4: Identifying Closures

<div id="answerable-multiple-choice">
    <p id="question">Does the following function create a closure?</p>
    <select id="choices">
        <option>No, because it does not use any outer variables.</option>
        <option id="correct-answer">Yes, because the inner function `preserveLyrics` forms a closure with `lyricsDraft`.</option>
        <option>No, because `preserveLyrics` does not return anything.</option>
        <option>Yes, because all functions create closures.</option>
    </select>
</div>
> Context: Given the snippet below:
```javascript
function songwriter() {
    let lyricsDraft = "Verse 1...";
    function preserveLyrics() {
        return lyricsDraft;
    }
    return preserveLyrics;
}
```

---

### Problem 5: Fixing Loops with Closures

<div id="answerable-code-editor">
  <p id="question">The following loop is intended to create five buttons and set up an event listener for each, which alerts the number of the button when clicked. Rewrite the loop so that it works as intended using closures.</p>
  <p id="correct-answer">// Example correct solution
for (let i = 1; i <= 5; i++) {
    let buttonId = 'button' + i;
    document.getElementById(buttonId).addEventListener('click', function() {
        alert('You clicked button ' + i);
    });
}</p>
</div>

---

These problems are designed to help you think critically about the concepts you've learned. Take your time, work through each challenge, and remember that with practice, you will deepen your understanding of JavaScript's scope and closures. Good luck!