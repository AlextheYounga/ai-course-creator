# Practice Skill Challenge

Welcome to the Practice Skill Challenge! Here you'll apply what you've learned in the course by solving a series of problems designed to test your understanding of JavaScript, particularly with jQuery, DOM manipulation libraries, state management, and asynchronous updates. Ready to showcase your skills? Let's dive in!

### Problem 1: DOM Manipulation using jQuery

You're tasked with creating an interactive to-do list. When a user clicks on a to-do item, it should be removed from the list. Use jQuery to add this functionality.

```
<!-- Assume the HTML structure is as follows -->
<ul id="todoList">
    <li>Buy milk</li>
    <li>Walk the dog</li>
    <li>Learn jQuery</li>
</ul>
```

<div id="answerable-code-editor">
    <p id="question">Write a jQuery command that removes a list item from `#todoList` when it is clicked.</p>
    <p id="correct-answer">$('#todoList li').click(function() { $(this).remove(); });</p>
</div>

---

### Problem 2: Event Handling with jQuery

Consider a webpage with a button that has the ID `clickMe`. You want to show an alert with the message "Button clicked!" whenever this button is clicked.

<div id="answerable-code-editor">
    <p id="question">Using jQuery, write the code to show an alert with the message "Button clicked!" when the button with ID `clickMe` is clicked.</p>
    <p id="correct-answer">$('#clickMe').click(function() { alert('Button clicked!'); });</p>
</div>

---

### Problem 3: Understanding State Management Principles

The predictability of state changes is crucial in managing the user interface. Redux relies on certain principles to ensure the state management is reliable and predictable.

<div id="answerable-multiple-choice">
    <p id="question">Which of the following best describes one of the principles of Redux?</p>
    <select id="choices">
        <option>The state should be managed by multiple disparate sources to increase robustness.</option>
        <option>All changes to the state should be done synchronously to maintain a stable system.</option>
        <option id="correct-answer">The only way to change the state is to dispatch an action.</option>
        <option>The state is mutable and can be changed by any part of the application at any time.</option>
    </select>
</div>

---

### Problem 4: Asynchronous State Updates with Redux Saga

Assume you're handling the state of product availability in an e-commerce app, and you want to check for product updates using `Redux Saga`. A successful check will dispatch an action type `PRODUCT_AVAILABLE` with the product information, while a failure will dispatch an action type `CHECK_FAILED` with an error message.

<div id="answerable-code-editor">
    <p id="question">Write the Redux Saga code snippet that performs the asynchronous operation of checking product availability.</p>
    <p id="correct-answer">function* checkProductAvailability(action) {
  try {
    const product = yield call(Api.checkAvailability, action.productId);
    yield put({type: "PRODUCT_AVAILABLE", product: product});
  } catch (e) {
    yield put({type: "CHECK_FAILED", message: e.message});
  }
}</p>
</div>

---

### Problem 5: AJAX Requests with jQuery

You are developing a feature for a weather application that displays weather information based on a city name that a user enters. Use jQuery to make an AJAX call to a hypothetical weather API at `https://api.weatherapi.com/v1/current.json`.

<div id="answerable-code-editor">
    <p id="question">Using jQuery, write an AJAX request to the weather API that logs the response to the console. Assume the API key is `YOUR_API_KEY`, and the city name is stored in a variable named `cityName`.</p>
    <p id="correct-answer">$.ajax({
  url: `https://api.weatherapi.com/v1/current.json?key=YOUR_API_KEY&q=${cityName}`,
  type: 'GET',
  dataType: 'json',
  success: function(data) {
    console.log(data);
  },
  error: function(error) {
    console.error('Request failed', error);
  }
});</p>
</div>

---

Complete these challenges to reinforce your understanding of JavaScript and jQuery topics covered in the course. Good luck!