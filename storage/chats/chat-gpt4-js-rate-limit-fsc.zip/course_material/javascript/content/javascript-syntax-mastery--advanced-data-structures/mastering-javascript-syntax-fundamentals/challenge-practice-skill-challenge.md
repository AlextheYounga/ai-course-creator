# Practice Skill Challenge

Put your JavaScript knowledge to the test with these practice problems! Each one is designed to reinforce your understanding of the concepts we've covered in the course so far. Tackle them to check your mastery of JavaScript syntax, variables, data types, expressions, operators, and more.

## Problem 1: Understanding JavaScript Usage (Multiple Choice)
What are some common uses for JavaScript in web development?
<div id="answerable-multiple-choice">
    <p id="question">Which of the following is NOT a common use of JavaScript?</p>
    <select id="choices">
        <option>Animating web page elements</option>
        <option>Styling HTML elements</option>
        <option id="correct-answer">Directly modifying server-side databases</option>
        <option>Validating user input on a form</option>
    </select>
</div>

## Problem 2: Variable Declaration (Multiple Choice)
<div id="answerable-multiple-choice">
    <p id="question">What keyword indicates that a variable’s value can change over time in JavaScript?</p>
    <select id="choices">
        <option id="correct-answer">let</option>
        <option>constant</option>
        <option>var</option>
        <option>change</option>
    </select>
</div>

## Problem 3: Strings Concatenation (Code Editor/Code Executor)
<div id="answerable-code-editor">
    <p id="question">Write a function that takes two strings as arguments and returns the concatenation of the two strings.</p>
    <p id="correct-answer">function concatStrings(str1, str2) {
  return str1 + str2;
}</p>
</div>

## Problem 4: Working with Booleans (Multiple Choice)
<div id="answerable-multiple-choice">
    <p id="question">In JavaScript, which value does NOT represent a boolean data type?</p>
    <select id="choices">
        <option>true</option>
        <option>false</option>
        <option id="correct-answer">'maybe'</option>
        <option>'false'</option>
    </select>
</div>

## Problem 5: Data Types Knowledge (Fill in the Blank)
<div id="answerable-fill-blank">
    <p id="question">In JavaScript, which data type is commonly used to represent numbers?</p>
    <p id="correct-answer">Number</p>
</div>

---

Once you've completed these challenges, review your answers to ensure your understanding matches the JavaScript concepts covered. If you find some concepts tricky, don't worry! Revisit the materials, practice a bit more, and you'll get the hang of it. Keep up the good work!