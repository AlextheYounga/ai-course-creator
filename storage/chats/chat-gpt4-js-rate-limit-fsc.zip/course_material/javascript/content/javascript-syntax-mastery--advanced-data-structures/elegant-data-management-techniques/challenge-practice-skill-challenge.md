# Practice Skill Challenge

---

### Challenge 1: Utilizing Filters for Efficient Data Access

Imagine you're managing a class grade book. You want to quickly find out which students have passed based on their grades. In JavaScript, this is a perfect opportunity to use the `.filter()` method.

**Instructions:**
Given an array of student objects, use JavaScript's `.filter()` method to create a new array containing only the students who have passed the course. A student has passed if their `grade` property is greater than or equal to 65.

```javascript
let students = [
  { name: 'Alice', grade: 50 },
  { name: 'Bob', grade: 80 },
  { name: 'Charlie', grade: 75 },
  { name: 'Dora', grade: 59 },
  { name: 'Eve', grade: 92 }
];
```

**Interactive Component: Code Editor/Code Executor**
<div id="answerable-code-editor">
    <p id="question">Write a function `getPassedStudents` that returns a new array containing only the students who have passed.</p>
    <p id="correct-answer">// Example function that solves the problem
function getPassedStudents(students) {
  return students.filter(student => student.grade >= 65);
}</p>
</div>

---

### Challenge 2: Efficient Data Access in a Digital Library

Suppose you are implementing a feature for a digital library to list all science fiction titles. Assume you have an array of book objects with properties `title` and `genre`.

**Instructions:**
Use the `.filter()` method to get an array of all books that belong to the 'Science Fiction' genre.

```javascript
let library = [
  { title: 'Dune', genre: 'Science Fiction' },
  { title: 'Pride and Prejudice', genre: 'Classic' },
  { title: '1984', genre: 'Science Fiction' },
  { title: 'The Great Gatsby', genre: 'Classic' }
];
```

**Interactive Component: Code Editor/Code Executor**
<div id="answerable-code-editor">
    <p id="question">Write a function `getSciFiTitles` that returns an array of titles of books from the 'Science Fiction' genre.</p>
    <p id="correct-answer">// Example function that solves the problem
function getSciFiTitles(library) {
  return library.filter(book => book.genre === 'Science Fiction').map(book => book.title);
}</p>
</div>

---

### Challenge 3: Working with Array Methods

You have been given the task to manipulate an array of numbers such that you filter out all odd numbers and then create a new array with the squares of the remaining even numbers.

**Instructions:**
Given an array of numbers, use the `.filter()` method to remove all odd numbers, and then the `.map()` method to create a new array containing the squares of the filtered numbers.

```javascript
let numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
```

**Interactive Component: Code Editor/Code Executor**
<div id="answerable-code-editor">
    <p id="question">Write a function `getSquaredEvens` that takes an array of numbers as an argument and returns a new array containing the squares of the even numbers only.</p>
    <p id="correct-answer">// Example function that solves the problem
function getSquaredEvens(numbers) {
  return numbers.filter(number => number % 2 === 0).map(number => number * number);
}</p>
</div>

---

### Challenge 4: Searching with Array Methods

In a customer database, you need to find all customers whose balance is below a certain threshold. The database is represented as an array of customer objects with `name` and `balance` properties.

**Instructions:**
Use the `.filter()` method to retrieve an array of customer names who have a balance less than 1000.

```javascript
let customers = [
  { name: 'Alice', balance: 500 },
  { name: 'Bob', balance: 1500 },
  { name: 'Charlie', balance: 600 },
  { name: 'Dora', balance: 1200 },
  { name: 'Eve', balance: 700 }
];
```

**Interactive Component: Code Editor/Code Executor**
<div id="answerable-code-editor">
    <p id="question">Write a function `findLowBalanceCustomers` that returns an array of names of customers with balances below 1000.</p>
    <p id="correct-answer">// Example function that solves the problem
function findLowBalanceCustomers(customers) {
  return customers.filter(customer => customer.balance < 1000).map(customer => customer.name);
}</p>
</div>

---

### Challenge 5: Optimizing Searches with Array Methods

Consider you have a list of transactions and need to find all transactions that have been successfully completed and have an amount greater than a specified value.

**Instructions:**
Given an array of transaction objects with properties `status` and `amount`, use the `.filter()` method to get an array of all successful transactions (`status` is 'completed') with an `amount` greater than 1000.

```javascript
let transactions = [
  { status: 'completed', amount: 1500 },
  { status: 'failed', amount: 200 },
  { status: 'completed', amount: 500 },
  { status: 'completed', amount: 2000 },
  { status: 'pending', amount: 1500 }
];
```

**Interactive Component: Code Editor/Code Executor**
<div id="answerable-code-editor">
    <p id="question">Write a function `getHighValueTransactions` that returns an array of transactions that are completed with an amount greater than 1000.</p>
    <p id="correct-answer">// Example function that solves the problem
function getHighValueTransactions(transactions) {
  return transactions.filter(transaction => transaction.status === 'completed' && transaction.amount > 1000);
}</p>
</div>

---

Good luck with these challenges and happy coding! Use what you've learned about efficient data access and array manipulation to tackle these problems.