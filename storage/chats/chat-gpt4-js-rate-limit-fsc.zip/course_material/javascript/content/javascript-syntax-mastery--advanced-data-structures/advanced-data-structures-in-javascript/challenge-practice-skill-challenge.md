# Practice Skill Challenge

Well done on making it this far! It's time to put your knowledge to the test with this set of practice problems. These problems aim to reinforce your understanding of the JavaScript concepts we've discussed, including objects, key-value pairs, JSON parsing and stringifying, and utilizing more sophisticated data structures like Maps and Sets. Ready to show what you've learned? Let's go!

### Problem 1: Accessing Object Properties
You are provided with an object that stores information about a book. Find the right way to access the title of the book from the object.

```javascript
let bookDetails = {
    title: 'Learning JavaScript',
    author: 'John Doe',
    pageCount: 350
};
```
<div id="answerable-multiple-choice">
    <p id="question">How would you access the title of the book from the bookDetails object?</p>
    <select id="choices">
        <option>bookDetails['title']</option>
        <option id="correct-answer">bookDetails.title</option>
        <option>bookDetails(title)</option>
        <option>title.bookDetails</option>
    </select>
</div>

### Problem 2: Extracting Information from Nested Structures
Given a nested structure representing a school's departments and their respective courses, how would you extract the list of all courses in the 'Science' department?

```javascript
let schoolDepartments = {
    Science: ['Biology', 'Chemistry', 'Physics'],
    Mathematics: ['Algebra', 'Calculus', 'Statistics'],
    Literature: ['English', 'French', 'Spanish']
};
```
<div id="answerable-multiple-choice">
    <p id="question">Which expression gets you the array of 'Science' department courses?</p>
    <select id="choices">
        <option id="correct-answer">schoolDepartments.Science</option>
        <option>schoolDepartments['Science']</option>
        <option>schoolDepartments.Science[0]</option>
        <option>Science.schoolDepartments</option>
    </select>
</div>

### Problem 3: Parsing JSON Objects
Given a JSON string that contains configuration settings for a user's dashboard, parse the JSON to a JavaScript object and access the theme chosen by the user.

```json
'{"theme": "dark", "language": "English", "notifications": true}'
```
<div id="answerable-code-editor">
    <p id="question">Write a line of JavaScript code that parses the JSON string and provide the code to access the user's theme setting.</p>
    <p id="correct-answer">// let dashboardSettings = JSON.parse('{"theme": "dark", "language": "English", "notifications": true}');
// dashboardSettings.theme;</p>
</div>

### Problem 4: Converting Objects to JSON Strings
You have an object representing a user's gaming profile. Convert this object into a JSON string that could be sent to a gaming leaderboard API.

```javascript
let gamingProfile = {
    username: 'Player1',
    level: 42,
    highScore: 215678
};
```
<div id="answerable-code-editor">
    <p id="question">Use JSON.stringify() to convert the gamingProfile object into a JSON string.</p>
    <p id="correct-answer">// let profileString = JSON.stringify(gamingProfile);</p>
</div>

### Problem 5: Basic Operations with Maps
You're given a map that stores user IDs associated with their email addresses. Add a new user to the map with a unique ID and an email address, and show how you would retrieve the email for that user.

```javascript
let userMap = new Map([
    [101, 'john.doe@example.com'],
    [102, 'jane.smith@example.com']
]);
```
<div id="answerable-code-editor">
    <p id="question">Add a new user with ID 103 and email 'alex.jones@example.com' to the userMap and provide the code to retrieve Alex's email using their user ID.</p>
    <p id="correct-answer">// userMap.set(103, 'alex.jones@example.com');
// userMap.get(103);</p>
</div>

Best of luck with these practice problems. They've been crafted to challenge and review the key points from the eLearning course. Once you've worked through these questions, you will be better prepared to utilize JavaScript's data structures and objects in your coding projects. Keep practicing and continue to build your JavaScript foundation. Happy coding!