# Making Asynchronous Calls with XMLHttpRequest

Picture a world where every time you turn the page of a book, you have to close it, open it again at the cover, and flip through each page to get where you left off. That would be quite a tedious process, wouldn't it? Well, that's analogous to the traditional way web pages used to work before the advent of AJAX. Every time you requested new content, the whole page would reload, even if the change was small, like checking if a username was available.

Enter `XMLHttpRequest` (XHR), a JavaScript object that allows us to communicate with servers without requiring a full page refresh. It's the magic behind the curtain for many features on the web today, like when your email automatically updates without you having to press a button.

Let's dive into how `XMLHttpRequest` can be used to make a call to a server. 

First, you need to create a new instance of an `XMLHttpRequest` object:

```javascript
var xhr = new XMLHttpRequest();
```

Then, you must define what happens when you receive a response from the server, known as an event handler for the `onreadystatechange` event. This event is fired every time the `readyState` of the `XMLHttpRequest` changes.

```javascript
xhr.onreadystatechange = function() {
    if(xhr.readyState === 4 && xhr.status === 200) {
        // Parse the JSON response
        var jsonData = JSON.parse(xhr.responseText);

        // Take action with the data
        console.log(jsonData);
    }
};
```

Here, `readyState` of 4 means the request is done, and `status` of 200 means it was successful. If everything checks out, we parse the response and do something with it.

Next, we open a new request using the `.open` method, where we define the request type and where it is going:

```javascript
xhr.open('GET', 'https://api.example.com/data', true);
```

The `GET` method indicates we're retrieving data, the URL specifies where from, and the `true` parameter makes it asynchronous.

Finally, we send the request with the `.send` method:

```javascript
xhr.send();
```

And that's it! The request is out in the wild, fetching data without disturbing the user experience.

Think of it as sending a text message to a friend asking for the latest gossip. While you wait for the response, life goes on; you don't just stop everything and stare at the phone. When the juicy details do come in, your phone buzzes, and you can dive right into the conversation. That's the non-blocking beauty of async!

Now, let's test your understanding with a simple challenge.

<div id="answerable-code-editor">
    <p id="question">Write the missing parts of the following JavaScript code snippet to make an asynchronous GET request to 'https://api.example.com/data' and log the response to the console.</p>
    <p id="correct-answer">
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
        if(xhr.readyState === 4 && xhr.status === 200) {
            console.log(xhr.responseText);
        }
    };
    xhr.open('GET', 'https://api.example.com/data', true);
    xhr.send();
    </p>
</div>

This simple exercise immerses you in the basic mechanics of making asynchronous calls with `XMLHttpRequest`. It sets the foundation for more powerful and intricate operations you can perform to bring dynamism and responsiveness to your web applications.