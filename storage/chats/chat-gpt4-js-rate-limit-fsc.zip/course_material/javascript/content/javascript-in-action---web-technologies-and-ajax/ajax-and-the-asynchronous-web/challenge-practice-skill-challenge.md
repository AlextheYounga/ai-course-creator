## Practice Skill Challenge: Putting AJAX and Asynchronous JavaScript to the Test

Great job making it through the material on AJAX and asynchronous JavaScript! Now it's time to put your knowledge to the test. Here are five practice problems that will help you assess your understanding of the concepts covered in this course. Choose your answers thoughtfully, as they will determine how well you've grasped the intricacies of making web applications dynamic and responsive.

### Problem 1: Making Asynchronous Calls
You're tasked with implementing a feature to display live weather updates on a website without refreshing the page.

<div id="answerable-multiple-choice">
    <p id="question">Which feature allows you to update the page with new data asynchronously?</p>
    <select id="choices">
        <option>Using only a basic HTML form</option>
        <option>An automated page refresh every few seconds</option>
        <option>Client-side cookies to store fetched data</option>
        <option id="correct-answer">AJAX calls to fetch and display new data without page refresh</option>
    </select>
</div>

### Problem 2: Understanding HTTP Requests
Imagine you're logging into a social media website. When you enter your username and password and hit the login button, an HTTP request is made.

<div id="answerable-multiple-choice">
    <p id="question">What HTTP method does the browser use to safely transmit your login details to the server?</p>
    <select id="choices">
        <option>GET</option>
        <option id="correct-answer">POST</option>
        <option>PUT</option>
        <option>DELETE</option>
    </select>
</div>

### Problem 3: Handling Server Responses
You've made an AJAX request to a server for a list of the latest sports scores. You want to run a certain block of code only when the request is complete and successful.

<div id="answerable-multiple-choice">
    <p id="question">What `readyState` and `status` should you check for in your `XMLHttpRequest`'s `onreadystatechange` event handler?</p>
    <select id="choices">
        <option>`readyState === 2` and `status === 200`</option>
        <option>`readyState === 3` and `status === 303`</option>
        <option>`readyState === 1` and `status === 201`</option>
        <option id="correct-answer">`readyState === 4` and `status === 200`</option>
    </select>
</div>

### Problem 4: Data Interchange Formats
You're sending a request to an API that will return a list of book titles related to the search term the user has entered. The response from the API is expected to be lightweight and easily parseable.

<div id="answerable-multiple-choice">
    <p id="question">What is the most-used data interchange format that you'll likely encounter in the response?</p>
    <select id="choices">
        <option>Plain text</option>
        <option>XML</option>
        <option id="correct-answer">JSON</option>
        <option>BSON</option>
    </select>
</div>

### Problem 5: Fetch API vs. XMLHttpRequest

You're refactoring old code in a web application and are moving from `XMLHttpRequest` to the Fetch API.

<div id="answerable-multiple-choice">
    <p id="question">Which statement is true when comparing Fetch API with `XMLHttpRequest`?</p>
    <select id="choices">
        <option>The Fetch API is less compatible with modern browsers than `XMLHttpRequest`.</option>
        <option id="correct-answer">Fetch API uses Promises, enabling a more streamlined way to handle asynchronous calls.</option>
        <option>`XMLHttpRequest` is the more modern technology with better support for error handling.</option>
        <option>JSON parsing must be manually implemented with Fetch API, unlike with `XMLHttpRequest`.</option>
    </select>
</div>

These problems are designed to recap and reinforce what you've learned throughout the course. Take your time, think through each question, and choose the answer that you believe aligns best with the course material. Good luck on your Practice Skill Challenge!