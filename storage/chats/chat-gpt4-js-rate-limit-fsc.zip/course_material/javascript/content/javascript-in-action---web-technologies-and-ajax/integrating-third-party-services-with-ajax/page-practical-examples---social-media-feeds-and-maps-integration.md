# Practical Examples - Social Media Feeds and Maps Integration

When you log into your favorite social media platform and see a stream of tweets or status updates flowing in, or when you visit a café's website and find a map showing its location, you're witnessing the power of integrating third-party services into websites. These practical features enhance user experiences by consolidating information and services directly into web pages using AJAX calls to Web APIs.

## Integrating Social Media Feeds

Social media feeds enable users to engage with the latest content without needing to jump between different platforms. If you're running a conference, for instance, you might want to display a live Twitter feed on your event's homepage to showcase participants' tweets in real-time. Let's break down this task into more digestible parts, like a chef deconstructing a recipe into simple ingredients.

First, you'll need to connect with the social media platform's API. After obtaining authorization, typically through OAuth, you make a call to the API's endpoint that serves the feed data. Your AJAX call would look something like this:

```javascript
fetch('https://api.twitter.com/1.1/statuses/user_timeline.json?screen_name=yourEvent&count=10')
  .then(response => response.json())
  .then(tweets => {
    // Code to handle the array of tweets received
  })
  .catch(error => console.error('Error:', error));
```

Just like how you follow a specific recipe to bake a cake, you'd replace `yourEvent` with your specific Twitter handle and adjust the count of tweets you want to display.

## Embedding Maps on Websites

Similarly, if you want to embed an interactive map on your website to help users find your business location, you'd use an API provided by a mapping service such as Google Maps or Mapbox. Once you've registered for an API key and set up your account, integrating the map involves writing a script to include the map and specifying which part of the world to zoom in on, marking the spot like an X on a pirate's treasure map.

Here's a basic snippet to embed a Google Map using their Maps JavaScript API:

```javascript
function initMap() {
  const myCafeLocation = { lat: -25.363, lng: 131.044 };
  const map = new google.maps.Map(document.getElementById("map"), {
    zoom: 16,
    center: myCafeLocation,
  });
  new google.maps.Marker({
    position: myCafeLocation,
    map,
    title: "My Café Here",
  });
}
```

Once you've added this to your page, users will be greeted by an interactive map pinpointing your café's location – a solid golden doubloon in a sea of information!

<div id="answerable-multiple-choice">
    <p id="question">Which API provides the authentication mechanism commonly used to connect with social media platforms?</p>
    <select id="choices">
        <option>API Key</option>
        <option>Basic Authentication</option>
        <option id="correct-answer">OAuth</option>
        <option>Bearer Token</option>
    </select>
</div>

By adding social media feeds and maps to your site, you enable a more cohesive and dynamic online presence. Users can sip on the fresh stream of social brews and navigate the digital terrain of your terrain, all while staying on your webpage. It's like having a multitool in the web developer's pocket – practical, efficient, and neat!