# Practice Skill Challenge: Mastering AJAX and Web APIs

It's time to put your knowledge to the test! The following questions are designed to reinforce your understanding of AJAX and Web APIs as covered in the course. Each challenge will require you to apply what you've learned in a practical context. Good luck!

### Challenge 1 - Understanding Web APIs
<div id="answerable-multiple-choice">
    <p id="question">When adding an event to your Google Calendar via a web application, the Application Programming Interface (API) used by the application serves what purpose?</p>
    <select id="choices">
        <option>Tells your computer to open the calendar application</option>
        <option id="correct-answer">Informs the server of what action to perform</option>
        <option>Updates the webpage to show the current date and time</option>
        <option>Directly modifies the data on the server without any intermediary</option>
    </select>
</div>

---

### Challenge 2 - AJAX Requests and Promises
<div id="answerable-multiple-choice">
    <p id="question">When using the `fetch` API in JavaScript to send a request to a RESTful service, what type of object is returned, and how is the response accessed?</p>
    <select id="choices">
        <option>The fetch API returns an Array object that directly contains the server's response data.</option>
        <option>The fetch API returns an XMLHttpRequest object that can be used to read the response data.</option>
        <option id="correct-answer">The fetch API returns a Promise object that resolves to the Response object containing the response to the request.</option>
        <option>The fetch API sends an event to the browser, and the response is accessed through a callback function.</option>
    </select>
</div>

---

### Challenge 3 - Displaying Fetched Data
<div id="answerable-code-editor">
    <p id="question">Write a snippet of JavaScript code using the `fetch` API that retrieves data from `https://api.example.com/items` and logs each item's `name` to the console.</p>
    <p id="correct-answer">fetch('https://api.example.com/items')\n  .then(response => response.json())\n  .then(data => data.forEach(item => console.log(item.name)))\n  .catch(error => console.error('Error:', error));</p>
</div>

---

### Challenge 4 - Managing Authentication in AJAX
<div id="answerable-multiple-choice">
    <p id="question">Which HTTP header is commonly used to include an authentication token in an AJAX request to a server?</p>
    <select id="choices">
        <option>Accept-Language</option>
        <option>User-Agent</option>
        <option id="correct-answer">Authorization</option>
        <option>Content-Length</option>
    </select>
</div>

---

### Challenge 5 - Real-World API Utilization
<div id="answerable-multiple-choice">
    <p id="question">If you integrate a live Twitter feed into your website, which method of authorization will typically be used to authenticate your web application to Twitter's API for secure access to Twitter data?</p>
    <select id="choices">
        <option id="correct-answer">OAuth</option>
        <option>API Key Authentication</option>
        <option>Basic Authentication with username and password</option>
        <option>SSH Key Authentication</option>
    </select>
</div>

---

Congratulations on completing the Practice Skill Challenge! Review your answers carefully, and try to understand any mistakes. Strong command over AJAX and Web APIs will greatly enhance your ability to create dynamic, responsive, and secure web applications. Keep honing your skills—practice leads to mastery!