# Practice Skill Challenge

Welcome to the Practice Skill Challenge! Below are 5 questions to test your understanding of AJAX and its application in web development. Use the knowledge you've gained from the course to solve these problems. Let's see how much you've learned!

### Question 1: The Role of AJAX

<div id="answerable-multiple-choice">
    <p id="question">What is the main purpose of using AJAX in web applications?</p>
    <select id="choices">
        <option>To create a static webpage that doesn't change.</option>
        <option id="correct-answer">To update parts of a webpage without reloading the entire page.</option>
        <option>To make the web pages load slower and with more security.</option>
        <option>To design intricate graphics for web applications.</option>
    </select>
</div>

### Question 2: AJAX Techniques

<div id="answerable-multiple-choice">
    <p id="question">Which JavaScript feature forms the basis of AJAX to allow asynchronous web requests?</p>
    <select id="choices">
        <option>JSON.parse()</option>
        <option id="correct-answer">XMLHttpRequest object</option>
        <option>document.getElementByID()</option>
        <option>console.log()</option>
    </select>
</div>

### Question 3: Submitting Forms with AJAX

<div id="answerable-code-editor">
    <p id="question">// Write an AJAX script that sends form data to a server endpoint '/submit-form' using the POST method and logs 'Form Submitted!' to the console if successful.</p>
    <p id="correct-answer">// Example correct answer:
function submitForm(formData) {
  var xhr = new XMLHttpRequest();
  xhr.open('POST', '/submit-form', true);
  xhr.onreadystatechange = function() {
    if (xhr.readyState == 4 && xhr.status == 200) {
      console.log('Form Submitted!');
    }
  };
  xhr.send(formData);
}</p>
</div>

### Question 4: Validating Email with Regular Expressions

<div id="answerable-code-editor">
    <p id="question">// Create a JavaScript function that uses a regular expression to validate if a string input is a valid email address and logs 'Valid' or 'Invalid' to the console.</p>
    <p id="correct-answer">// Example correct answer:
function validateEmail(email) {
  var pattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
  if (email.match(pattern)) {
    console.log('Valid');
    return true;
  } else {
    console.log('Invalid');
    return false;
  }
}</p>
</div>

### Question 5: Pagination with AJAX

<div id="answerable-code-editor">
    <p id="question">// Implement an AJAX function that is triggered when a 'Next Page' button is clicked. It should request new content from '/page-2' and update the innerHTML of the 'content-area' div. Assume success if the server response has a status of 200.</p>
    <p id="correct-answer">// Example correct answer:
function nextPage() {
  var xhr = new XMLHttpRequest();
  xhr.open('GET', '/page-2', true);
  xhr.onreadystatechange = function() {
    if (xhr.readyState == 4 && xhr.status == 200) {
      document.getElementById('content-area').innerHTML = xhr.responseText;
    }
  };
  xhr.send();
}</p>
</div>

Complete these challenges to hone your AJAX skills and prepare yourself for creating dynamic, real-time web applications. Remember, it's all about enhancing the user experience with smooth, uninterrupted interactions. Happy coding!