# Practice Skill Challenge

Welcome to your Practice Skill Challenge! These practice problems will test your knowledge on the materials covered in the course so far, including data persistence, JavaScript database interactions, CRUD operations, session management, in-memory caching, and data security. It's time to put what you've learned to the test!

### Question 1: Data Persistence
<div id="answerable-multiple-choice">
    <p id="question">Which JavaScript object allows you to store data that outlives the current page session and persists even after the browser is closed?</p>
    <select id="choices">
        <option>`sessionStorage`</option>
        <option id="correct-answer">`localStorage`</option>
        <option>`cookies`</option>
        <option>`globalStorage`</option>
    </select>
</div>

### Question 2: CRUD Operations
<div id="answerable-code-editor">
    <p id="question">Using Mongoose, write a JavaScript function named `deleteUser` that takes a userId as a parameter and deletes the user from a database. Assume that you have a model User which has a method `findByIdAndRemove`.</p>
    <p id="correct-answer">function deleteUser(userId) {\n  User.findByIdAndRemove(userId, function(err) {\n    if (err) return handleError(err);\n    // User is deleted\n  });\n}</p>
</div>

### Question 3: Sessions and Persistent User Data
<div id="answerable-multiple-choice">
    <p id="question">In web development, what is a "session" typically used for?</p>
    <select id="choices">
        <option>Persisting user data across multiple visits to a website</option>
        <option>Storing data temporarily during a single visit to a website</option>
        <option id="correct-answer">Temporarily storing information about the user's interaction with a website, which is discarded after the session ends</option>
        <option>Encrypting user data sent between the client and server</option>
    </select>
</div>

### Question 4: Caching Strategies
<div id="answerable-multiple-choice">
    <p id="question">What is the main benefit of implementing caching strategies in web development?</p>
    <select id="choices">
        <option id="correct-answer">Minimizing database hits to improve application performance</option>
        <option>Storing permanent records of user interactions for analytics</option>
        <option>Encrypting sensitive user data to prevent unauthorized access</option>
        <option>Verifying user identities to ensure secure transactions</option>
    </select>
</div>

### Question 5: Data Security and Integrity
<div id="answerable-multiple-choice">
    <p id="question">Which of the following best describes how JSON Web Tokens (JWT) are used in web applications?</p>
    <select id="choices">
        <option>To encrypt data stored in the database</option>
        <option>To decrease the load times of web pages</option>
        <option id="correct-answer">To authenticate users and authorize access to certain routes</option>
        <option>To increase the storage capacity on the client side</option>
    </select>
</div>

Great job tackling these practice problems! Review the materials as needed and keep practicing to solidify your understanding of these key concepts.