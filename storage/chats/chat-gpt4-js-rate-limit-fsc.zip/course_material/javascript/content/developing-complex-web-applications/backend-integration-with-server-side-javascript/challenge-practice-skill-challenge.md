### Practice Skill Challenge

Test your knowledge with these practice problems based on the material covered in our JavaScript and Node.js course. Tackle each one to cement your understanding and prepare yourself for working on real-world applications!

#### Question 1: Understanding Node.js Modules
<div id="answerable-multiple-choice">
    <p id="question">To use the HTTP module in Node.js, which command do you need to execute to import it?</p>
    <select id="choices">
        <option>const http = import('http');</option>
        <option id="correct-answer">const http = require('http');</option>
        <option>import http from 'http';</option>
        <option>require('http', function (http) {});</option>
    </select>
</div>

#### Question 2: Package Initialization
<div id="answerable-multiple-choice">
    <p id="question">What command will create a 'package.json' file in your Node.js project?</p>
    <select id="choices">
        <option>node init package.json</option>
        <option>npm create json</option>
        <option id="correct-answer">npm init</option>
        <option>npm start</option>
    </select>
</div>

#### Question 3: Working with Express.js
<div id="answerable-multiple-choice">
    <p id="question">In Express, if you wanted to send back a status code indicating a successful GET request, what status code would you use?</p>
    <select id="choices">
        <option id="correct-answer">200</option>
        <option>404</option>
        <option>500</option>
        <option>302</option>
    </select>
</div>

#### Question 4: RESTful API Methods
<div id="answerable-multiple-choice">
    <p id="question">Which HTTP method is used to update an existing resource in a RESTful API?</p>
    <select id="choices">
        <option>POST</option>
        <option>GET</option>
        <option id="correct-answer">PUT</option>
        <option>HEAD</option>
    </select>
</div>

#### Question 5: Sequelize Usage
<div id="answerable-code-editor">
    <p id="question">Using Sequelize, how would you find a user with the ID of 3 in the database?</p>
    <p id="correct-answer">User.findByPk(3)</p>
</div>

Great work going through these practice challenges! Remember, each step you take strengthens your understanding of JavaScript and Node.js, setting you up for success in your web development journey. Keep practicing, and you'll be a pro in no time!