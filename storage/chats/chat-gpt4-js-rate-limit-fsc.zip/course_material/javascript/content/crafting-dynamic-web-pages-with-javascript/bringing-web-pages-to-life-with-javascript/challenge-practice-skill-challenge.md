# Practice Skill Challenge: JavaScript Essentials

Congratulations on reaching this point in the JavaScript Essentials course! To solidify your understanding and assess your skills, tackle these five practice problems. Each one is based on the material we've explored so far. Read each question carefully, and when you feel ready, write the code or select the correct answer.

Good luck, and remember – the real learning happens when you apply what you know!

### Question 1: Selecting DOM Elements

The HTML page contains several paragraphs (`<p>`), but you're interested in the one that speaks about "JavaScript benefits". This particular paragraph has an ID of "js-benefits". Write the JavaScript code to select this paragraph.

<div id="answerable-code-editor">
    <p id="question">Write the JavaScript code that selects the paragraph with the ID of "js-benefits".</p>
    <p id="correct-answer">document.getElementById('js-benefits');</p>
</div>

### Question 2: Responding to User Events

You have a button on your webpage that says "Greet Me!" and has the ID of "greet-button". Your task is to add a JavaScript event listener to this button, so when it is clicked, it displays an alert that says "Hello, world!".

<div id="answerable-multiple-choice">
    <p id="question">Which JavaScript snippet correctly adds a click event listener to a button with the ID "greet-button" that displays an alert?</p>
    <select id="choices">
        <option>document.querySelector('#greet-button').click = function() { alert('Hello, world!'); };</option>
        <option id="correct-answer">document.getElementById('greet-button').addEventListener('click', function() { alert('Hello, world!'); });</option>
        <option>document.querySelector('button#greet-button').addEventListener('onclick', function() { alert('Hello, world!'); });</option>
        <option>document.getElementById('greet').onclick = function() { alert('Hello, world!'); };</option>
    </select>
</div>

### Question 3: Manipulating DOM Elements

Create a JavaScript function called `changeHeadingColor` that changes the color of all `<h2>` elements to "blue". Assume that these `<h2>` tags don't have any class or ID associated.

<div id="answerable-code-editor">
    <p id="question">Write a JavaScript function named "changeHeadingColor" that changes the color of all `<h2>` elements to "blue".</p>
    <p id="correct-answer">
function changeHeadingColor() {
  var headings = document.getElementsByTagName('h2');
  for (var i = 0; i < headings.length; i++) {
    headings[i].style.color = 'blue';
  }
}
    </p>
</div>

### Question 4: Dynamic Content Update

Assuming you have a `<div>` with the ID "time-display" on your page, write a JavaScript snippet that updates this `<div>` to display the current time in the format "HH:MM:SS", updating every second.

<div id="answerable-multiple-choice">
    <p id="question">Which JavaScript code snippet correctly updates a `<div>` with the ID "time-display" to show the current time every second?</p>
    <select id="choices">
        <option>setInterval(function() { document.querySelector('#time-display').innerText = new Date().toLocaleTimeString(); }, 1000);</option>
        <option id="correct-answer">setInterval(function() { document.getElementById('time-display').textContent = new Date().toLocaleTimeString(); }, 1000);</option>
        <option>setTimeout(function() { document.getElementById('time').innerText = new Date().toLocaleTimeString(); }, 1000);</option>
        <option>document.getElementById('time-display').addEventListener('load', function() { this.textContent = new Date().toLocaleTimeString(); });</option>
    </select>
</div>

### Question 5: Form Feedback

You have an input field for usernames with the ID "username-input". Write a JavaScript function that sets the border of the input to red if the username is less than 4 characters long and to green if it is 4 or more characters long. Attach this function to the "input" event of the input field.

<div id="answerable-code-editor">
    <p id="question">Write a JavaScript function that changes the border color of the "username-input" field based on the length of the input.</p>
    <p id="correct-answer">
document.getElementById('username-input').addEventListener('input', function() {
  if (this.value.length < 4) {
    this.style.borderColor = 'red';
  } else {
    this.style.borderColor = 'green';
  }
});
    </p>
</div>

These challenges are modeled after scenarios you might encounter while scripting for the web. Use this opportunity to apply the concepts you've learned and to test your problem-solving skills. When you're ready, try to solve the problems and write the code in your preferred environment. Keep practicing, and you'll continue to improve your JavaScript expertise!