# Practice Skill Challenge

Now that you've learned how to breathe life into web pages using HTML, CSS, and JavaScript, it's time to put your knowledge to the test! The following practice problems will challenge your understanding of JavaScript events, manipulating the DOM, and dynamically interacting with CSS. Ready to show off your skills? Here we go!

### Practice Problem 1: JavaScript Events and User Interaction
Imagine you have a button on a webpage that says "Buy Now," and when clicked, the text changes to "Item Purchased". Using only JavaScript, how would you modify this button's behavior upon clicking?

<div id="answerable-code-editor">
    <p id="question">Add the JavaScript necessary to change the button's text to "Item Purchased!" when it is clicked.</p>
    <p id="correct-answer">
document.getElementById('buyButton').addEventListener('click', function() {
  this.textContent = 'Item Purchased!';
});
    </p>
</div>

---

### Practice Problem 2: Inline vs External JavaScript
Which method of JavaScript inclusion is preferred if you want to ensure the same script functionality is available across multiple pages without rewriting the code and taking advantage of browser caching?

<div id="answerable-multiple-choice">
    <p id="question">Which of the following methods is best for cross-page script availability and browser caching?</p>
    <select id="choices">
        <option>Inline JavaScript with repeated code on each page</option>
        <option>Internal JavaScript added within script tags on every page</option>
        <option id="correct-answer">External JavaScript file linked to each HTML document</option>
        <option>JavaScript embedded in a style sheet</option>
    </select>
</div>

---

### Practice Problem 3: Dynamic CSS Modifications
How would you update the font size of a paragraph with the id `description` to `18px` dynamically using JavaScript?

<div id="answerable-code-editor">
    <p id="question">Write the JavaScript line that dynamically changes the font size of the paragraph with id `description` to `18px`.</p>
    <p id="correct-answer">
document.getElementById('description').style.fontSize = '18px';
    </p>
</div>

---

### Practice Problem 4: Class Management with JavaScript
You're working on a profile management application whereby clicking an "Edit Profile" button should switch the profile display from "view mode" to "edit mode". This is represented by adding a class named `edit-mode` to the `<div>` with id `profile-container`. How would you achieve this in JavaScript?

<div id="answerable-code-editor">
    <p id="question">Write the JavaScript that adds the `edit-mode` class to the element with id `profile-container` upon clicking the "Edit Profile" button.</p>
    <p id="correct-answer">
document.getElementById('editProfileButton').addEventListener('click', function() {
  document.getElementById('profile-container').classList.add('edit-mode');
});
    </p>
</div>

---

### Practice Problem 5: Working with CSS3 Animations
Given a CSS3 animation named `slide-in`, which smoothly transitions an element from the left side of the screen into view, how would you apply this animation to an element with the id `side-panel` using JavaScript as soon as the page loads?

<div id="answerable-code-editor">
    <p id="question">Write the JavaScript to apply the `slide-in` animation to the `side-panel` element on page load.</p>
    <p id="correct-answer">
window.onload = function() {
  document.getElementById('side-panel').classList.add('slide-in');
};
    </p>
</div>

---

These practice problems are designed to test essential web development skills and to sharpen your proficiency with JavaScript and its interaction with HTML and CSS. Solve these, and you'll power up your ability to create dynamic web experiences!