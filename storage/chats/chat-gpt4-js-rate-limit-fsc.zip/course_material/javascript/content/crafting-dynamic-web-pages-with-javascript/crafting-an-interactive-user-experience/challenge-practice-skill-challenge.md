# Practice Skill Challenge: JavaScript Event Handling and More

Test your event handling expertise and solidify your understanding of JavaScript with these interactive practice questions. Designed to review the key concepts from the lesson, tackle these challenges to demonstrate your mastery of the subject.

### Problem 1: Button Event Binding
Imagine you have an application with a user interface containing numerous buttons. For the button with the ID 'actionButton', you want to log a message to the console whenever the button is clicked.

<div id="answerable-code-editor">
    <p id="question">Write a snippet of JavaScript code to bind an event listener to the button with the ID 'actionButton' that logs "Action button was clicked!" to the console.</p>
    <p id="correct-answer">document.getElementById('actionButton').addEventListener('click', function() { console.log('Action button was clicked!'); });</p>
</div>

### Problem 2: Responding to a Timer
You're creating an interactive quiz where users have a limited time to answer each question. You want to alert the user that their time is up after 10 seconds have passed.

<div id="answerable-code-editor">
    <p id="question">Write a JavaScript `setTimeout` function that alerts the user with the message "Time's up!" after 10 seconds.</p>
    <p id="correct-answer">setTimeout(function() { alert("Time's up!"); }, 10000);</p>
</div>

### Problem 3: Preventing Default Event Behavior
In a web form, you have a 'submit' button. However, you want to validate the input fields when the user clicks the button instead of immediately submitting the form.

<div id="answerable-multiple-choice">
    <p id="question">Which of the following lines of code can prevent the form from being submitted when the 'submit' button is clicked?</p>
    <select id="choices">
        <option id="correct-answer">event.preventDefault()</option>
        <option>event.stopPropagation()</option>
        <option>event.stopImmediatePropagation()</option>
        <option>event.pausePropagation()</option>
    </select>
</div>

### Problem 4: AJAX Request
You are fetching data from an API to display new articles without refreshing the web page. You need to ensure the data request is complete and successful.

<div id="answerable-multiple-choice">
    <p id="question">Which of the following code blocks correctly checks if an AJAX request using `XMLHttpRequest` was successful?</p>
    <select id="choices">
        <option>if (xhr.readyState === 4 && xhr.status === 200) { // Process the response }</option>
        <option id="correct-answer">if (xhr.status === 200) { // Process the response }</option>
        <option>if (xhr.Done && xhr.OK) { // Process the response }</option>
        <option>if (xhr.complete === true) { // Process the response }</option>
    </select>
</div>

### Problem 5: Working with Intervals
You've designed a webpage with a live clock that updates every second. However, you want to provide the user with a button to stop the clock from updating.

<div id="answerable-fill-blank">
    <p id="question">Fill in the blank: To stop the clock's interval from running, the JavaScript function you would use is _________ followed by passing the relevant interval ID.</p>
    <p id="correct-answer">clearInterval</p>
</div>

Be sure to review the materials on JavaScript events, timers, intervals, and AJAX before attempting these problems. Good luck, and may the code be with you!