# Practice Skill Challenge: JavaScript Quality Assurance

Welcome to the Practice Skill Challenge! To become proficient at Quality Assurance in JavaScript, it's essential to put theory into practice. Let's test your knowledge and skills with a set of practice problems based on the materials provided in the course. Each challenge will focus on a different aspect of JavaScript QA, including writing test cases, unit testing with Jest, CI interactions, and cross-browser testing strategies. 

Are you ready to take on these challenges? Good luck, and remember: attention to detail is key in quality assurance!

## Challenge 1: Writing Test Cases
Imagine you're working on a function to calculate the sum of an array of numbers. Here is the function definition:

```javascript
function sumArray(numbers) {
    return numbers.reduce((acc, curr) => acc + curr, 0);
}
```

Your task is to write a test case to verify that the `sumArray` function correctly calculates the sum of the array `[1, 2, 3, 4, 5]`.

<div id="answerable-code-editor">
    <p id="question">Create a test case using `console.assert` to check if the `sumArray` function works as expected.</p>
    <p id="correct-answer">console.assert(sumArray([1, 2, 3, 4, 5]) === 15, "sumArray test failed");</p>
</div>

## Challenge 2: Unit Testing with Jest
Suppose you have a function that verifies if a user is of legal age. The function is defined like this:

```javascript
function isLegalAge(age) {
    return age >= 18;
}
```

Write a unit test using Jest to test whether the `isLegalAge` function returns `true` for an age of `20`.

<div id="answerable-code-editor">
    <p id="question">Create a Jest test case for the `isLegalAge` function.</p>
    <p id="correct-answer">test('returns true for age 20', () => {
    expect(isLegalAge(20)).toBe(true);
});</p>
</div>

## Challenge 3: Understanding Continuous Integration
Let's examine a situation where your CI pipeline failed after a new commit. Your CI system has notified you that an end-to-end test failed due to an unexpected error on the login page of your application.

<div id="answerable-fill-blank">
    <p id="question">What is a common step you should take to address the CI pipeline failure regarding the end-to-end test on the login page?</p>
    <p id="correct-answer">Review recent changes in the commit</p>
</div>

## Challenge 4: CI Systems and Notifications
Imagine your CI system runs a suite of tests automatically and sends you an email notification when a test fails. This time, you received a notification about a failed unit test related to a payment processing module.

<div id="answerable-fill-blank">
    <p id="question">What is a likely immediate action you would take in response to the notification of the failed unit test in the payment processing module?</p>
    <p id="correct-answer">Examine the test report for details on the failure</p>
</div>

## Challenge 5: Cross-Browser Testing Tools
Now, consider the need to perform cross-browser testing across different browsers and operating systems. What tool could you use to automate this process and ensure that your JavaScript application works smoothly in the most popular web browsers?

<div id="answerable-multiple-choice">
    <p id="question">Choose an automated testing framework suitable for cross-browser testing scenarios.</p>
    <select id="choices">
        <option id="correct-answer">Selenium</option>
        <option>Mocha</option>
        <option>QUnit</option>
        <option>Jasmine</option>
    </select>
</div>

Great job tackling these Quality Assurance challenges! By practicing these problems, you're strengthening your understanding of QA in JavaScript and becoming ever more prepared to write code that is resilient, maintainable, and user-approved. Keep up the great work – the more you test, the more robust your code becomes!