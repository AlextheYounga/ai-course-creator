# Practice Skill Challenge
Time to apply what you've learned in this course and test your knowledge on JavaScript security. Tackle the following challenges to ensure you understand how to enhance web application security. Good luck!

### Challenge 1: Client-Side Security
Imagine you’re building an online form that allows users to post comments on an article. You’ve learned about the dangers of XSS and want to make sure user inputs are sanitized properly before being displayed on the page.
<div id="answerable-code-editor">
    <p id="question">Using JavaScript, write a function that sanitizes user input by escaping special HTML characters that could be used for XSS. It should convert the characters <code>&lt;</code>, <code>&gt;</code>, and <code>&amp;</code> into their corresponding HTML entities.</p>
    <p id="correct-answer">// Function to escape HTML special characters
function escapeHTML(input) {
    return input
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}

// Example usage
const userInput = 'Hello & welcome, click <a href="#!">here</a>!';
const safeInput = escapeHTML(userInput);
console.log(safeInput); // Output should be 'Hello &amp; welcome, click &lt;a href="#!"&gt;here&lt;/a&gt;!'</p>
</div>

### Challenge 2: Subresource Integrity
You’ve been provided with a link to a third-party JavaScript library that you need to include in your project. However, you need to ensure that this file hasn’t been altered in the transfer for security reasons.
<div id="answerable-multiple-choice">
    <p id="question">Which HTML attribute should you add to the <code>&lt;script&gt;</code> tag to verify that the file you received is the one you intended to use?</p>
    <select id="choices">
        <option>crossorigin</option>
        <option id="correct-answer">integrity</option>
        <option>src</option>
        <option>type</option>
    </select>
</div>

### Challenge 3: Secure Cookie Attributes
You want to make sure that sensitive information, such as user authentication tokens, are handled securely when setting cookies in your web application.
<div id="answerable-multiple-choice">
    <p id="question">Which attribute would you set to ensure the cookie is only sent over HTTPS connections?</p>
    <select id="choices">
        <option>HttpOnly</option>
        <option>SameSite</option>
        <option>Path</option>
        <option id="correct-answer">Secure</option>
    </select>
</div>

### Challenge 4: Defense Against Session Hijacking
In order to protect your users from session hijacking, you decide to implement a measure that would prevent JavaScript access to session cookies.
<div id="answerable-multiple-choice">
    <p id="question">What cookie attribute should you use to prevent client-side scripts from accessing the session cookie?</p>
    <select id="choices">
        <option>Secure</option>
        <option id="correct-answer">HttpOnly</option>
        <option>SameSite</option>
        <option>Path</option>
    </select>
</div>

### Challenge 5: Identifying Vulnerabilities
After understanding the importance of updating dependencies from the case studies of famous breaches, you realize it is time to review your project’s dependencies.
<div id="answerable-code-editor">
    <p id="question">Write a shell command that checks for outdated npm packages in your project.</p>
    <p id="correct-answer">npm outdated</p>
</div>

Completing these challenges is a great way to solidify your understanding of web application security basics. Remember, security is an ongoing process that requires regular education, vigilance, and updates. Keep practicing and stay informed about the latest security trends and threats!