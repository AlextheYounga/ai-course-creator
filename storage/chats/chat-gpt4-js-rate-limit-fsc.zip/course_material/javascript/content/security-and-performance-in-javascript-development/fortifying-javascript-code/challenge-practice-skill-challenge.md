# Practice Skill Challenge

Congratulations on reaching the Practice Skill Challenge page! It's time to put to test what you've learned about JavaScript security. Here are 5 practice problems that will not only reinforce your understanding of essential concepts but also help you remember key security practices. Aim to complete each problem accurately, and remember, this is a learning experience—mistakes are just stepping stones to mastery.

### Problem 1: Securing Data
Picture this: Your application allows users to input their bio information, which is then displayed on their profile page. Which security practice would you use to ensure that any HTML tags the user might enter won't be executed on other users' browsers, effectively preventing an XSS attack?

<div id="answerable-multiple-choice">
    <p id="question">Which JavaScript function should you use to prevent XSS in the scenario mentioned above?</p>
    <select id="choices">
        <option>validatePhoneNumber()</option>
        <option>sanitizeAlphabetic()</option>
        <option id="correct-answer">sanitizeString()</option>
        <option>encodePhoneNumber()</option>
    </select>
</div>

### Problem 2: Data Validation
Imagine you're working on a website form that collects phone numbers from users. You want to make sure that the input matches a standard phone number format, e.g., (555) 555-5555. What method of data validation can you employ to achieve this?

<div id="answerable-code-editor">
    <p id="question">Write a regex pattern that matches a phone number in the format: (555) 555-5555.</p>
    <p id="correct-answer">/^\(\d{3}\) \d{3}-\d{4}$/</p>
</div>

### Problem 3: Understanding Attack Types
You've been briefed about various types of attacks that can target web applications, such as XSS and CSRF. Being able to identify these attacks is the first step in preventing them. Which attack involves an attacker tricking a user into submitting a request that they did not intend to?

<div id="answerable-multiple-choice">
    <p id="question">What type of attack involves deceiving a user into executing unintended actions on a web application?</p>
    <select id="choices">
        <option>SQL Injection</option>
        <option id="correct-answer">CSRF</option>
        <option>XSS</option>
        <option>DDoS</option>
    </select>
</div>

### Problem 4: Safe Coding Practices
Secure coding is a fundamental aspect of creating robust applications. What practice protects your application by treating every user input as untrusted, inspecting it meticulously, and ensuring that nothing harmful gets through?

<div id="answerable-multiple-choice">
    <p id="question">Which practice involves treating every user input as potentially dangerous and requires rigorous inspection?</p>
    <select id="choices">
        <option>Code Obfuscation</option>
        <option>Cryptography</option>
        <option id="correct-answer">Input Validation</option>
        <option>Code Minification</option>
    </select>
</div>

### Problem 5: Encoding and Entities
Your web application includes a feature for users to post comments. You want to make sure that if a user tries to submit a comment with a script tag, it will be displayed as plain text and not run as JavaScript in the browser. Which function would you use to convert potentially dangerous text into a safe format?

<div id="answerable-multiple-choice">
    <p id="question">Which JavaScript function converts a string into HTML entities to prevent scripts from executing in the browser?</p>
    <select id="choices">
        <option id="correct-answer">encodeToEntities()</option>
        <option>sanitizeString()</option>
        <option>validateInputFormat()</option>
        <option>protectInnerHTML()</option>
    </select>
</div>

Tackle these problems with confidence, and don't hesitate to revisit the course material if you need a refresh. Good luck on your quest for secure coding!