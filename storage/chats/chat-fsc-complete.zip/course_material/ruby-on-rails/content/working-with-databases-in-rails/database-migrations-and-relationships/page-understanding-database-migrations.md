# Understanding Database Migrations

In Ruby on Rails, database migrations are a crucial concept that allows developers to manage changes to the database schema over time. Think of database migrations as a version control system for your database schema. They enable you to evolve your database structure over time, making it easier to collaborate with team members and troubleshoot issues.

## What are Database Migrations?

Imagine you are constructing a building and need to make alterations to the architectural plans as you go along. In the same way, database migrations are a way to modify the structure of your database without having to recreate it from scratch each time. Whether you need to add a new table, remove an existing column, or modify a data type, database migrations provide a systematic way to make these changes.

When you run a migration, you are essentially updating the database schema to the latest version. Rails keeps track of which migrations have been run, so it knows how to update the database to match the current state of the schema.

## Creating a Migration

Let's consider an example. Suppose you want to add a "birth_date" column to the "users" table in your Rails application. To achieve this, you would create a migration file using the Rails command-line tools. This migration file contains instructions for adding the new column to the "users" table.

```ruby
class AddBirthDateToUsers < ActiveRecord::Migration[6.1]
  def change
    add_column :users, :birth_date, :date
  end
end
```

In this migration, the `add_column` method instructs Rails to add a new column called "birth_date" of type "date" to the "users" table. This file can then be executed to update the database schema accordingly.

## Interactive Component

<div id="answerable-multiple-choice">
    <p id="question">What is the purpose of database migrations in Ruby on Rails?</p>
    <select id="choices">
        <option>To update the Rails framework</option>
        <option id="correct-answer">To manage changes to the database schema over time</option>
        <option>To optimize database performance</option>
        <option>To create new databases</option>
    </select>
</div>