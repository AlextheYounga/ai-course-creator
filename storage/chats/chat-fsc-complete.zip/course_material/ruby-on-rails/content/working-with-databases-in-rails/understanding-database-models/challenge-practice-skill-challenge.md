# Practice Skill Challenge

## Question 1
### Multiple Choice
<div id="answerable-multiple-choice">
    <p id="question">What is the correct way to retrieve all records from a table using ActiveRecord?</p>
    <select id="choices">
        <option>ModelName.queryAllRecords()</option>
        <option id="correct-answer">ModelName.all</option>
        <option>retrieveAll(ModelName)</option>
        <option>fetch.records(ModelName)</option>
    </select>
</div>

## Question 2
### Code Editor/Code Executor
<div id="answerable-code-editor">
    <p id="question">Write a simple program to create a new record in the 'User' table using ActiveRecord.</p>
    <p id="correct-answer">User.new(name: 'Emily', email: 'emily@example.com', role: 'user').save</p>
</div>

## Question 3
### Fill in the Blank
<div id="answerable-fill-blank">
    <p id="question">What does a database model serve as in the world of construction?</p>
    <p id="correct-answer">Blueprint</p>
</div>

## Question 4
### Multiple Choice
<div id="answerable-multiple-choice">
    <p id="question">Which of the following best describes a database model?</p>
    <select id="choices">
        <option>A blueprint for organizing and storing data</option>
        <option id="correct-answer">A framework for building web pages</option>
        <option>A tool for designing user interfaces</option>
        <option>A language for querying databases</option>
    </select>
</div>

## Question 5
### Fill in the Blank
<div id="answerable-fill-blank">
    <p id="question">What method can be used to remove a record from the database using ActiveRecord?</p>
    <p id="correct-answer">destroy</p>
</div>

Great job! You've completed the practice skill challenge. Now, you're ready to apply your knowledge of database models and ActiveRecord in real-world scenarios.