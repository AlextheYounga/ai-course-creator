## Practice Skill Challenge

### Question 1

Imagine your Rails application needs to fetch data from an external API to display real-time weather information. What type of API is commonly used for web services and provides a flexible way to interact with data?

<aside class="notes">
RESTful APIs are commonly used for web services and provide a lightweight, flexible way to interact with data.
</aside>

### Question 2

Write a rescue_from method in Rails to capture all StandardError exceptions.

<aside class="notes">
```
Write a rescue_from method in Rails to capture all StandardError exceptions.
```
</aside>

### Question 3

What type of API is designed for the web and based on the HTTP protocol?

<aside class="notes">
RESTful API is designed for the web and based on the HTTP protocol.
</aside>

### Question 4

Which gem can be used to consume external APIs in a Rails application?

<aside class="notes">
HTTParty gem can be used to consume external APIs in a Rails application.
</aside>

### Question 5

API authentication verifies the ______ of the user making the request.

<aside class="notes">
API authentication verifies the **identity** of the user making the request.
</aside>