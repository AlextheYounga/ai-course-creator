# Practice Skill Challenge

## Question 1

Suppose you are developing a feature in a Rails application that involves calculating the total cost of items in a shopping cart. However, when you test the feature, the total cost doesn't match your expectations. Which tool can you use to place a breakpoint in the code and inspect variables to identify the discrepancy?

1. Pry
2. Byebug
3. Logging
4. Rescue_from

<div id="answerable-multiple-choice">
    <p id="question">Which tool can you use to place a breakpoint in the code and inspect variables to identify the discrepancy?</p>
    <select id="choices">
      <option>Pry</option>
      <option id="correct-answer">Byebug</option>
      <option>Logging</option>
      <option>Rescue_from</option>
    </select>
</div>

## Question 2

What is the command to set a breakpoint in Byebug?

<div id="answerable-fill-blank">
    <p id="question">What is the command to set a breakpoint in Byebug?</p>
    <p id="correct-answer">break</p>
</div>

## Question 3

What type of logging involves recording events or actions within the application?

1. Debug Logging
2. Error Logging
3. General Logging
4. System Logging

<div id="answerable-multiple-choice">
    <p id="question">What type of logging involves recording events or actions within the application?</p>
    <select id="choices">
      <option>Debug Logging</option>
      <option>Error Logging</option>
      <option id="correct-answer">General Logging</option>
      <option>System Logging</option>
    </select>
</div>

## Question 4

What does the `rescue_from` method do in Rails?

1. It allows us to define custom error messages.
2. It catches specific types of errors and allows us to define how the application should respond.
3. It automatically fixes errors before they occur.
4. It logs errors to a file for later review.

<div id="answerable-multiple-choice">
    <p id="question">What does the `rescue_from` method do in Rails?</p>
    <select id="choices">
      <option>It allows us to define custom error messages.</option>
      <option id="correct-answer">It catches specific types of errors and allows us to define how the application should respond.</option>
      <option>It automatically fixes errors before they occur.</option>
      <option>It logs errors to a file for later review.</option>
    </select>
</div>

## Question 5

Given a scenario where an e-commerce website faces intermittent crashes during the checkout process due to an unknown bug, what is the significance of effective debugging for the business?

<div id="answerable-multiple-choice">
    <p id="question">What is the significance of effective debugging for the business?</p>
    <select id="choices">
        <option id="correct-answer">Reducing potential revenue loss and improving user experience</option>
        <option>Enhancing website aesthetics</option>
        <option>Speeding up the website loading time</option>
        <option>Expanding the product catalog</option>
    </select>
</div>