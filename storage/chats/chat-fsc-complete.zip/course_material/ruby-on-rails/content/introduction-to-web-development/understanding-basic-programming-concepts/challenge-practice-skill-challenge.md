## Practice Skill Challenge

### Problem 1

Select the correct statement about the importance of web development:
<select id="choices">
    <option>Web development is irrelevant in today's digital age</option>
    <option id="correct-answer">Understanding web development is crucial due to the increasing demand for web-based services and applications</option>
    <option>Web development is limited to creating static websites</option>
    <option>Web development has no impact on user experiences</option>
</select>

### Problem 2

What is a variable in programming?

<select id="choices">
    <option>A reserved keyword</option>
    <option id="correct-answer">A named storage location for data</option>
    <option>A type of loop</option>
</select>

### Problem 3

What type of loop continues executing a block of code while a specified condition is true?

<select id="choices">
    <option>For loop</option>
    <option id="correct-answer">While loop</option>
    <option>Do-while loop</option>
    <option>Until loop</option>
</select>

### Problem 4

Write a program that calculates 2 + 2

<div id="answerable-code-editor">
    <p id="question">Write a program that calculates 2 + 2</p>
    <p id="correct-answer">4</p>
</div>

### Problem 5

What is the keyword commonly used to create a conditional statement in Ruby?

<select id="choices">
    <option>case</option>
    <option>check</option>
    <option id="correct-answer">if</option>
    <option>then</option>
</select>

Great work so far! Keep practicing to reinforce your learning.