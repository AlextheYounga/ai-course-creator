## Practice Skill Challenge

### Problem 1
Which command is used to install Rails?
<div id="answerable-multiple-choice">
    <p id="question">Which command is used to install Rails?</p>
    <select id="choices">
        <option>gem install ruby</option>
        <option id="correct-answer">gem install rails</option>
        <option>ruby install rails</option>
        <option>rails install gem</option>
    </select>
</div>

### Problem 2
What is the correct answer to this question?
<div id="answerable-fill-blank">
    <p id="question">What is the correct answer to this question?</p>
    <p id="correct-answer">Correct Answer</p>
</div>

### Problem 3
Which component of MVC is responsible for presenting the data to the users?
<div id="answerable-multiple-choice">
    <p id="question">Which component of MVC is responsible for presenting the data to the users?</p>
    <select id="choices">
        <option>Model</option>
        <option>View</option>
        <option>Controller</option>
        <option id="correct-answer">View</option>
    </select>
</div>

### Problem 4
Write a program that calculates 2 + 2
<div id="answerable-code-editor">
    <p id="question">Write a program that calculates 2 + 2</p>
    <p id="correct-answer">4</p>
</div>

### Problem 5
What is the correct answer to this question?
<div id="answerable-fill-blank">
    <p id="question">What is the correct answer to this question?</p>
    <p id="correct-answer">Correct Answer</p>
</div>

Great job! You've completed the practice skill challenge. Check your answers and validate your understanding of the concepts.