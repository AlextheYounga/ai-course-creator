# Practice Skill Challenge

## User Authorization Concepts

### Multiple Choice
<div id="answerable-multiple-choice">
    <p id="question">What are the benefits of user authorization in web applications?</p>
    <select id="choices">
        <option>Increased user registration</option>
        <option id="correct-answer">Control over user access and data security</option>
        <option>Improved user interface design</option>
        <option>Better database management</option>
    </select>
</div>

## Role-Based Access Control (RBAC)

### Fill in the Blank
<div id="answerable-fill-blank">
    <p id="question">What is the advantage of using Role-Based Access Control (RBAC) in a web application?</p>
    <p id="correct-answer">Granular control over user permissions</p>
</div>

## Implementing Access Control Lists (ACL)

### Code Editor
<div id="answerable-code-editor">
    <p id="question">Write a code example that demonstrates implementing ACLs in a Ruby on Rails application using the cancancan gem.</p>
    <p id="correct-answer">```ruby
class Ability
  include CanCan::Ability

  def initialize(user)
    if user.admin?
      can :manage, :all
    else
      can :read, Document
      can :create, Document
      can :update, Document, user_id: user.id
      can :destroy, Document, user_id: user.id
    end
  end
end
```</p>
</div>

## Fine-Grained Authorization Strategies

### Multiple Choice
<div id="answerable-multiple-choice">
    <p id="question">What does ACL stand for?</p>
    <select id="choices">
        <option>Access Control Level</option>
        <option id="correct-answer">Access Control List</option>
        <option>Access Control Logic</option>
        <option>Authority Control List</option>
    </select>
</div>

### Code Editor
<div id="answerable-code-editor">
    <p id="question">Write a policy using Pundit to ensure only the owner of a post can edit it.</p>
    <p id="correct-answer">```ruby
class PostPolicy
  attr_reader :user, :post

  def initialize(user, post)
    @user = user
    @post = post
  end
  
  def edit?
    post.user == user
  end
end
```</p>
</div>

These practice problems will test your understanding of user authorization, role-based access control, access control lists, and fine-grained authorization strategies. Good luck!