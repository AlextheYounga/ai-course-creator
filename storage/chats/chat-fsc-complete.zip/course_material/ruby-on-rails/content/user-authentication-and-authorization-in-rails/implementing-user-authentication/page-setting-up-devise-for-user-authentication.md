# Setting up Devise for User Authentication

Now that we've gained an understanding of user authentication and explored the Devise gem, let's dive into setting up Devise for user authentication in our Ruby on Rails application.

When you think about setting up user authentication, it's a bit like securing the entrance to a building. You want to make sure that only authorized individuals can enter. In the case of a web application, this means ensuring that only registered and authenticated users can access certain parts of the application.

To begin, we need to add the Devise gem to our Gemfile and install it. We can do this by running the following commands in the terminal:

```ruby
# Add Devise to the Gemfile
gem 'devise'

# Install the gem
bundle install
```

Next, we need to run the Devise generator to set up its configuration files. This generator will create the necessary files for user authentication:

```ruby
rails generate devise:install
```

Once the generator has done its magic, we need to set up Devise for the User model. This involves running the following command:

```ruby
rails generate devise User
```

Now, we have Devise set up in our application, but there are a few more steps to complete the configuration. One crucial step is to define the root URL of the application. This is the page where users will land after signing in. We can specify this in the `config/routes.rb` file.


## Fill in the Blank
<div id="answerable-fill-blank">
    <p id="question">What command should you run to add Devise to the Gemfile?</p>
    <p id="correct-answer">gem 'devise'</p>
</div>

By setting up Devise, we are laying the foundation for secure user authentication in our Rails application. This will allow us to focus on building the core features of our application while leveraging Devise's powerful authentication capabilities.
