# Practice Skill Challenge

## Question 1

What is the primary function of user authentication?

<div id="answerable-multiple-choice">
    <p id="question">What is the primary function of user authentication?</p>
    <select id="choices">
        <option>Securing the database</option>
        <option id="correct-answer">Restricting access to authorized users</option>
        <option>Improving website speed</option>
        <option>Enhancing user interface</option>
    </select>
</div>

## Question 2

Which of the following best describes user authentication?

<div id="answerable-multiple-choice">
    <p id="question">Which of the following best describes user authentication?</p>
    <select id="choices">
        <option>A process that verifies the identity of a user</option>
        <option id="correct-answer">A process that encrypts user passwords</option>
        <option>A process that displays user information</option>
        <option>A process that validates email addresses</option>
    </select>
</div>

## Question 3

What is the command you should run to add Devise to the Gemfile?

<div id="answerable-fill-blank">
    <p id="question">What command should you run to add Devise to the Gemfile?</p>
    <p id="correct-answer">gem 'devise'</p>
</div>

## Question 4

What command would you run to generate Devise views for customization?

<div id="answerable-multiple-choice">
    <p id="question">What command would you run to generate Devise views for customization?</p>
    <select id="choices">
        <option>rails generate devise:models</option>
        <option id="correct-answer">rails generate devise:views</option>
        <option>rails generate devise:controllers</option>
        <option>rails generate devise:layout</option>
    </select>
</div>

## Question 5

Write a program that calculates 2 + 2

<div id="answerable-code-editor">
    <p id="question">Write a program that calculates 2 + 2</p>
    <p id="correct-answer">4</p>
</div>