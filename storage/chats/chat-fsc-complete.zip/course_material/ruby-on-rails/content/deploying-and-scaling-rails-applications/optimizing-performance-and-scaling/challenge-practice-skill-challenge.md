## Practice Skill Challenge

### Question 1

What is the common performance optimization strategy for Rails applications?

<details>
  <summary>Click to reveal the correct option</summary>
  <div id="answerable-multiple-choice">
    <p id="question">What is the common performance optimization strategy for Rails applications?</p>
    <select id="choices">
        <option>Ignoring database queries</option>
        <option id="correct-answer">Implementing caching</option>
        <option>Using inefficient algorithms</option>
        <option>Performing unnecessary loops</option>
    </select>
  </div>
</details>

---

### Question 2

Which of the following is a common load balancing algorithm?

<details>
  <summary>Click to reveal the correct option</summary>
  <div id="answerable-multiple-choice">
    <p id="question">Which of the following is a common load balancing algorithm?</p>
    <select id="choices">
        <option>First Come, First Served</option>
        <option id="correct-answer">Round Robin</option>
        <option>Random Selection</option>
        <option>Single Server Optimization</option>
    </select>
  </div>
</details>

---

### Question 3

Why is caching important in Rails applications?

<details>
  <summary>Click to reveal the correct option</summary>
  <div id="answerable-fill-blank">
    <p id="question">Why is caching important in Rails applications?</p>
    <p id="correct-answer">Caching helps in storing computed or fetched data to improve response times and reduce the load on the server.</p>
  </div>
</details>

---

### Question 4

Name one purpose of load balancing in scaling Rails applications for high traffic.

<details>
  <summary>Click to reveal the correct option</summary>
  <div id="answerable-multiple-choice">
    <p id="question">What is one purpose of load balancing in scaling Rails applications for high traffic?</p>
    <select id="choices">
        <option>Distributing traffic to a single server</option>
        <option id="correct-answer">Spreading incoming web traffic across multiple servers</option>
        <option>Maintaining session data</option>
        <option>Minimizing database queries</option>
    </select>
  </div>
</details>

---

### Question 5

How does database optimization contribute to the performance of a Rails application?

<details>
  <summary>Click to reveal the correct option</summary>
  <div id="answerable-fill-blank">
    <p id="question">How does database optimization contribute to the performance of a Rails application?</p>
    <p id="correct-answer">Optimizing the database reduces the number of unnecessary queries and helps in quick and efficient retrieval of data, enhancing the overall performance.</p>
  </div>
</details>