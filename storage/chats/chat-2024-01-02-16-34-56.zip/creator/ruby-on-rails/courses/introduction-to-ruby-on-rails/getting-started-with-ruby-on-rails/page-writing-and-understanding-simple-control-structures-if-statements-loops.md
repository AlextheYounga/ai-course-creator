Page Title: Writing and Understanding Simple Control Structures (if statements, loops)

---

Hey there! In this section, we're going to delve into the exciting world of control structures in Ruby on Rails. Don't worry, it's not as complex as it sounds. Control structures are simply the building blocks that allow us to make decisions and loop through code - just like the way you make decisions in everyday life.

Imagine you're deciding whether to go out for a walk. You might check the weather, and if it's sunny, you'll go out. If it's raining, you might choose to stay indoors. In programming, we use "if statements" to make decisions just like this.

Let's get started with if statements. In Ruby on Rails, an if statement looks like this:
```ruby
weather = "sunny"

if weather == "sunny"
  puts "Let's go for a walk!"
else
  puts "Maybe we should stay inside today."
end
```

In this example, we check the variable `weather` to see if it contains the value "sunny". If it does, we'll print "Let's go for a walk!". If it's anything else, we'll print "Maybe we should stay inside today." See how easy that was?

Now, moving on to loops. Loops allow us to repeat a certain section of code multiple times. They're like a never-ending treadmill at the gym - they keep running until a condition is met.

The most common type of loop in Ruby on Rails is the "while loop". Here's a simple example:
```ruby
counter = 1

while counter <= 5
  puts "Counting: #{counter}"
  counter += 1
end
```

In this example, we start with a `counter` set to 1. The loop will continue to execute as long as the `counter` is less than or equal to 5. Inside the loop, we print the current value of the `counter`, then increment it by 1. The loop will continue until our condition is no longer true.

These simple structures may seem small, but they are the backbone of decision-making and repetition in Ruby on Rails. Understanding them will allow you to create powerful, efficient, and dynamic code. So, take your time to experiment with if statements and loops, and see how they can be used to make your code more flexible and responsive to different situations.

Great work so far! Keep practicing and experimenting with these control structures, and soon you'll be writing code that can make decisions and repeat tasks just like a pro!