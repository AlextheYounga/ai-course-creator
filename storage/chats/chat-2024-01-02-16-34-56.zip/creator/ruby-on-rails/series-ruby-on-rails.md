```json
[
    {
        "courseName": "Introduction to Ruby on Rails",
        "modules": [
            {
                "name": "Basic Programming Concepts",
                "skills": [
                    "Understanding variables, data types, and operators",
                    "Writing and understanding simple control structures (if statements, loops)",
                    "Understanding functions and basic concepts of object-oriented programming"
                ]
            },
            {
                "name": "Ruby Language Skills",
                "skills": [
                    "Understanding the syntax and structure of the Ruby language",
                    "Working with arrays, hashes, and other data structures in Ruby",
                    "Knowledge of Ruby's object-oriented features"
                ]
            }
        ]
    },
    {
        "courseName": "Web Development with Rails",
        "modules": [
            {
                "name": "Web Development Fundamentals",
                "skills": [
                    "Understanding HTML and CSS",
                    "Familiarity with client-server architecture",
                    "Knowledge of HTTP protocols and how browsers work"
                ]
            },
            {
                "name": "Rails Framework Knowledge",
                "skills": [
                    "Understanding the Model-View-Controller (MVC) architecture",
                    "Creating and managing database migrations in Rails",
                    "Using ActiveRecord for database interactions"
                ]
            }
        ]
    },
    {
        "courseName": "Building Modern Web Apps with Rails",
        "modules": [
            {
                "name": "Frontend Development Skills",
                "skills": [
                    "Using JavaScript and jQuery with Rails applications",
                    "Knowledge of responsive design and front-end frameworks like Bootstrap",
                    "Understanding AJAX and its implementation in Rails"
                ]
            },
            {
                "name": "Rails Development Tools",
                "skills": [
                    "Using the Rails command-line tools and generators",
                    "Working with Git for version control",
                    "Familiarity with testing frameworks like RSpec or Minitest"
                ]
            }
        ]
    },
    {
        "courseName": "Security and Performance in Rails",
        "modules": [
            {
                "name": "Security and Performance Optimization",
                "skills": [
                    "Implementing user authentication and authorization",
                    "Understanding common security vulnerabilities and best practices for securing a Rails application",
                    "Optimizing database queries and performance tuning"
                ]
            }
        ]
    },
    {
        "courseName": "Deployment and DevOps for Rails Applications",
        "modules": [
            {
                "name": "Deployment and DevOps",
                "skills": [
                    "Deploying Rails applications to cloud platforms like Heroku or AWS",
                    "Understanding the basics of server configuration and maintenance",
                    "Implementing continuous integration and deployment pipelines"
                ]
            }
        ]
    }
]
```