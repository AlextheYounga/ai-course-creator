# Control Structures in Programming

Welcome to the "Control Structures in Programming" section! In the world of programming, control structures are like the traffic signals that direct the flow of a program. They help control the execution of code by making decisions and repeating tasks. Let's dive into the main types of control structures that you'll encounter in programming.

## Conditional Statements

Conditional statements allow the program to make decisions based on certain conditions. It's like giving instructions such as "If it's raining, take an umbrella; otherwise, leave it behind." In programming terms, it could be something like:

```ruby
weather = "rainy"

if weather == "rainy"
  puts "Take an umbrella"
else
  puts "No need for an umbrella"
end
```

## Loops

Loops are like repeating a process until a certain condition is met. Think of a loop like a washing machine that keeps running until the clothes are clean. In programming, loops are used to perform a set of instructions repeatedly until a specific condition is satisfied. Here's an example of a basic loop in Ruby:

```ruby
counter = 1

while counter <= 5
  puts "Iteration: #{counter}"
  counter += 1
end
```

## Practice Time!

<div id="answerable-multiple-choice">
    <p id="question">What does the following code print out?</p>
    <p>weather = "sunny"
      if weather == "rainy"
        puts "Take an umbrella"
      else
        puts "Enjoy the sunshine"
      end
    </p>
    <select id="choices">
        <option>Take an umbrella</option>
        <option id="correct-answer">Enjoy the sunshine</option>
        <option>It will throw an error</option>
        <option>None of the above</option>
    </select>
</div>

Great job! Understanding control structures is crucial as they form the backbone of many programming concepts. Whether it's deciding what action to take based on a specific condition or iterating over a list of items, control structures are foundational in programming.