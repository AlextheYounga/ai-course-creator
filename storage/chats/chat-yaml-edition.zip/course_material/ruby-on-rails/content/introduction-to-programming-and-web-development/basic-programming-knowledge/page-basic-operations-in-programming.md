Title: Basic Operations in Programming

Welcome to the "Basic Operations in Programming" lesson! We'll be diving into the fundamental operations that form the backbone of programming. Just like math has its basic operations of addition, subtraction, multiplication, and division, programming has its own set of fundamental operations that allow us to work with data and manipulate it. 

### Arithmetic Operations
In programming, we use arithmetic operations to perform calculations. Just like in math, we have addition, subtraction, multiplication, and division. Let's look at a simple example in Ruby on Rails:
```ruby
# Addition
result = 5 + 3  # the result will be 8

# Subtraction
result = 7 - 2  # the result will be 5

# Multiplication
result = 4 * 6  # the result will be 24

# Division
result = 10 / 2  # the result will be 5
```

### String Concatenation
In addition to arithmetic operations, we also have string concatenation. This operation allows us to combine strings together. It's like linking different pieces of a puzzle to form a complete picture. Here's a simple example:
```ruby
first_name = "John"
last_name = "Doe"
full_name = first_name + " " + last_name  # the result will be "John Doe"
```

### Comparison Operators
These operators are used to compare two values. We have equality (==), not equal (!=), greater than (>), less than (<), greater than or equal to (>=), and less than or equal to (<=). Here's a quick example:
```ruby
age = 20
if age >= 18
  puts "You are an adult"
else
  puts "You are a minor"
end
```

Now, let's try to reinforce what we've learned with a quick multiple choice question:

<div id="answerable-multiple-choice">
    <p id="question">What is the result of 5 + 7?</p>
    <select id="choices">
        <option>10</option>
        <option id="correct-answer">12</option>
        <option>13</option>
        <option>11</option>
    </select>
</div>

Understanding these basic operations is crucial as they form the foundation for more complex programming. Whether you are building a web application, a mobile app, or analyzing data, these fundamental operations will always be at play.

Keep practicing these operations as they will become second nature, just like recalling basic math facts.