# Ruby Syntax and Features

Alright, now that we have a basic understanding of what Ruby is, let's dive into its syntax and some key features. 

## The Ruby Syntax

Ruby is known for its simplicity and readability. It uses a clear and easy-to-understand syntax that makes it a great language for beginners. Let's compare a simple "Hello, World!" program in Ruby with the same program written in another language, like Python.

In Ruby:
```ruby
puts "Hello, World!"
```

In Python:
```python
print("Hello, World!")
```

You can see that the Ruby syntax is quite intuitive and easy to grasp. It focuses on human-readable code, which means that the code is easy to understand and follow, just like reading a story.

## Key Features

### 1. Dynamic Typing
Ruby is dynamically typed, which means that you don't have to declare the data type of a variable when you create one. The interpreter automatically knows the type of the variable based on the value assigned to it. This makes writing code more flexible and saves time.

### 2. Blocks and Procs
Ruby allows you to pass blocks of code around your program. This feature is used in many places within the language and is a key part of what makes Ruby so expressive.

### 3. Object-Oriented
Everything in Ruby is an object, even simple data types like integers and booleans. This means that you can easily manipulate and interact with everything in the language in a consistent way.

### 4. Symbol
In Ruby, a symbol is similar to a string, but it's immutable and unique. Symbols are commonly used as the keys of hashes due to their performance benefits. 

### 5. Everything is an Object
In Ruby, everything is treated as an object. Even simple data types like integers are objects with methods that can be called on them. This makes Ruby a true object-oriented language.

## Let's Test Your Knowledge!

<div id="answerable-multiple-choice">
    <p id="question">Which of the following is a key feature of Ruby?</p>
    <select id="choices">
        <option>Static Typing</option>
        <option id="correct-answer">Dynamic Typing</option>
        <option>Binary Typing</option>
        <option>None of the above</option>
    </select>
</div>

Alright, now that we've covered the syntax and key features of Ruby, let's move on to exploring the concept of Object-Oriented Programming in Ruby.