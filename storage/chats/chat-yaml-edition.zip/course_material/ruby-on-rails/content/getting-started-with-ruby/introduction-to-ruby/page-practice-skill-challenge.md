Hey there! Welcome to the Practice Skill Challenge for Ruby on Rails. This is where we're going to put your newfound knowledge to the test and see how well you've grasped the concepts we've covered so far.

Let's dive right in with an interactive challenge:

## Multiple Choice
<div id="answerable-multiple-choice">
    <p id="question">What is the result of the following Ruby code snippet?</p>
    <pre>
class Circle
  attr_accessor :radius

  def initialize(radius)
    @radius = radius
  end

  def area
    Math::PI * @radius**2
  end
end

my_circle = Circle.new(5)
puts my_circle.area
    </pre>
    <select id="choices">
        <option>10</option>
        <option>3.14159</option>
        <option id="correct-answer">78.53975</option>
        <option>25</option>
    </select>
</div>

Now, take a moment to think it through.

Okay, in the code snippet above, we've defined a class `Circle` with an attribute `radius`. The `initialize` method sets the initial value of `radius`, and the `area` method calculates the area of the circle using the formula πr^2. When we create a new instance of `Circle` with a radius of 5 and call the `area` method, it returns the area of the circle.

Do you think you've got the correct answer? Go ahead and make your choice.

Now, let's move on to the next challenge. Great work!