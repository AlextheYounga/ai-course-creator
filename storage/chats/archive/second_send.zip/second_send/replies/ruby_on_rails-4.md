# Working with Databases

Ruby on Rails provides a powerful set of tools for working with databases, allowing you to interact with and manage your application's data. In this section, we will delve into the details of working with databases in a Rails application.

## Configuring the Database

Rails applications typically use a database to store and retrieve data. The database configuration for a Rails application is specified in the `config/database.yml` file. In this file, you can define the database connection parameters such as the adapter, database name, username, and password.

For example, a typical database configuration for a development environment might look like this:

```yaml
development:
  adapter: postgresql
  database: myapp_development
  username: myapp_user
  password: secret
```

Rails supports a variety of database systems, including MySQL, PostgreSQL, SQLite, and others.

## Migrations

Migrations in Rails are a way to evolve the database schema over time. They allow you to make changes to the database structure, such as creating or altering tables and adding or removing columns, while maintaining the version history of the database schema.

To create a new migration, you can use the `rails generate migration` command, followed by a descriptive name for the migration and any additional parameters.

For example, to create a migration to add a `birthdate` column to the `users` table, you would use the following command:

```ruby
rails generate migration AddBirthdateToUsers birthdate:date
```

Once the migration file is generated, you can define the specific changes to the database schema within the generated Ruby file.

## Querying the Database

Rails provides a rich set of methods for querying the database using ActiveRecord, which is a powerful ORM (Object-Relational Mapping) technology. ActiveRecord allows you to interact with the database using Ruby-based methods and conventions.

For example, to find all users with a given name, you can use the following ActiveRecord query:

```ruby
users_with_name_john = User.where(name: 'John')
```

Understanding how to work with databases in Rails is crucial for managing the application's data and ensuring efficient data retrieval and storage. It provides a solid foundation for building applications that can store, update, and retrieve data effectively.