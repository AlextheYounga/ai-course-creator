# Handling Forms and Data

In Ruby on Rails, handling forms and user data is a key aspect of building interactive web applications. Forms are used to collect user input, such as user registration details, search queries, or any other data submission scenarios. Let's explore how to handle forms and data effectively in a Rails application.

## Creating Forms

Rails provides form builder methods that make it easy to create and work with HTML forms. These form builder methods generate HTML inputs, select boxes, text areas, and other form elements, and handle the mapping of form data back to the server.

For example, a simple form for creating a new user might look like this:

```html
<%= form_for @user do |f| %>
  <div>
    <%= f.label :name %>
    <%= f.text_field :name %>
  </div>
  <div>
    <%= f.label :email %>
    <%= f.email_field :email %>
  </div>
  <div>
    <%= f.submit %>
  </div>
<% end %>
```

In this form, the `form_for` method generates an HTML form that is tied to a specific model instance (`@user`), and the form fields correspond to the attributes of the model.

## Handling Form Submissions

When a user submits a form, the input data is sent to the server as part of an HTTP request. In Ruby on Rails, the data can be accessed within the corresponding controller action, where it can be validated, processed, and stored in the database.

For example, a controller action to create a new user might look like this:

```ruby
class UsersController < ApplicationController
  def create
    @user = User.new(user_params)
    if @user.save
      redirect_to @user
    else
      render 'new'
    end
  end
  
  private
  def user_params
    params.require(:user).permit(:name, :email)
  end
end
```

In this example, `user_params` is a private method that specifies which attributes are allowed to be mass-assigned from the form data, providing a basic level of security.

## Data Validation

Rails provides a rich set of validation helpers to ensure that the data entered into the forms meets specific criteria, such as presence, length, format, and uniqueness.

For instance, to validate the presence and uniqueness of the `email` attribute for a `User` model, you can use the following validation:

```ruby
class User < ApplicationRecord
  validates :email, presence: true, uniqueness: true
end
```

Understanding how to handle forms and data in Rails is essential for creating interactive web applications that can collect user input, process it, and persist it in the database effectively. It underpins the user interaction layer of a Rails application and directly impacts the user experience.