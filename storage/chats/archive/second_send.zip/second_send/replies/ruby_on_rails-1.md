# Working with Models

In Ruby on Rails, models are used to interact with the database. They represent the data and the rules that govern the data within the application. In this section, we will explore how to work with models in a Rails application.

## Creating Models

To create a model in Ruby on Rails, you can use the `rails generate model` command followed by the name of the model and its attributes. For example, to create a model for a `User` with `name` and `email` attributes, you would use the following command:

```ruby
rails generate model User name:string email:string
```

This command creates a migration file for the `User` model, as well as a model file in the `app/models` directory.

## Relationships between Models

In many applications, different models are related to each other. Ruby on Rails provides easy ways to define these relationships. Common types of relationships include:

- One-to-one
- One-to-many
- Many-to-many

These relationships are defined using associations such as `has_many`, `belongs_to`, and `has_and_belongs_to_many`.

## Validations and Callbacks

Validations ensure that the data entered into the database meets certain criteria. Common validations include presence, numericality, and format validations. For example, to ensure that a `User` model's `email` attribute is unique, you can use the `validates` method in the model:

```ruby
class User < ApplicationRecord
  validates :email, presence: true, uniqueness: true
end
```

Callbacks allow you to trigger logic at certain points in the lifecycle of a model, such as before or after saving, creating, or updating a record.

Understanding how to work with models is essential to building robust and efficient Ruby on Rails applications. It provides a solid foundation for managing data and implementing business logic within the application.