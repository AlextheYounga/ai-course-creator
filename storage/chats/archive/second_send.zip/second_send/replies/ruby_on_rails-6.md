# Adding Authentication and Authorization

Security is a critical aspect of web development, and Ruby on Rails provides robust tools for implementing user authentication and authorization features. Authentication ensures that users are who they claim to be, while authorization controls what authenticated users are allowed to do within the application. Let's explore how to add authentication and authorization to a Rails application.

## Implementing User Authentication

### Using Devise for Authentication

Devise is a popular authentication solution for Rails applications. It provides a complete authentication system with features such as user registration, login, logout, password reset, and more. To use Devise, you can simply add it to your Gemfile, install it, and set up the required configurations.

```ruby
# Gemfile
gem 'devise'
```

Then run:

```bash
bundle install
rails generate devise:install
rails generate devise User
rake db:migrate
```

With these simple steps, your Rails application can now manage user registrations, logins, and sessions effectively using Devise.

### Custom Authentication Implementations

While Devise offers a comprehensive solution for authentication, some applications may require custom authentication logic. In such cases, you can implement a custom authentication system by leveraging Rails' built-in features for processing and securing user credentials.

## Authorizing User Actions

Once users are authenticated, it's essential to control what actions they are authorized to perform within the application. Authorization involves defining and enforcing access control rules to ensure that users can only interact with the parts of the application they are allowed to.

### Using CanCanCan for Authorization

CanCanCan is a popular authorization library for Rails applications. It allows you to define abilities for different user roles and easily enforce authorization rules within controller actions and views.

```ruby
# Define abilities
class Ability
  include CanCan::Ability
  
  def initialize(user)
    user ||= User.new # Guest user
    
    if user.admin?
      can :manage, :all
    else
      can :read, Post
    end
  end
end
```

By defining abilities for different user roles, you can better control what users can and cannot do within the application.

### Custom Authorization Logic

In some cases, particularly for simpler authorization requirements, custom authorization logic can be implemented directly within the controllers and views. This involves explicitly checking user roles or permissions to determine whether certain actions are allowed.

```ruby
class PostsController < ApplicationController
  before_action :require_admin, only: [:edit, :update, :destroy]
  
  def edit
    # Edit action logic here
  end
  
  private
  
  def require_admin
    redirect_to root_path, alert: 'You are not authorized to perform this action' unless current_user.admin?
  end
end
```

Understanding how to add authentication and authorization to a Rails application is vital for securing user data and controlling access to sensitive parts of the application. It forms the basis for building secure and role-based web applications that deliver a trusted and controlled user experience.