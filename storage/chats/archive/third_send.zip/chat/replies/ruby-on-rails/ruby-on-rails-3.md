# Building Your First Rails Application

## Installing Rails
Before we can start building our first Rails application, we need to ensure that we have Rails installed on our system. Rails is a powerful web application framework written in the Ruby programming language.

To install Rails, we first need to make sure we have a compatible version of Ruby installed. Then, we can use the following command to install Rails using the RubyGems package manager:

```
gem install rails
```

Once the installation is complete, we can verify the installation by running:

```
rails -v
```

This command should display the installed version of Rails, confirming that it has been successfully installed on our system.

## Creating a new Rails project
With Rails installed, we can now create a new Rails project by running the following command in our terminal:

```
rails new my_first_app
```

In this command, "my_first_app" is the name of our new Rails application. This command will create a new directory called "my_first_app" and set up the basic structure of a Rails application within it.

## Generating a simple web application
Now that we have our new Rails project set up, we can generate a simple web application to get started. Rails provides a powerful set of generators that can quickly create the essential components of a web application.

For example, we can generate a new controller and view for a "welcome" page by running the following command:

```
rails generate controller welcome index
```

This command will create a new controller file for our "welcome" page and a corresponding view file to display the content of the page.

We can then start the Rails server using the following command:

```
rails server
```

This will start the server, allowing us to access our new web application by visiting http://localhost:3000 in a web browser.

With these initial steps, we have successfully installed Rails, created a new Rails project, and generated a simple web application. In the next sections, we will further explore the components of a Rails application and begin building our first features.