```json
[
    {
        "chapterName": "Introduction to Ruby on Rails",
        "pages": [
            "What is Ruby on Rails?",
            "Brief History and Real World Use-Cases of Ruby on Rails",
            "Pros and Cons of Using Ruby on Rails"
        ]
    },
    {
        "chapterName": "Getting Started with Ruby on Rails",
        "pages": [
            "Installation and Environment Setup",
            "Creating Your First Ruby on Rails Application",
            "Understanding the MVC Architecture in Ruby on Rails"
        ]
    },
    {
        "chapterName": "Diving Deeper into Ruby on Rails",
        "pages": [
            "Working with Controllers",
            "Understanding Models and Active Record",
            "Views and Templates in Ruby on Rails"
        ]
    },
    {
        "chapterName": "Advanced Ruby on Rails Concepts",
        "pages": [
            "Migrations and Database Interactions",
            "Testing in Ruby on Rails",
            "Deploying a Ruby on Rails Application"
        ]
    }
]
```