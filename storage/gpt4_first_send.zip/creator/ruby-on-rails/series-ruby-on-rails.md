Sure, here is the list of courses:

```json
[
    "Ruby on Rails: A Basic Introduction",
    "Ruby on Rails: Setup and Installation",
    "Understanding Ruby Language: The Base for Rails",
    "Ruby on Rails: Working with MVC Architecture",
    "Building a Simple App with Ruby on Rails",
    "Ruby on Rails: Understanding Routes, Views, and Controllers",
    "Database Integration with Ruby on Rails: ActiveRecord Basics",
    "Ruby on Rails: Implementing CRUD Operations",
    "Ruby on Rails: Data Validation and Security",
    "Building User Interface with Ruby on Rails",
    "Ruby on Rails: Implementing Authentication and Authorization",
    "Deploying Ruby on Rails Application",
    "Ruby on Rails: Debugging Tips and Techniques",
    "Ruby on Rails: Integration with API's",
    "Ruby on Rails: Working with JavaScript and AJAX",
    "Ruby on Rails: Understanding Rails Testing",
    "Ruby on Rails: Advanced Topics"
]
```