```json
[
    {
        "chapterName": "Chapter 1: Getting Started with Ruby on Rails",
        "pages": [
            "What is Ruby on Rails?",
            "Setting Up Ruby on Rails Environment",
            "Exploring the Ruby on Rails Directory Structure"
        ]
    },
    {
        "chapterName": "Chapter 2: Understanding Model-View-Controller (MVC) Architecture",
        "pages": [
            "Introduction to MVC Architecture",
            "Creating a Model in Ruby on Rails",
            "Designing Views and Controllers"
        ]
    },
    {
        "chapterName": "Chapter 3: Working with Databases and Active Record",
        "pages": [
            "Configuring Databases in Ruby on Rails",
            "Understanding Active Record and Relationships",
            "Performing CRUD Operations using Active Record"
        ]
    },
    {
        "chapterName": "Chapter 4: Building Dynamic Web Applications with Ruby on Rails",
        "pages": [
            "Implementing Routes and URLs",
            "Creating Forms and Handling Form Data",
            "Adding Authentication and Authorization"
        ]
    }
]
```