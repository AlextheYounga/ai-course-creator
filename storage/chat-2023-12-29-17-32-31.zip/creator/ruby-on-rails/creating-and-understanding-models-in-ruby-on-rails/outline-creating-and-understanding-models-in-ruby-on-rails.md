```json
[
    {
        "chapterName": "Introduction to Ruby on Rails Models",
        "pages": [
            "What are Models in Ruby on Rails?",
            "Creating a New Model",
            "Understanding Model Attributes"
        ]
    },
    {
        "chapterName": "CRUD Operations with Models",
        "pages": [
            "Reading Data from a Model",
            "Creating New Records",
            "Updating and Deleting Records"
        ]
    },
    {
        "chapterName": "Model Relationships in Ruby on Rails",
        "pages": [
            "Understanding Associations between Models",
            "One-to-Many Relationships",
            "Many-to-Many Relationships"
        ]
    }
]
```