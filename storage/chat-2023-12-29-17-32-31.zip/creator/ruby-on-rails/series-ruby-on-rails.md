```json
[
    "Introduction to Ruby on Rails",
    "Creating and Understanding Models in Ruby on Rails",
    "Working with Views and Layouts in Ruby on Rails",
    "Controllers and Routing in Ruby on Rails",
    "Database Management in Ruby on Rails",
    "Forms and User Input in Ruby on Rails",
    "Adding Authentication to Ruby on Rails Applications",
    "Testing and Debugging in Ruby on Rails",
    "Deploying a Ruby on Rails Application"
]
```