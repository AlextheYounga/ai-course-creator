```json
[
    {
        "chapterName": "Introduction to Controllers and Routing",
        "pages": [
            "Understanding Controllers and their Role in Ruby on Rails",
            "Basic Routing in Ruby on Rails",
            "RESTful Routing Principles in Ruby on Rails"
        ]
    },
    {
        "chapterName": "Creating and Implementing Controllers",
        "pages": [
            "Creating a New Controller in Ruby on Rails",
            "Defining Actions and Routes for Controllers",
            "Implementing Controller Logic and Views"
        ]
    },
    {
        "chapterName": "Advanced Routing Techniques",
        "pages": [
            "Understanding Named Routes and Route Helpers",
            "Route Constraints and Advanced Route Matching",
            "Implementing Nested Routes for Resources"
        ]
    }
]
```