```json
[
    {
        "chapterName": "Introduction to ActiveRecord and Databases",
        "pages": [
            "Chapter Introduction",
            "What is ActiveRecord?",
            "Understanding Databases in Rails",
            "Setting up and Configuring Databases"
        ]
    },
    {
        "chapterName": "Modeling Data with ActiveRecord",
        "pages": [
            "Chapter Introduction",
            "Defining Models with ActiveRecord",
            "Creating Associations between Models",
            "Validating Data with ActiveRecord"
        ]
    },
    {
        "chapterName": "Migrations and Schema Management",
        "pages": [
            "Chapter Introduction",
            "Understanding Migrations in Rails",
            "Managing Database Schema",
            "Advanced Schema Management Techniques"
        ]
    },
    {
        "chapterName": "Querying and Manipulating Data",
        "pages": [
            "Chapter Introduction",
            "Querying Data with ActiveRecord",
            "Manipulating Data with ActiveRecord",
            "Advanced Data Manipulation Techniques"
        ]
    },
    {
        "chapterName": "Understanding Metaprogramming in Ruby",
        "pages": [
            "Chapter Introduction",
            "Metaprogramming Fundamentals",
            "Metaprogramming Use Cases in ActiveRecord",
            "Practical Applications of Metaprogramming in Rails"
        ]
    }
]
```