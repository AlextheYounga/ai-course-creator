```json
[
    {
        "chapterName": "Understanding Rails Application Deployment",
        "pages": [
            "Introduction to Rails Application Deployment",
            "Deployment Processes for Rails Applications",
            "Continuous Integration and Continuous Deployment (CI/CD) practices",
            "Best Practices for Rails Application Deployment"
        ]
    },
    {
        "chapterName": "Containerization and Orchestration with Docker and Kubernetes",
        "pages": [
            "Introduction to Containerization and Orchestration",
            "Using Docker for Containerization",
            "Using Kubernetes for Orchestration",
            "Best Practices for Containerization and Orchestration in Rails Applications"
        ]
    }
]
```