```json
[
    {
        "chapterName": "Unit Testing in Rails with RSpec",
        "pages": [
            "Introduction to Unit Testing in Rails",
            "Writing Unit Tests with RSpec",
            "Integration Testing with RSpec",
            "Test-Driven Development (TDD) Principles"
        ]
    },
    {
        "chapterName": "Debugging and Troubleshooting Rails Applications",
        "pages": [
            "Introduction to Debugging in Rails",
            "Tools for Debugging Rails Applications",
            "Troubleshooting Common Issues",
            "Optimizing and Improving Rails Application Performance"
        ]
    }
]
```