```json
[
    {
        "courseName": "Introduction to Ruby on Rails",
        "modules": [
            {
                "name": "Getting Started with Ruby on Rails",
                "skills": [
                    "Mastery of Ruby syntax and features",
                    "Understanding of Rails MVC (Model-View-Controller) architecture",
                    "Understanding of web development frameworks and libraries"
                ]
            },
            {
                "name": "Rails Web Development Basics",
                "skills": [
                    "HTML/CSS knowledge for web page layout and styling",
                    "Understanding of client-server architecture and HTTP protocol",
                    "Ability to use version control systems (e.g., Git)",
                    "Proficiency in using Rails conventions and best practices"
                ]
            }
        ]
    },
    {
        "courseName": "Testing and Debugging in Ruby on Rails",
        "modules": [
            {
                "name": "Unit Testing in Rails with RSpec",
                "skills": [
                    "Proficiency in writing unit tests and integration tests using RSpec or other testing frameworks",
                    "Understanding of TDD (Test-Driven Development) principles"
                ]
            },
            {
                "name": "Debugging and Troubleshooting Rails Applications",
                "skills": [
                    "Ability to debug and troubleshoot Ruby on Rails applications",
                    "Ability to optimize and improve the performance of Rails applications"
                ]
            }
        ]
    },
    {
        "courseName": "Security and Performance in Ruby on Rails",
        "modules": [
            {
                "name": "Securing Rails Applications",
                "skills": [
                    "Knowledge of common security vulnerabilities and best practices for securing Rails applications",
                    "Familiarity with authentication and authorization mechanisms in Rails"
                ]
            },
            {
                "name": "Optimizing Rails Application Performance",
                "skills": [
                    "Ability to optimize and improve the performance of Rails applications"
                ]
            }
        ]
    },
    {
        "courseName": "Database Management with ActiveRecord",
        "modules": [
            {
                "name": "Creating and Managing Databases with ActiveRecord",
                "skills": [
                    "Ability to create and manage databases using ActiveRecord"
                ]
            },
            {
                "name": "Understanding Metaprogramming in Ruby",
                "skills": [
                    "Understanding of metaprogramming concepts in Ruby"
                ]
            }
        ]
    },
    {
        "courseName": "Deployment and DevOps for Ruby on Rails",
        "modules": [
            {
                "name": "Rails Application Deployment",
                "skills": [
                    "Understanding of deployment processes for Rails applications",
                    "Familiarity with continuous integration and continuous deployment (CI/CD) practices"
                ]
            },
            {
                "name": "Containerization and Orchestration with Docker and Kubernetes",
                "skills": [
                    "Knowledge of containerization and orchestration tools like Docker and Kubernetes"
                ]
            }
        ]
    }
]
```