# Creating and Using Custom Modules

Okay, so we've talked about using modules that are already available in Python, but what if you want to create your own modules? Well, you totally can! 

Custom modules are like personalized toolkits where you can store your own set of functions and variables. Let's say you have a bunch of functions that you've written for a particular project, and you want to use these functions in another project without having to copy and paste the code every time. This is where custom modules come to the rescue.

To create a custom module, you simply write your functions and variables in a `.py` file. For example, let's say you have a file called `my_module.py`:

```python
# my_module.py

def greet(name):
    print("Hello, " + name)

def calculate_average(numbers):
    total = sum(numbers)
    average = total / len(numbers)
    return average
```

In this example, we have a custom module called `my_module` that contains two functions: `greet` and `calculate_average`.

Now, to use these functions in another Python script, you just need to import the `my_module`:

```python
import my_module

my_module.greet("Alice")  # This will print: Hello, Alice

numbers = [75, 92, 84, 100, 90]
average = my_module.calculate_average(numbers)
print("The average is:", average)  # This will print the calculated average
```

See how easy that is? It's like having your own set of tools that you can bring into any project.

Custom modules are super handy for keeping your code organized and making it reusable. Plus, they can be shared with others, just like how you can share a toolkit with your friends. So, if you find yourself writing the same functions over and over again, maybe it's time to create your own custom module!