# Using Functions from Modules

Alright, so now that we know how to import modules in Python, let's dive into using the functions that are contained within those modules. Think of modules as toolboxes, each containing a set of tools (functions) that you can use in your Python programs.

When we import a module, we essentially bring in all the functions and attributes that the module contains. These functions can then be used in our program to perform specific tasks without us having to write the code for those tasks from scratch.

Let's consider a real-world analogy to understand this better. Imagine you have a special toolbox for fixing things around the house. Inside this toolbox, you have different tools such as a screwdriver, a hammer, and a wrench. Similarly, when you import a module in Python, you gain access to a set of tools (functions) that can help you accomplish specific tasks without having to build those tools from the ground up.

Here's a simple example of how we can use a function from a module:

```python
# Importing the math module to use the sqrt function
import math

# Using the sqrt function from the math module
result = math.sqrt(16)
print(result)  # Output: 4.0
```

In this example, we import the `math` module and then use the `sqrt` function from the module to calculate the square root of 16. The `math.sqrt()` syntax indicates that we are using the `sqrt` function from the `math` module.

It's important to note that when using functions from modules, we need to reference the module name followed by a dot, then the function name. This ensures that Python knows which module the function belongs to.

By utilizing functions from modules, we can save time and effort by leveraging pre-built functionalities that have been thoroughly tested and optimized by the Python community.

Keep in mind that different modules have different functions, so it's essential to explore the documentation for the specific module to understand which functions are available and how to use them effectively.

Now that we have a good grasp of using functions from modules, let's move on to creating and using our custom modules to encapsulate our own reusable code.