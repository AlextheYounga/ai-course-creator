# Understanding Python Syntax and Basics

Welcome to the exciting world of Python! In this section, we will dive into the fundamental aspects of Python syntax and basic principles, setting the stage for your journey into the world of programming.

## Syntax: The Language of Python
Python's syntax is the set of rules that defines the combinations of symbols, words, and expressions that are considered to be correctly structured in Python programs. Think of it as the grammar of the Python language.

### Indentation
Unlike many other programming languages that use braces to define code blocks, Python uses indentation. For example, in a loop, the code within the loop is indented to identify it as part of the loop. Let's take a look at a simple "for" loop:
```python
for i in range(5):
    print(i)
```
In this example, the `print(i)` statement is indented to indicate that it belongs to the loop.

### Comments
Comments are essential in code to make it more understandable. In Python, comments are marked by the `#` symbol. Anything written after the `#` is treated as a comment and is not executed. For instance:
```python
# This is a comment in Python
print("Hello, World!")
```
The comment `# This is a comment in Python` is not executed, only the `print("Hello, World!")` line is executed.

## Basic Principles: Variables, Statements, and Expressions
In Python, you can think of a variable as a container that holds data. When you assign a value to a variable, you are storing data in the computer's memory. For example:
```python
message = "Hello, World!"
```
Here, we have created a variable called `message` and assigned it the value `"Hello, World!"`.

Python code consists of statements and expressions. A statement is a complete line of code that performs some action, while an expression is a combination of variables, operators, and calls to functions that are evaluated to produce a value. For instance:
```python
# Statement
print("Hello, World!")

# Expression
result = 10 * (5 + 3)
```
The `print("Hello, World!")` is a statement, while `10 * (5 + 3)` is an expression.

Understanding Python syntax and basic principles is crucial as they form the foundation of your programming journey. In the upcoming sections, we will further explore these concepts and apply them to solve real-world problems. Let's continue this amazing Python adventure!