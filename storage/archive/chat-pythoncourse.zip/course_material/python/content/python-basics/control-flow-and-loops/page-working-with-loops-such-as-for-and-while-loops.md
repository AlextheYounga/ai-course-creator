# Working with Loops, Such as For and While Loops

Alright, let's dive into the exciting world of loops! Imagine you're a chef making a batch of chocolate chip cookies. As you place each cookie on the baking tray, you want to repeat the same process until you've used up all the cookie dough. This repetitive action is similar to how loops work in programming.

## The For Loop

The `for` loop is like having a predefined set of instructions that you want to repeat for each item in a collection, such as a list or a range of numbers. Let's say you want to print each item in a list of fruits:

```python
fruits = ["apple", "banana", "cherry"]
for fruit in fruits:
    print(fruit)
```

In this example, the `for` loop iterates through each fruit in the list and prints it. It's like having a conveyor belt that moves each item to the processing unit one by one, until there are no more items left.

## The While Loop

On the other hand, the `while` loop is like a repeated action that continues as long as a certain condition is true. Let's use the cookie example again. You keep placing cookies on the tray as long as there is still dough left. Once the dough is finished, you stop adding more cookies.

```python
cookies = 10
while cookies > 0:
    print("Placing a cookie on the tray")
    cookies -= 1
```

In this snippet, the `while` loop checks if there are still cookies remaining and continues placing them on the tray until there are none left.

Loops are incredibly useful for automating repetitive tasks and processing large amounts of data. Both `for` and `while` loops play a crucial role in programming, allowing you to efficiently handle tasks that would be tedious to do manually.

Now that you understand how loops work, let's practice using them in Python!