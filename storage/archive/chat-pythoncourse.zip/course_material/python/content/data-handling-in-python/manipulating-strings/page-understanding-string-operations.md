# Understanding String Operations

Welcome to the world of Python strings! Strings are a fundamental data type in Python, and understanding how to manipulate them is crucial for any Python programmer.

Think of a string as a collection of characters, like a string of pearls or a string of Christmas lights. You can perform various operations on strings, just like you can manipulate the beads of a pearl necklace or rearrange the bulbs of a string of lights to create different patterns.

**Concatenation:** One of the most basic operations on strings is concatenation, which simply means joining two strings together. In Python, you can use the `+` operator to concatenate two strings. For example:
```python
str1 = "Hello"
str2 = "World"
result = str1 + " " + str2
print(result)  # Output: Hello World
```

**Indexing and Slicing:** Strings can be thought of as a sequence of individual characters, each at a specific position. You can access individual characters in a string using the indexing and slicing operations. In Python, indexing starts at 0 and you can use square brackets `[]` to access individual characters or a range of characters within a string. For example:
```python
my_string = "Python"
print(my_string[0])  # Output: P
print(my_string[2:5])  # Output: thon
```

**Built-in Functions:** Python provides a variety of built-in functions for string manipulation. For instance, the `len()` function returns the length of a string, and the `str()` function can convert other data types into strings. These functions can be incredibly useful when working with strings in Python.

Understanding these fundamental string operations forms the basis for more advanced string manipulation techniques, so make sure to practice and experiment with different strings to reinforce your understanding!