# Understanding and Using Lists

In Python, a **list** is a versatile and fundamental data structure used to store a collection of items, such as a list of numbers, names, or any other data types. Think of it as a container that holds various things, like how your backpack can contain books, a water bottle, and a snack.

To create a list in Python, you simply enclose the items within square brackets and separate them with commas. Let's say we want to create a list of the days of the week:

```python
days_of_the_week = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
```

### Accessing Elements in a List

You can access individual elements within a list by their position, known as the index. It's similar to how you would locate a book on a shelf by its position. In Python, the index starts at 0. So, to access the first element in the `days_of_the_week` list, you would use `days_of_the_week[0]`, which would return "Monday".

### Modifying Lists

Lists in Python are mutable, which means you can change, add, and remove elements after the list has been created. Let's modify the `days_of_the_week` list by replacing "Sunday" with "Funday":

```python
days_of_the_week[-1] = "Funday"
```

### List Operations and Functions

Python provides a variety of operations and functions to work with lists. For instance, you can easily add elements to the end of a list using the `append()` method:

```python
fruits = ["apple", "banana", "cherry"]
fruits.append("orange")
# The fruits list would now be: ["apple", "banana", "cherry", "orange"]
```

You can also use the `len()` function to find the length of a list:

```python
num_list = [1, 2, 3, 4, 5]
length = len(num_list)
# The value of length would be 5
```

Understanding and mastering lists is a crucial part of becoming proficient in Python. They are incredibly useful and can be found in almost all Python programs, allowing for efficient and organized data storage and manipulation.