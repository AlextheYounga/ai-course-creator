# Exploring the Functionality of Dictionaries

Welcome back! In the previous section, we delved into the world of lists and their versatile functionality. Now, let's shift our focus to another essential data structure in Python: dictionaries.

Think of dictionaries as real-life dictionaries, where you look up a word (key) to find its definition (value). Similarly, in Python, a dictionary is a collection of key-value pairs, where each unique key maps to a value. This key-value pairing allows for convenient and efficient data retrieval.

### Creating a Dictionary

Creating a dictionary in Python is as easy as pie. You can define a dictionary by enclosing a comma-separated list of key-value pairs within curly braces `{}`. Let's say we want to create a dictionary of contact information:

```python
# dictionary of contact information
contact_info = {
    "name": "John Doe",
    "email": "john.doe@email.com",
    "phone": "123-456-7890"
}
```

In the example above, the keys are "name", "email", and "phone", and their respective values are "John Doe", "john.doe@email.com", and "123-456-7890".

### Accessing and Modifying Values

To access a value in the dictionary, you can use its corresponding key. For instance, let's access the email from the `contact_info` dictionary:

```python
email = contact_info["email"]
print(email)  # Output: john.doe@email.com
```

If you need to update a value, you can simply refer to the key and assign a new value to it:

```python
# Update the email
contact_info["email"] = "j.doe@email.com"
```

### Adding and Removing Key-Value Pairs

Adding a new key-value pair is straightforward. You simply assign a value to a new key:

```python
# Adding a new key-value pair
contact_info["address"] = "123 Main St"
```

To remove a key-value pair, you can use the `pop()` method:

```python
# Removing a key-value pair
contact_info.pop("phone")
```

### Dictionary Methods and Functions

Python provides a variety of built-in methods to manipulate dictionaries. For instance, you can use `keys()`, `values()`, and `items()` to retrieve the keys, values, and key-value pairs, respectively.

```python
# Getting keys
keys = contact_info.keys()

# Getting values
values = contact_info.values()

# Getting key-value pairs
items = contact_info.items()
```

By exploring and understanding the functionality of dictionaries, you gain a powerful tool for organizing and manipulating data in Python. With practice and creativity, you can leverage the versatility of dictionaries to solve a wide range of real-world problems.