# Understanding Inheritance in Python

When it comes to object-oriented programming, inheritance is a concept that plays a crucial role. In Python, as in many other programming languages, inheritance allows one class to inherit attributes and methods from another class. This not only promotes code reusability but also helps in creating a logical hierarchy of classes.

Let's go through a real-world analogy to understand inheritance more clearly. Consider a vehicle hierarchy with a base class `Vehicle` and derived classes such as `Car`, `Motorcycle`, and `Truck`. Each of these derived classes inherits common attributes and methods from the base class `Vehicle`, like `color`, `speed`, and `start_engine()` method, but can also have their own distinct attributes and behaviors.

In Python, the syntax for creating a new class that inherits from another class is simple. When defining the new class, simply include the name of the base class in parentheses after the new class name:

```python
class Vehicle:
    def __init__(self, color, speed):
        self.color = color
        self.speed = speed

    def start_engine(self):
        print("Engine started")

class Car(Vehicle):
    def __init__(self, color, speed, brand):
        super().__init__(color, speed)
        self.brand = brand

    def open_trunk(self):
        print("Trunk opened")
```

In this example, the `Car` class inherits from the `Vehicle` class, gaining access to its attributes and methods. The `super()` function is used to call the `__init__()` method of the parent class.

Understanding inheritance in Python is fundamental for building efficient and maintainable code. It allows for the creation of a well-organized class hierarchy and promotes the reusability of code. In the next section, we will delve deeper into implementing inheritance in classes.