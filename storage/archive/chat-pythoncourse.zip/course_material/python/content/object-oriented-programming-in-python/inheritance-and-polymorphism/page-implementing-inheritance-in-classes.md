# Implementing Inheritance in Classes

Alright, we've talked about what inheritance is and how it works in Python. Now, let's dive into how we can actually implement inheritance in our Python classes.

When we want to create a new class that is based on an existing class, we can use inheritance. The existing class is called the **parent class** or **base class**, and the new class is called the **child class** or **derived class**. The child class inherits attributes and methods from the parent class, allowing us to reuse the code and extend the functionality.

Let's consider an example to make things clearer. Suppose we have a `Vehicle` class with attributes and methods common to all vehicles. Now, we want to create a more specific class called `Car`, which shares the same attributes and methods as `Vehicle` but also has its own unique features. This is where inheritance comes into play.

In Python, implementing inheritance is quite simple. We define the child class, and in the parentheses after the child class name, we specify the name of the parent class. Here's a basic example:

```python
class Vehicle:
    def __init__(self, make, model, year):
        self.make = make
        self.model = model
        self.year = year

    def display_info(self):
        print(f"{self.year} {self.make} {self.model}")

class Car(Vehicle):
    def __init__(self, make, model, year, num_doors):
        super().__init__(make, model, year)
        self.num_doors = num_doors

    def honk(self):
        print("Beep! Beep!")
```

In the example above, the `Car` class inherits from the `Vehicle` class. The `__init__` method in the `Car` class starts by calling the `__init__` method of the parent class using `super().__init__(make, model, year)`. This allows the `Car` class to inherit the attributes `make`, `model`, and `year` from the `Vehicle` class, and then adds its own unique `num_doors` attribute and the `honk` method.

By using inheritance, not only do we avoid duplicating code, but we also create a logical and hierarchical structure for our classes. This makes the code more organized, easier to maintain, and reduces the chances of errors.

In summary, implementing inheritance in Python is a powerful tool that allows us to create new classes based on existing ones, promoting code reusability and providing a clear way to structure our programs.