# Reading and Writing Files

When it comes to working with files in Python, two fundamental operations are reading from files and writing to files. In this section, we'll dive into the specifics of both of these operations and how they can be implemented in Python.

## Reading Files

To read from a file, we need to first open the file in read mode using the `open()` function. Let's consider an example. Suppose we have a file named "data.txt" containing some text. We can open and read this file using the following code:

```python
with open('data.txt', 'r') as file:
    content = file.read()
    print(content)
```

In this example, we are using the `open()` function to open the file in read mode (`'r'`). The `with` statement here is used to ensure that the file is properly closed after its suite finishes, even if an exception is raised during the process.

The method `file.read()` reads the entire file content and stores it in the variable `content`. After that, we simply print the content to the console.

## Writing to Files

Writing to a file in Python is quite straightforward. We can create a new file or overwrite an existing one by opening the file in write mode using the `open()` function. Let's take a look at an example:

```python
with open('output.txt', 'w') as file:
    file.write('This is a sample text that will be written to the file.')
```

In this example, we are using the `open()` function to open (or create if it doesn't exist) a file named "output.txt" in write mode (`'w'`). The `with` statement ensures that the file is properly closed after writing to it.

The method `file.write()` is then used to write the specified text to the file.

## Closing Files

It's important to note that after working with files, we should always close them to free up system resources. However, using Python's `with` statement as shown in the examples above implicitly handles closing the file. This means we don't explicitly have to call the `file.close()` method.

File handling is an essential aspect of programming, and Python provides convenient ways to read from and write to files, making it a powerful tool for handling real-world data and scenarios.