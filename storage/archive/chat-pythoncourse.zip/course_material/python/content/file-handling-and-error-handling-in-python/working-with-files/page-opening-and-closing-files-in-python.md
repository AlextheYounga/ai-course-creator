# Opening and Closing Files in Python

When working with files in Python, it’s essential to know how to open and close them properly. Just like in the real world, you wouldn’t leave a book open forever or forget to close the refrigerator door. Let's dive into how you can do this in Python.

### Opening Files
In order to work with a file, you first need to open it. To open a file in Python, you can use the `open()` function. 

```python
file = open('example.txt', 'r')
```

In the above example, we've used the `open()` function to open a file named 'example.txt' in read mode ('r'). The first parameter of the `open()` function is the name of the file, and the second parameter is the mode in which we want to open the file. Here are a few common modes:
- `'r'`: Open for reading (default)
- `'w'`: Open for writing, truncating (overwriting) the file first
- `'a'`: Open for writing, appending to the end of the file if it exists
- `'b'`: Binary mode

### Closing Files
Once you have finished working with a file, it’s crucial to close it. This releases the file's resources back to the operating system and ensures that no data is lost or corrupted.

To close a file in Python, you can use the `close()` method as follows:

```python
file.close()
```

In this example, `file` is the name of the file object. Once you've performed all the operations you need on the file, calling `file.close()` will close the file.

It's good practice to do the opening and closing of files in a way that ensures the file gets closed even if an error occurs. We'll cover this in more detail when we discuss error handling.

In the next section, we'll explore how to read from and write to files in Python. Keep going!

Now that we’ve learned how to open and close files in Python, let's move on to understanding how to read and write data to files.