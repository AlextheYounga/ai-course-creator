# Dictionaries in Python

Hey there! Welcome to the exciting world of dictionaries in Python. In this section, we're going to dive into the versatile data structure known as dictionaries and explore how they can be used to store and manipulate data in Python.

## Understanding Dictionaries

Imagine you have a physical dictionary book where you look up words and find their meanings. Similarly, in Python, a dictionary is like a digital version of this book, but instead of words and definitions, it stores pairs of keys and values. Each key is unique, like a word in the book, and each key has an associated value, like the word's definition.

Here's a simple example of a dictionary in Python:

```python
# Creating a dictionary
student = {
    "name": "John",
    "age": 16,
    "grade": "11th"
}
```

In this example, the keys are "name", "age", and "grade", and the corresponding values are "John", 16, and "11th" respectively.

## Accessing and Modifying Dictionaries

Just like how you would look up a word in a dictionary book, you can access the value of a specific key in a Python dictionary.

```python
# Accessing a value
print(student["name"])  # Output: John
```

You can also add new key-value pairs, modify existing values, or remove key-value pairs from a dictionary, making it a dynamic and flexible data structure to work with.

## Iterating Through a Dictionary

Looping through a dictionary allows you to access all the key-value pairs it contains. You can use a `for` loop to iterate through the keys, the values, or both.

```python
# Iterating through keys
for key in student:
    print(key)  # Output: name, age, grade

# Iterating through values
for value in student.values():
    print(value)  # Output: John, 16, 11th

# Iterating through key-value pairs
for key, value in student.items():
    print(f"{key}: {value}")  # Output: name: John, age: 16, grade: 11th
```

## Practical Example

Let's say you're building a game and you want to store information about a player, such as their username, level, and score. A dictionary would be a perfect choice for this as it allows you to organize and retrieve this data efficiently.

```python
# Player dictionary
player = {
    "username": "gamer123",
    "level": 5,
    "score": 2300
}
```

## Your Turn
Now it's your turn to test your understanding. Take a moment to complete the following:

<div id="answerable-fill-blank">
    <p id="question">What is the result of accessing the "level" key in the 'player' dictionary?</p>
    <p id="correct-answer">5</p>
</div>

Awesome! You're well on your way to mastering dictionaries in Python. Keep practicing and experimenting with dictionaries to become even more comfortable using them in your Python journey.