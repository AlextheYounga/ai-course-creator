# Lists, Tuples, and Sets in Python

Alright, so now that we have covered the basics of data handling in Python, let's dive into the world of lists, tuples, and sets. These are fundamental data structures in Python that allow us to store and organize data in different ways.

## Lists
Imagine a list as a shopping list - it can contain a variety of items like fruits, vegetables, and snacks. In Python, a list is an ordered collection of items that can be of different data types. For example, we can have a list of numbers, a list of strings, or even a list of lists!

```python
# Creating a list of fruits
fruits = ["apple", "banana", "orange", "grape"]
```

## Tuples
Now, picture a tuple as a pair of coordinates - it's an ordered pair of values. In Python, a tuple is similar to a list, but it's immutable, meaning its elements cannot be changed after the tuple is created. Tuples are commonly used for fixed collections of items.

```python
# Creating a tuple of coordinates
coordinate = (3, 4)
```

## Sets
To understand sets, think of a set of unique keys – each item is unique and there are no duplicates. In Python, a set is an unordered collection of unique items. Sets are handy when you want to perform mathematical set operations like union, intersection, and difference.

```python
# Creating a set of unique colors
colors = {"red", "green", "blue", "red"}  # Note that "red" will only appear once in the set
```

Now, let's add an interactive coding exercise to apply what we've just discussed.

## Code Editor/Code Executor
<div id="answerable-code-editor">
    <p id="question">Can you create a list of your favorite movies?</p>
    <p id="correct-answer">movies = ["The Shawshank Redemption", "Inception", "The Matrix", "Pulp Fiction"]</p>
</div>