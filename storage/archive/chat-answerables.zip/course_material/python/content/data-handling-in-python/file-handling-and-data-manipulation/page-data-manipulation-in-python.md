# Data Manipulation in Python

Welcome to the exciting world of data manipulation in Python! So far, we've learned about variables, data types, and file I/O operations. Now, it's time to explore how Python can manipulate and analyze data to extract valuable insights.

## Data Structures Review

Before we dive into data manipulation techniques, let's quickly review some essential data structures in Python that we'll be working with:

- **Lists:** Ordered collections of items, suitable for storing sequences of data.
- **Dictionaries:** Key-value pairs that allow us to store and retrieve data based on keys.
- **Tuples:** Similar to lists, but immutable once created, ideal for representing fixed collections of items.

## Manipulating Lists

Imagine you have a list of numbers, and you want to extract only the even numbers from it. Python makes this task effortless. Here's a simple example:

```python
# Example: Filtering even numbers from a list
numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
even_numbers = [num for num in numbers if num % 2 == 0]
print(even_numbers)
```

In this example, we use a list comprehension to create a new list `even_numbers` that contains only the even numbers from the original list.

## Working with Dictionaries

Let's consider a scenario where you have a dictionary containing the sales data for different products. You want to find the product with the highest sales. Python's built-in functions and methods can help us achieve this easily.

```python
# Example: Finding the product with the highest sales
sales_data = {
    'product1': 150,
    'product2': 300,
    'product3': 200,
    'product4': 500
}
best_selling_product = max(sales_data, key=sales_data.get)
print("The best selling product is:", best_selling_product)
```

Here, the `max` function along with the `key` parameter helps us find the product key with the highest sales value.

## Data Manipulation Techniques

Python offers a wide range of libraries and built-in functions for data manipulation, such as filtering, sorting, and transforming data. Whether it's working with strings, numbers, or complex data structures, Python provides powerful tools to manipulate and mold the data to suit our needs.

## Your Turn!

Now that you have a solid understanding of basic data manipulation in Python, it's your turn to apply these concepts. Take a shot at a challenge.

<div id="answerable-code-editor">
    <p id="question">Given a list of words, create a new list containing the lengths of each word.</p>
    <p id="correct-answer">[5, 3, 6, 7]</p>
</div>

Great work! You're well on your way to becoming proficient in Python data manipulation!