# Working with CSV and JSON Files

Hey there! In this section, we're going to dive into the exciting world of working with CSV and JSON files in Python.

## CSV Files
Let's start with CSV files. CSV stands for Comma Separated Values, and it's a popular way to store tabular data. Imagine you have a spreadsheet with rows and columns of data - that's exactly what a CSV file represents.

### Reading CSV Files
One of the most common tasks you'll encounter is reading data from a CSV file. Let's take a look at how we can achieve this in Python.

```python
import csv

# Open the CSV file
with open('data.csv', 'r') as file:
    reader = csv.reader(file)

    # Iterate through each row
    for row in reader:
        print(row)
```

In this example, we use the `csv` module to read the data from a CSV file. We open the file and then iterate through each row to access the data.

### Writing to CSV Files
Now, what if you want to create a new CSV file or append data to an existing one? Let's see how you can do that.

```python
import csv

data = [
    ['Name', 'Age', 'Country'],
    ['Alice', 25, 'USA'],
    ['Bob', 30, 'Canada']
]

# Write data to a CSV file
with open('new_data.csv', 'w', newline='') as file:
    writer = csv.writer(file)
    writer.writerows(data)

print('Data written successfully!')
```

In this example, we use the `csv.writer` to write data to a new CSV file.

## JSON Files
Moving on to JSON (JavaScript Object Notation) files. JSON is a lightweight data interchange format that is easy for humans to read and write, and easy for machines to parse and generate.

### Reading JSON Files
Reading data from a JSON file is straightforward in Python.

```python
import json

# Open the JSON file and load the data
with open('data.json', 'r') as file:
    data = json.load(file)

print(data)
```

Here, we use the `json` module to load the data from a JSON file, and then we can work with the data as needed.

### Writing to JSON Files
To write data to a JSON file, we can use the following approach:

```python
import json

data = {
    'name': 'John',
    'age': 28,
    'city': 'New York'
}

# Write data to a JSON file
with open('new_data.json', 'w') as file:
    json.dump(data, file)

print('Data written successfully!')
```

With `json.dump`, we can write data to a new JSON file effortlessly.

That's it for working with CSV and JSON files in Python! These skills are essential for handling and manipulating various types of data, and you're well on your way to becoming a data handling pro.