# Welcome to Control Structures and Functions

Welcome to the Python Basics and Control Structures course! In this chapter, we'll dive into the essential concepts of control structures and functions in Python.

## What are Control Structures?

Imagine control structures as the traffic signals in a city. They direct the flow of traffic (your program) by making decisions based on certain conditions. In Python, we use control structures to dictate the flow of the program execution based on logical conditions.

### Conditional Statements

Conditional statements, like the if statement, act as the green light, allowing the program to execute certain blocks of code only if a specified condition is met. For example:
```python
age = 18

if age >= 18:
    print("You are old enough to vote")
```

### Loops

Loops, such as the for and while loops, are like the roundabout on a busy street. They allow us to repeat a block of code multiple times. For instance:
```python
for i in range(5):
    print(i)
```

## What are Functions?

Functions are like reusable recipes in cooking. Just as a recipe describes a set of instructions to prepare a dish, a function is a block of organized, reusable code used to perform a single, related action.

### Defining a Function

In Python, we define a function using the `def` keyword, followed by the function name and parentheses. For example:
```python
def greet():
    print("Hello, welcome to the course!")
```

### Calling a Function

Once a function is defined, we can "call" or "invoke" it to execute the code within the function block. Like so:
```python
greet()
```

Now that we have a basic understanding of control structures and functions, let's delve deeper into each concept and explore more about how they work in Python.