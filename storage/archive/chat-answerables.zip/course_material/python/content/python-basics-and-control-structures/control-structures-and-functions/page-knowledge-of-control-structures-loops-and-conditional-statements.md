# Knowledge of Control Structures: Loops and Conditional Statements

Welcome to the exciting world of control structures in Python! In this section, we will dive deep into the essential concepts of loops and conditional statements.

## Loops
Imagine you are a teacher and you want to take attendance of all the students in your class. You can go to each student's desk one by one, take their attendance, and repeat the process until you have covered the entire class. This repetitive process can be compared to what we do with loops in programming.

### While Loops
The `while` loop in Python keeps executing a block of code as long as a specified condition is true. It's like telling a child, "Keep eating cookies until you finish your homework."

Let's take an example:
```python
count = 0
while count < 5:
    print("Count is", count)
    count += 1
```
In the above code, the `while` loop keeps running until the `count` is less than 5. 

### For Loops
On the other hand, `for` loops are used when you have a block of code which you want to repeat a fixed number of times.

```python
fruits = ["apple", "banana", "cherry"]
for fruit in fruits:
    print(fruit)
```
In this example, the `for` loop iterates over each of the fruits in the list and prints it.

## Conditional Statements
Conditional statements allow us to execute certain pieces of code based on a condition. It's like deciding whether to go out to play based on the weather.

### If Statement
The most basic type of decision making is the `if` statement. It checks a condition and performs a task if the condition is true.

```python
age = 16
if age >= 18:
    print("You are eligible to vote")
```
In this code, the message is only printed if the `age` is 18 or above.

### If-else Statement
The `if-else` statement is an extension to the `if` statement. If the condition specified in the `if` statement is false, the `else` statement is executed.

```python
age = 16
if age >= 18:
    print("You are eligible to vote")
else:
    print("You are not eligible to vote yet")
```
In this case, the code checks if the `age` is 18 or above. If it is, the first message is printed. If not, the second message is printed.

### If-elif-else Statement
When you have multiple conditions to check, the `if-elif-else` statement comes to the rescue. It allows you to check for multiple conditions and execute the block of code corresponding to the first true condition.

```python
age = 16
if age < 13:
    print("You are a child")
elif age < 18:
    print("You are a teenager")
else:
    print("You are an adult")
```
In this example, depending on the `age`, a specific message is printed.

Now it's time to practice what you've learned about loops and conditional statements! 

## Code Editor
<div id="answerable-code-editor">
    <p id="question">Write a program that calculates the sum of all even numbers from 1 to 10</p>
    <p id="correct-answer">30</p>
</div>