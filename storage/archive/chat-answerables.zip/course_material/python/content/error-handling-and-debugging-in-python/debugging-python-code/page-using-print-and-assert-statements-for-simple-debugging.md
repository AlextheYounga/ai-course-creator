# Using print() and assert statements for simple debugging

Welcome to the world of debugging in Python! In this section, we'll explore some simple yet powerful techniques you can use to identify and fix issues in your code.

## The Power of Print Statements

One of the most straightforward ways to debug your Python code is by using print statements. By strategically placing print statements throughout your code, you can track the value of variables, see the flow of your program, and identify where things might be going wrong.

Let's consider an example where you're trying to calculate the total price of items in a shopping cart. You suspect there's a problem with the calculation. By inserting print statements at key points in your code, such as before and after the calculation, you can observe the values of the variables involved and trace the flow of the calculation.

```python
# Example of using print statements for debugging
cart = [10, 20, 30, 5]
total_price = 0

# Adding up the prices
for item_price in cart:
    print("Current total_price:", total_price)  # Debugging statement
    total_price += item_price
    print("Adding", item_price, "to total_price")  # Debugging statement

print("Final total price:", total_price)  # Debugging statement
```

In the example above, the print statements help you observe the value of `total_price` as items are added, allowing you to identify any discrepancies in the calculations.

## Using Assert Statements

Another technique for simple debugging is using assert statements. An assert statement is used to test if a condition is true, and if it's not, it raises an AssertionError. This can be a quick way to check if your code is performing as expected at a particular point.

Let's say you're working on a function to calculate the average of a list of numbers. You can use assert statements to verify that the function is returning the correct result for a given input.

```python
# Using assert statements for debugging
def calculate_average(numbers):
    assert len(numbers) > 0, "List cannot be empty"  # Debugging assert statement
    average = sum(numbers) / len(numbers)
    return average

# Test the calculate_average function
test_numbers = [5, 10, 15, 20, 25]
result = calculate_average(test_numbers)
assert result == 15, "Average calculation incorrect"  # Debugging assert statement
print("Average calculation successful!")  # Debugging statement
```

In the example above, the assert statements help you quickly verify assumptions about the code, ensuring that the function is working as intended.

By mastering the art of strategically placing print() and assert statements in your code, you can gain valuable insights into the behavior of your program and effectively tackle simple debugging scenarios.

Now, it's your turn to practice using print() and assert statements in your own code! Remember, the journey to becoming a proficient debugger in Python begins with these fundamental techniques.