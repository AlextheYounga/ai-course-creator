# Common Types of Exceptions in Python and How to Handle Them

Welcome to the chapter on understanding exception handling in Python! In this section, we'll dive into the common types of exceptions that you may encounter while writing Python code, and how to handle them effectively.

## Types of Exceptions

### 1. **SyntaxError**
This type of error occurs when the Python interpreter encounters a syntax that does not conform to the language's grammar rules. It indicates a mistake in the code structure such as missing parentheses, incorrect indentation, or misspelled keywords.

### 2. **NameError**
NameError is raised when a local or global name is not found. This usually happens when you try to use a variable or a function that has not been defined.

### 3. **TypeError**
TypeError is raised when an operation or function is applied to an object of an inappropriate type. For example, trying to add a string and a number together would raise this type of error.

### 4. **IndexError**
IndexError occurs when you try to access an index in a sequence (such as a list) that is not valid. For instance, trying to access the 5th element in a list with only 3 elements will raise an IndexError.

## Handling Exceptions

Now that we've covered some common types of exceptions, let's discuss how to handle them using the `try...except` block.

The `try...except` block allows us to catch and handle exceptions gracefully. Here's a simple example:

```python
try:
    result = 10 / 0
except ZeroDivisionError:
    print("You can't divide by zero!")
```

In this example, when the division by zero occurs, the ZeroDivisionError exception is caught, and the message "You can't divide by zero!" is printed.

By using the `try...except` block, you can prevent your program from crashing and provide useful feedback to the user when errors occur.

## Sandbox

<div id="answerable-code-editor">
    <p id="question">Write a program that tries to access an element at index 3 in a list with only 2 elements, and use the correct exception handling to avoid a crash.</p>
    <p id="correct-answer">```python
try:
    my_list = [1, 2]
    print(my_list[3])
except IndexError:
    print("Index is out of range!")
```</p>
</div>

Understanding and handling exceptions is a crucial skill in Python development. It allows you to build robust and reliable programs that gracefully handle unexpected scenarios. So, make sure to practice writing code that handles various types of exceptions to become a proficient Python programmer.