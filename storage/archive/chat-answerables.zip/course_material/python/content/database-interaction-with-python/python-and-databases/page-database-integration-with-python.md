# Database Integration with Python

Now that we understand how to interact with databases using Python and SQL, let's dive into integrating databases with Python applications.

Imagine your Python application as a server at a restaurant. When a customer (user) places an order (performs an action), the server needs to communicate with the kitchen (the database) to fulfill the order. This interaction between the server and the kitchen is similar to the way Python applications interact with databases.

One popular method of integrating databases with Python is through Object-Relational Mapping (ORM) libraries like SQLAlchemy. ORM libraries allow us to interact with the database using Python objects rather than directly writing SQL queries. It's like having a menu (Python code) that you can use to place an order (query the database) instead of going into the kitchen (writing SQL queries) every time you need something.

Let's take a look at a simple example of using SQLAlchemy to integrate a SQLite database with a Python application:

```python
# First, we need to create a database engine
from sqlalchemy import create_engine

engine = create_engine('sqlite:///example.db')

# Using a declarative base to define a table
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String

Base = declarative_base()

class User(Base):
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True)
    name = Column(String)
    age = Column(Integer)

# Creating the table in the database
Base.metadata.create_all(engine)

# Performing database operations
from sqlalchemy.orm import sessionmaker

# Creating a session
Session = sessionmaker(bind=engine)
session = Session()

# Adding a new user to the database
new_user = User(name='John', age=25)
session.add(new_user)
session.commit()

# Querying the database
user = session.query(User).filter_by(name='John').first()
print(user.age)
```

In this example, we create a SQLite database engine, define a User class using SQLAlchemy's declarative base, create the users table in the database, add a new user, and then query the database to retrieve the user's information.

Python's adaptability and the powerful tools of libraries like SQLAlchemy make database integration seamless and efficient. With these tools at your disposal, you can create robust applications that interact with databases effortlessly.

Now, let's move on to practice and reinforce our understanding of integrating databases with Python.