## Practice Skill Challenge

### Question 1
What is a promise in JavaScript?

<div id="answerable-multiple-choice">
    <p id="question">What is a promise in JavaScript?</p>
    <select id="choices">
        <option>An object representing the eventual completion or failure of an asynchronous operation</option>
        <option id="correct-answer">A keyword to declare a future action in JavaScript</option>
        <option>A way to ensure synchronous execution of code</option>
        <option>A type of function to handle errors in JavaScript</option>
    </select>
</div>

### Question 2
Which of the following best describes callback functions in JavaScript?

<div id="answerable-multiple-choice">
    <p id="question">Which of the following best describes callback functions in JavaScript?</p>
    <select id="choices">
        <option>A function that returns a value</option>
        <option id="correct-answer">A function that is passed as an argument to another function and is executed after an operation has been completed</option>
        <option>A function that repeats a block of code</option>
        <option>A function that initializes a variable</option>
    </select>
</div>

### Question 3
What method is used to handle the successful completion of a promise in JavaScript?

<div id="answerable-fill-blank">
    <p id="question">What method is called when the promise is resolved?</p>
    <p id="correct-answer">.then()</p>
</div>

### Question 4
Which of the following best describes callback functions in JavaScript?

<div id="answerable-multiple-choice">
    <p id="question">Which of the following best describes callback functions in JavaScript?</p>
    <select id="choices">
        <option>A function that returns a value</option>
        <option id="correct-answer">A function that is passed as an argument to another function and is executed after an operation has been completed</option>
        <option>A function that runs before the main function</option>
        <option>A function that runs indefinitely</option>
    </select>
</div>

### Question 5
What is the main advantage of using Promises over callbacks?

<div id="answerable-multiple-choice">
    <p id="question">What is the main advantage of using Promises over callbacks?</p>
    <select id="choices">
        <option>Promises are easier to write</option>
        <option>Promises simplify error handling</option>
        <option id="correct-answer">Promises avoid callback hell</option>
        <option>Promises execute faster</option>
    </select>
</div>