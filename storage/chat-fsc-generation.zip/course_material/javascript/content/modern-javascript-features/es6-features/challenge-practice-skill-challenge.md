# Practice Skill Challenge

## Question 1

What is the correct answer to this question?

<div id="answerable-fill-blank">
    <p id="question">What is the correct answer to this question?</p>
    <p id="correct-answer">Correct Answer</p>
</div>

## Question 2

What is one of the benefits of using arrow functions in JavaScript?

<div id="answerable-multiple-choice">
    <p id="question">What is one of the benefits of using arrow functions in JavaScript?</p>
    <select id="choices">
        <option>They have access to their own this context</option>
        <option id="correct-answer">They provide a more concise syntax for writing functions</option>
        <option>They are hoisted to the top of the scope</option>
        <option>They automatically bind their own this context</option>
    </select>
</div>

## Question 3

What was the name given to the version of JavaScript released in 2015, incorporating significant updates and improvements?

<div id="answerable-multiple-choice">
    <p id="question">What was the name given to the version of JavaScript released in 2015, incorporating significant updates and improvements?</p>
    <select id="choices">
        <option>JavaScript 2015</option>
        <option id="correct-answer">ECMAScript 2015</option>
        <option>ES6+</option>
        <option>JSX</option>
    </select>
</div>

## Question 4

What do you use to gather individual arguments into an array in a function parameter?

<div id="answerable-multiple-choice">
    <p id="question">What do you use to gather individual arguments into an array in a function parameter?</p>
    <select id="choices">
        <option>Spread Operator (...) </option>
        <option id="correct-answer">Rest Parameter (...)</option>
        <option>Concatenation Operator (+)</option>
        <option>Assignment Operator (=)</option>
    </select>
</div>

## Question 5

Write a program that calculates 2 + 2

<div id="answerable-code-editor">
    <p id="question">Write a program that calculates 2 + 2</p>
    <p id="correct-answer">4</p>
</div>