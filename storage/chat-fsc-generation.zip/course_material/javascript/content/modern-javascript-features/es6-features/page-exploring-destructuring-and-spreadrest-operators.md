# Exploring Destructuring and Spread/Rest Operators

In JavaScript, ES6 introduced some powerful features that make working with arrays and objects more intuitive and flexible. Two of the most important features are destructuring and spread/rest operators. Let's dive into these concepts and see how they can be used to simplify your code and make it more expressive.

## Destructuring Arrays and Objects

Imagine you have a box of fruits, and you want to take out each fruit and store it in a separate container. Destructuring in JavaScript is like opening the box and placing each fruit into its own basket without having to handle each fruit individually.

### Destructuring Arrays
```javascript
// Traditional way
const fruits = ['apple', 'banana', 'orange'];
const fruit1 = fruits[0];
const fruit2 = fruits[1];
const fruit3 = fruits[2];

// Using destructuring
const [fruit1, fruit2, fruit3] = fruits;
```

In the example above, we used array destructuring to assign each element of the `fruits` array to its own variable in a single line—much more concise and readable!

### Destructuring Objects
```javascript
// Traditional way
const person = { name: 'Alice', age: 25 };
const name = person.name;
const age = person.age;

// Using destructuring
const { name, age } = person;
```

Similarly, object destructuring allows us to extract specific properties from an object and assign them to variables with the same names.

## Spread and Rest Operators

The spread and rest operators are denoted by the ellipsis (`...`) and can be used for various operations on arrays and function parameters.

### Spread Operator
The spread operator can be used to make a copy of an array, concatenate arrays, or pass elements of an array as arguments to a function.

```javascript
const arr1 = [1, 2, 3];
const arr2 = [4, 5, 6];

const combinedArray = [...arr1, ...arr2];
```

In this example, the spread operator `...arr1` and `...arr2` are used to concatenate the arrays into a new `combinedArray`.

### Rest Parameter
The rest parameter allows a function to accept an indefinite number of arguments as an array.

```javascript
function sum(...numbers) {
  return numbers.reduce((total, num) => total + num, 0);
}

sum(1, 2, 3, 4, 5); // Returns 15
```

The `...numbers` syntax gathers individual arguments into an array, allowing us to work with them as a collection.

Now that we have explored destructuring and spread/rest operators, let's apply our knowledge to a practical example.

## Applying What You've Learned

Suppose you are working on a project where you need to merge multiple arrays and calculate the sum of numbers. How would you use destructuring to simplify the process of handling arrays and the spread/rest operators to perform array operations?

<div id="answerable-multiple-choice">
    <p id="question">What do you use to gather individual arguments into an array in a function parameter?</p>
    <select id="choices">
        <option>Spread Operator (...) </option>
        <option id="correct-answer">Rest Parameter (...)</option>
        <option>Concatenation Operator (+)</option>
        <option>Assignment Operator (=)</option>
    </select>
</div>