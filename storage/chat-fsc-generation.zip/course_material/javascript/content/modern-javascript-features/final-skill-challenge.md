```markdown
# Final Skill Challenge

Congratulations on reaching the final skill challenge! This is your opportunity to put your knowledge and skills to the test by tackling a series of thought-provoking questions. Be prepared to demonstrate your understanding of the concepts covered in this course with these challenging tasks.

## Question 1

What is the name of the feature in ES6 that allows for declaring a sequence that generates a stream of values over time?

<div id="answerable-fill-blank">
    <p id="question">What is the name of the feature in ES6 that allows for declaring a sequence that generates a stream of values over time?</p>
    <p id="correct-answer">Generators</p>
</div>

## Question 2

Write a program to find the factorial of a given number using recursion in JavaScript.

<div id="answerable-code-editor">
    <p id="question">Write a program to find the factorial of a given number using recursion in JavaScript.</p>
    <p id="correct-answer">function factorialRecursive(num) {
  if (num === 1) {
    return 1;
  } else {
    return num * factorialRecursive(num - 1);
  }
}
console.log(factorialRecursive(5)); // Output: 120</p>
</div>

## Question 3

Consider the concept of Promises in JavaScript. Explain the difference between the "pending" and "settled" states of a Promise, and provide a real-world scenario where this can be useful.

<div id="answerable-fill-blank">
    <p id="question">Consider the concept of Promises in JavaScript. Explain the difference between the "pending" and "settled" states of a Promise, and provide a real-world scenario where this can be useful.</p>
    <p id="correct-answer">The "pending" state represents the initial state of a Promise, before it is either resolved or rejected. The "settled" state, on the other hand, signifies that the Promise has been fulfilled with a value (resolved) or rejected with a reason.

A real-world scenario where this can be useful is when making an asynchronous HTTP request to fetch data from a remote server. While waiting for the response, the Promise is in a "pending" state. Once the data is successfully retrieved, the Promise transitions to the "fulfilled" (settled) state with the data. If an error occurs during the request, the Promise transitions to the "rejected" (settled) state with the reason for the rejection.</p>
</div>

## Question 4

Explain the difference between the `let`, `var`, and `const` keywords for declaring variables in JavaScript. Provide an example scenario where each of these would be the most appropriate choice.

<div id="answerable-fill-blank">
    <p id="question">Explain the difference between the `let`, `var`, and `const` keywords for declaring variables in JavaScript. Provide an example scenario where each of these would be the most appropriate choice.</p>
    <p id="correct-answer">- `var` is function-scoped and can be re-declared and updated. It was the original way of declaring variables in JavaScript.

- `let` is block-scoped and can be updated but not re-declared. It is appropriate for variables that need to be reassigned within a block scope.

- `const` is block-scoped and cannot be updated or re-declared. It is suitable for defining constants or immutable values that should not change after initialization.

Example scenario:
Using `let`: When iterating through an array or implementing loop-based operations where the variable needs to be reassigned within the block scope.
Using `const`: Defining mathematical constants, such as the value of pi (π), that should not change throughout the program.
Using `var`: Legacy code that requires compatibility with older browsers, or in situations where function-level scope rather than block-level scope is desirable.</p>
</div>

## Question 5

Create a function in JavaScript that takes an array of numbers as input and returns an array of all prime numbers in the input array.

<div id="answerable-code-editor">
    <p id="question">Create a function in JavaScript that takes an array of numbers as input and returns an array of all prime numbers in the input array.</p>
    <p id="correct-answer">// Function to check if a number is prime
const isPrime = (num) => {
  if (num < 2) {
    return false;
  }
  for (let i = 2; i <= Math.sqrt(num); i++) {
    if (num % i === 0) {
      return false;
    }
  }
  return true;
};

// Function to filter prime numbers from an array
const filterPrimeNumbers = (arr) => {
  return arr.filter((num) => isPrime(num));
};

const numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11];
console.log(filterPrimeNumbers(numbers)); // Output: [2, 3, 5, 7, 11]</p>
</div>

## Question 6

In your own words, elaborate on the concept of hoisting in JavaScript. Provide a real-world analogy to illustrate how hoisting works with variable and function declarations.

<div id="answerable-fill-blank">
    <p id="question">In your own words, elaborate on the concept of hoisting in JavaScript. Provide a real-world analogy to illustrate how hoisting works with variable and function declarations.</p>
    <p id="correct-answer">Hoisting in JavaScript refers to the behavior where variable and function declarations are moved to the top of their containing scope during the compilation phase, before the code executes. This means that regardless of where variables and functions are declared in the code, they are effectively "lifted" to the top of the scope and can be accessed before they are declared.

Real-world analogy: Hoisting can be likened to creating a to-do list for tasks to be completed during the day. Even if the tasks are written later in the day, they are mentally "hoisted" to the top of your mind, establishing a plan for the day's activities. Similarly, in JavaScript, variable and function declarations are processed upfront, establishing the structure of the scope before code execution.</p>
</div>
```
The above questions are challenging, designed to fully assess your understanding of the essential JavaScript concepts taught in this course and provide opportunities for in-depth problem-solving and critical thinking.