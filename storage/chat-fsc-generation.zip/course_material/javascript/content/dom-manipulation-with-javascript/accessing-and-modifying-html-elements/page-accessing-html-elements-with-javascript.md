# Accessing HTML Elements with JavaScript

When working with web development, one of the most common tasks is accessing HTML elements and manipulating them using JavaScript. Whether you want to change the content of a paragraph, show or hide an element, or update the value of an input field, understanding how to access HTML elements with JavaScript is crucial.

## Accessing Elements by ID

Imagine a library full of books, each with a unique identification number. When you want to find a specific book, you refer to its ID. Similarly, in HTML, each element can have a unique ID attribute. JavaScript allows us to access elements by their ID using the `document.getElementById()` method.

```javascript
// Accessing an element with the ID 'example'
const element = document.getElementById('example');
```

## Accessing Elements by Class Name

In a classroom, students with similar characteristics are grouped together. Similarly, in HTML, multiple elements can share the same class name. To access elements by class name in JavaScript, we can use the `document.getElementsByClassName()` method.

```javascript
// Accessing all elements with the class 'highlighted'
const elements = document.getElementsByClassName('highlighted');
```

## Accessing Elements by Tag Name

When you enter a room and want to interact with all the chairs, you don't need to individually name each one; you can simply refer to them by their common type as "chairs". Similarly, we can access all elements with the same tag name using the `document.getElementsByTagName()` method in JavaScript.

```javascript
// Accessing all <div> elements on the page
const divElements = document.getElementsByTagName('div');
```

## Interactive Component
<div id="answerable-multiple-choice">
    <p id="question">Which JavaScript method is used to access elements by their class name?</p>
    <select id="choices">
        <option>document.getElementById()</option>
        <option id="correct-answer">document.getElementsByClassName()</option>
        <option>document.getElementsByTagName()</option>
        <option>document.querySelector()</option>
    </select>
</div>

Understanding how to access HTML elements with JavaScript is fundamental for creating dynamic web applications. Whether it's for building interactive forms, creating responsive layouts, or implementing engaging user interfaces, the ability to access and manipulate HTML elements is essential in the technology industry today.