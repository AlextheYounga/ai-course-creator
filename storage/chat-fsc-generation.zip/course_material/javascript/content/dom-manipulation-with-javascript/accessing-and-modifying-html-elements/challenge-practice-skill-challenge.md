# Practice Skill Challenge

## Question 1
In the world of web development, what is the term for the top node of the tree structure in the DOM?

<div id="answerable-multiple-choice">
    <p id="question">In the DOM, what is the term for the top node of the tree structure?</p>
    <select id="choices">
        <option>Root Node</option>
        <option id="correct-answer">Parent Node</option>
        <option>Child Node</option>
        <option>Leaf Node</option>
    </select>
</div>

## Question 2
Which JavaScript method is used to access elements by their class name in the DOM?

<div id="answerable-multiple-choice">
    <p id="question">Which JavaScript method is used to access elements by their class name?</p>
    <select id="choices">
        <option>document.getElementById()</option>
        <option id="correct-answer">document.getElementsByClassName()</option>
        <option>document.getElementsByTagName()</option>
        <option>document.querySelector()</option>
    </select>
</div>

## Question 3
What is an example of an HTML element for displaying an image?

<div id="answerable-multiple-choice">
    <p id="question">What is an example of an HTML element for displaying an image?</p>
    <select id="choices">
        <option>&lt;div&gt;</option>
        <option>&lt;img&gt;</option>
        <option>&lt;a&gt;</option>
        <option id="correct-answer">&lt;img&gt;</option>
    </select>
</div>

## Question 4
What method is used to add a new element to the DOM in JavaScript?

<div id="answerable-multiple-choice">
    <p id="question">Which method is used to add a new element to the DOM?</p>
    <select id="choices">
        <option>createAttribute</option>
        <option id="correct-answer">createElement</option>
        <option>appendChild</option>
        <option>addNewElement</option>
    </select>
</div>

## Question 5
What method is commonly used to make AJAX requests in modern JavaScript?

<div id="answerable-fill-blank">
    <p id="question">What method is commonly used to make AJAX requests in modern JavaScript?</p>
    <p id="correct-answer">fetch()</p>
</div>

Great job! Once you're ready, move on to the next section to explore more concepts in web development.