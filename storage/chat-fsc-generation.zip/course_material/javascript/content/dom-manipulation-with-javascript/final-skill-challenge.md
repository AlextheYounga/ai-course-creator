# Final Skill Challenge

## Question 1
What is an example of an HTML element used for creating a hyperlink?

<div id="answerable-multiple-choice">
    <p id="question">What is an example of an HTML element used for creating a hyperlink?</p>
    <select id="choices">
        <option>&lt;link&gt;</option>
        <option>&lt;hyperlink&gt;</option>
        <option>&lt;a&gt;</option>
        <option id="correct-answer">&lt;a&gt;</option>
    </select>
</div>

## Question 2
Which method in JavaScript is used to access elements by their unique ID attribute?

<div id="answerable-multiple-choice">
    <p id="question">Which method in JavaScript is used to access elements by their unique ID attribute?</p>
    <select id="choices">
        <option>document.querySelector()</option>
        <option>document.selectById()</option>
        <option>document.getElementByID()</option>
        <option id="correct-answer">document.getElementById()</option>
    </select>
</div>

## Question 3
What is an important benefit of adding event listeners to HTML elements in web development?

<div id="answerable-multiple-choice">
    <p id="question">What is an important benefit of adding event listeners to HTML elements in web development?</p>
    <select id="question-3-choices">
        <option>It reduces the size of HTML files</option>
        <option>It makes web pages load faster</option>
        <option>It allows for better interaction and dynamic behavior</option>
        <option id="correct-answer">It enables responsive and interactive user interfaces</option>
    </select>
</div>

## Question 4
Which JavaScript method is used to add additional behavior to an HTML element upon the occurrence of specific events such as clicks, hovers, or form submissions?

<div id="answerable-multiple-choice">
    <p id="question">Which JavaScript method is used to add additional behavior to an HTML element upon the occurrence of specific events such as clicks, hovers, or form submissions?</p>
    <select id="choices">
        <option>modifyBehavior()</option>
        <option>addBehavior()</option>
        <option>elementListener()</option>
        <option id="correct-answer">addEventListener()</option>
    </select>
</div>

## Question 5
In JavaScript, what is the method used to remove an element from the Document Object Model (DOM)?

<div id="answerable-multiple-choice">
    <p id="question">In JavaScript, what is the method used to remove an element from the Document Object Model (DOM)?</p>
    <select id="choices">
        <option>removeElement()</option>
        <option>deleteNode()</option>
        <option>removeChild()</option>
        <option id="correct-answer">remove()</option>
    </select>
</div>

## Question 6
What do you achieve by knowing how to access HTML elements with JavaScript?

<div id="answerable-fill-blank">
    <p id="question">What do you achieve by knowing how to access HTML elements with JavaScript?</p>
    <p id="correct-answer">You can dynamically interact with and modify the content and appearance of a web page.</p>
</div>

## Question 7
Imagine you want to create a webpage with three distinct sections, each with different content and styling. Which HTML element would you use to contain all of these distinct sections?

<div id="answerable-multiple-choice">
    <p id="question">Imagine you want to create a webpage with three distinct sections, each with different content and styling. Which HTML element would you use to contain all of these distinct sections?</p>
    <select id="choices">
        <option>&lt;article&gt;</option>
        <option>&lt;main&gt;</option>
        <option>&lt;section&gt;</option>
        <option id="correct-answer">&lt;div&gt;</option>
    </select>
</div>

## Question 8
When writing JavaScript code, what is used to group lines of code and improve code readability?

<div id="answerable-multiple-choice">
    <p id="question">When writing JavaScript code, what is used to group lines of code and improve code readability?</p>
    <select id="choices">
        <option>Code Nests</option>
        <option>Line Sequences</option>
        <option>Statement Blocks</option>
        <option id="correct-answer">Code Blocks</option>
    </select>
</div>

## Question 9
What action would you perform to update a webpage without needing to refresh the entire page?

<div id="answerable-fill-blank">
    <p id="question">What action would you perform to update a webpage without needing to refresh the entire page?</p>
    <p id="correct-answer">Use AJAX to communicate with the server in the background and fetch data dynamically.</p>
</div>

## Question 10
In web development, what is an alternative term for "HTML elements"?

<div id="answerable-fill-blank">
    <p id="question">In web development, what is an alternative term for "HTML elements"?</p>
    <p id="correct-answer">DOM elements</p>
</div>

## Question 11
Briefly explain the purpose of the 'fetch()' method in JavaScript.

<div id="answerable-fill-blank">
    <p id="question">Briefly explain the purpose of the 'fetch()' method in JavaScript.</p>
    <p id="correct-answer">The 'fetch()' method is used to make asynchronous HTTP requests and retrieve data from a server.</p>
</div>

## Question 12
What element in the DOM is used to group together lists of similar items?

<div id="answerable-multiple-choice">
    <p id="question">What element in the DOM is used to group together lists of similar items?</p>
    <select id="choices">
        <option>&lt;directory&gt;</option>
        <option>&lt;menu&gt;</option>
        <option>&lt;list&gt;</option>
        <option id="correct-answer">&lt;ul&gt;</option>
    </select>
</div>

## Question 13
If you want to create a tabbed user interface on a website, which DOM concept would be crucial to understand and utilize?

<div id="answerable-multiple-choice">
    <p id="question">If you want to create a tabbed user interface on a website, which DOM concept would be crucial to understand and utilize?</p>
    <select id="choices">
        <option>Attribute Manipulation</option>
        <option>Event Delegation</option>
        <option id="correct-answer">Node Manipulation</option>
        <option>CSS Styling</option>
    </select>
</div>

## Question 14
What JavaScript method is commonly used to add and remove CSS classes to and from HTML elements?

<div id="answerable-fill-blank">
    <p id="question">What JavaScript method is commonly used to add and remove CSS classes to and from HTML elements?</p>
    <p id="correct-answer">toggle()</p>
</div>

## Question 15
Imagine you want to ensure that a specific JavaScript function runs only after the entire HTML document has been loaded and parsed. Which JavaScript event would you use to achieve this?

<div id="answerable-multiple-choice">
    <p id="question">Imagine you want to ensure that a specific JavaScript function runs only after the entire HTML document has been loaded and parsed. Which JavaScript event would you use to achieve this?</p>
    <select id="choices">
        <option>DOMContentLoaded</option>
        <option>HTMLLoaded</option>
        <option>DocumentReady</option>
        <option id="correct-answer">load</option>
    </select>
</div>

## Question 16
What is the purpose of the CSS 'display' property with a value of 'none' when applied to an HTML element?

<div id="answerable-fill-blank">
    <p id="question">What is the purpose of the CSS 'display' property with a value of 'none' when applied to an HTML element?</p>
    <p id="correct-answer">It hides the HTML element and does not allocate any space for it within the layout.</p>
</div>

## Question 17
Explain what is meant by the term "semantic HTML" in the context of web development.

<div id="answerable-fill-blank">
    <p id="question">Explain what is meant by the term "semantic HTML" in the context of web development.</p>
    <p id="correct-answer">Semantic HTML refers to the use of elements that clearly convey the meaning and purpose of their content to both the browser and the developer, enhancing accessibility, SEO, and maintainability.</p>
</div>

## Question 18
What is the primary benefit of wrapping related HTML elements with a <div> element?

<div id="answerable-fill-blank">
    <p id="question">What is the primary benefit of wrapping related HTML elements with a &lt;div&gt; element?</p>
    <p id="correct-answer">It provides a way to group elements, organize layout, and apply styling or behavior to the entire group.</p>
</div>

## Question 19
When using the 'fetch()' method in JavaScript, what does the '.json()' method accomplish?

<div id="answerable-fill-blank">
    <p id="question">When using the 'fetch()' method in JavaScript, what does the '.json()' method accomplish?</p>
    <p id="correct-answer">It parses the response from the server as JSON, returning a Promise that resolves to the JSON data.</p>
</div>

## Question 20
In web development, what does the term "callback" typically refer to when working with asynchronous operations in JavaScript?

<div id="answerable-fill-blank">
    <p id="question">In web development, what does the term "callback" typically refer to when working with asynchronous operations in JavaScript?</p>
    <p id="correct-answer">A callback is a function provided as an argument to another function, which is then invoked by the latter function at a particular time or based on certain conditions.</p>
</div>

Congratulations on completing the Final Skill Challenge! You've demonstrated an excellent understanding of HTML elements and JavaScript concepts. Keep up the fantastic work!