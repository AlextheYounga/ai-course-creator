# Practice Skill Challenge

Congratulations on making it this far! It's time to put your newly acquired JavaScript knowledge to the test. Below are five practice problems that will challenge your understanding of the concepts covered in this course. Don't worry; they're fun and interactive!

## Problem 1
**Question:** What type of development does JavaScript play a crucial role in?

<div id="answerable-multiple-choice">
    <p id="question">What type of development does JavaScript play a crucial role in?</p>
    <select id="choices">
        <option>Mobile App Development</option>
        <option id="correct-answer">Web Development</option>
        <option>Game Development</option>
        <option>Data Science</option>
    </select>
</div>

## Problem 2
**Question:** What data type would you use to store multiple pieces of information in JavaScript?

<div id="answerable-fill-blank">
    <p id="question">What data type would you use to store multiple pieces of information in JavaScript?</p>
    <p id="correct-answer">Array</p>
</div>

## Problem 3
**Question:** What type of loop will execute its block of code at least once, even if the condition is false?

<div id="answerable-multiple-choice">
    <p id="question">Which type of loop will execute its block of code at least once, even if the condition is false?</p>
    <select id="choices">
        <option>for Loop</option>
        <option>while Loop</option>
        <option>do...while Loop</option>
        <option id="correct-answer">All of the above</option>
    </select>
</div>

## Problem 4
**Question:** What type of loop is commonly used to iterate over a range of values?

<div id="answerable-multiple-choice">
    <p id="question">What type of loop is commonly used to iterate over a range of values?</p>
    <select id="choices">
        <option>while loop</option>
        <option>if-else loop</option>
        <option id="correct-answer">for loop</option>
        <option>loop loop</option>
    </select>
</div>

## Problem 5
**Question:** What concept in JavaScript allows a function to remember and access its lexical scope even when that function is executed outside the lexical scope?

<div id="answerable-fill-blank">
    <p id="question">What concept in JavaScript allows a function to remember and access its lexical scope even when that function is executed outside the lexical scope?</p>
    <p id="correct-answer">Closures</p>
</div>

Take your time, think through each problem, and select the answers that you believe are correct. Good luck, and have fun!