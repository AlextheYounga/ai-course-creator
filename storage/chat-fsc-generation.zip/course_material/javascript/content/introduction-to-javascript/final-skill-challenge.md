# Final Skill Challenge

Congratulations on reaching the final skill challenge! This is your chance to put your JavaScript knowledge to the test with a series of interactive and thought-provoking problems. Take your time and carefully consider each question before selecting your answer. Good luck!

## Problem 1
**Question:** What type of development does JavaScript play a crucial role in?

<div id="answerable-multiple-choice">
    <p id="question">What type of development does JavaScript play a crucial role in?</p>
    <select id="choices">
        <option>Mobile App Development</option>
        <option id="correct-answer">Web Development</option>
        <option>Game Development</option>
        <option>Data Science</option>
    </select>
</div>

## Problem 2
**Question:** What data type would you use to store multiple pieces of information in JavaScript?

<div id="answerable-fill-blank">
    <p id="question">What data type would you use to store multiple pieces of information in JavaScript?</p>
    <p id="correct-answer">Array</p>
</div>

## Problem 3
**Question:** What type of loop will execute its block of code at least once, even if the condition is false?

<div id="answerable-multiple-choice">
    <p id="question">Which type of loop will execute its block of code at least once, even if the condition is false?</p>
    <select id="choices">
        <option>for Loop</option>
        <option>while Loop</option>
        <option>do...while Loop</option>
        <option id="correct-answer">All of the above</option>
    </select>
</div>

## Problem 4
**Question:** What type of loop is commonly used to iterate over a range of values?

<div id="answerable-multiple-choice">
    <p id="question">What type of loop is commonly used to iterate over a range of values?</p>
    <select id="choices">
        <option>while loop</option>
        <option>if-else loop</option>
        <option id="correct-answer">for loop</option>
        <option>loop loop</option>
    </select>
</div>

## Problem 5
**Question:** What concept in JavaScript allows a function to remember and access its lexical scope even when that function is executed outside the lexical scope?

<div id="answerable-fill-blank">
    <p id="question">What concept in JavaScript allows a function to remember and access its lexical scope even when that function is executed outside the lexical scope?</p>
    <p id="correct-answer">Closures</p>
</div>

## Problem 6
**Question:** What does the `return` statement do in a JavaScript function?

<div id="answerable-fill-blank">
    <p id="question">What does the `return` statement do in a JavaScript function?</p>
    <p id="correct-answer">Specifies the value that the function will output.</p>
</div>

## Problem 7
**Question:** In JavaScript, what type of variable can be accessed from anywhere in the code, whether inside a function or outside of it?

<div id="answerable-fill-blank">
    <p id="question">In JavaScript, what type of variable can be accessed from anywhere in the code, whether inside a function or outside of it?</p>
    <p id="correct-answer">Global variable</p>
</div>

## Problem 8
**Question:** What is the output of `console.log(3 + 4 + "5")` in JavaScript?

<div id="answerable-fill-blank">
    <p id="question">What is the output of `console.log(3 + 4 + "5")` in JavaScript?</p>
    <p id="correct-answer">75</p>
</div>

## Problem 9
**Question:** How many times will the following `for` loop execute: `for (let i = 0; i < 3; i++) {}`?

<div id="answerable-fill-blank">
    <p id="question">How many times will the following `for` loop execute: `for (let i = 0; i < 3; i++) {}`?</p>
    <p id="correct-answer">3 times</p>
</div>

## Problem 10
**Question:** What is the result of `10 == '10'` in JavaScript?

<div id="answerable-multiple-choice">
    <p id="question">What will be the result of `10 == '10'` in JavaScript?</p>
    <select id="choices">
        <option>true</option>
        <option>false</option>
        <option id="correct-answer">It depends on the comparison type, as JavaScript will perform implicit type conversion if the compared values are of different types.</option>
    </select>
</div>

## Problem 11
**Question:** What will be the output of `console.log("5" + 3)` in JavaScript?

<div id="answerable-fill-blank">
    <p id="question">What will be the output of `console.log("5" + 3)` in JavaScript?</p>
    <p id="correct-answer">53</p>
</div>

## Problem 12
**Question:** Which built-in method can be used to determine the type of a variable or object in JavaScript?

<div id="answerable-fill-blank">
    <p id="question">Which built-in method can be used to determine the type of a variable or object in JavaScript?</p>
    <p id="correct-answer">typeof</p>
</div>

## Problem 13
**Question:** What is the correct way to write a comment in JavaScript?

<div id="answerable-fill-blank">
    <p id="question">What is the correct way to write a comment in JavaScript?</p>
    <p id="correct-answer">// This is a single-line comment or /* This is a multi-line comment */</p>
</div>

## Problem 14
**Question:** Which symbol is used for equality comparison in JavaScript?

<div id="answerable-fill-blank">
    <p id="question">Which symbol is used for equality comparison in JavaScript?</p>
    <p id="correct-answer">== (double equals)</p>
</div>

## Problem 15
**Question:** What will be the output of `console.log(typeof [])` in JavaScript?

<div id="answerable-fill-blank">
    <p id="question">What will be the output of `console.log(typeof [])` in JavaScript?</p>
    <p id="correct-answer">object</p>
</div>

## Problem 16
**Question:** In JavaScript, what is the purpose of an `if` statement?

<div id="answerable-fill-blank">
    <p id="question">In JavaScript, what is the purpose of an `if` statement?</p>
    <p id="correct-answer">To execute a block of code if a specified condition is true.</p>
</div>

## Problem 17
**Question:** What will the following code output: `console.log(true + true + true)` in JavaScript?

<div id="answerable-fill-blank">
    <p id="question">What will the following code output: `console.log(true + true + true)` in JavaScript?</p>
    <p id="correct-answer">3</p>
</div>

## Problem 18
**Question:** What is the correct way to define a function in JavaScript?

<mark>Answerable Component:</mark>
<div id="answerable-code-editor">
    <p id="question">Write a JavaScript function named 'greet' that takes a parameter 'name' and returns a greeting message.</p>
    <p id="correct-answer">function greet(name) { return `Hello, ${name}!`; }</p>
</div>

## Problem 19
**Question:** What is the purpose of a `while` loop in JavaScript?

<div id="answerable-fill-blank">
    <p id="question">What is the purpose of a `while` loop in JavaScript?</p>
    <p id="correct-answer">To execute a block of code as long as a specified condition is true.</p>
</div>

## Problem 20
**Question:** What does the acronym DOM stand for in web development?

<div id="answerable-fill-blank">
    <p id="question">What does the acronym DOM stand for in web development?</p>
    <p id="correct-answer">Document Object Model</p>
</div>

You've reached the final set of challenges! Take your time to carefully consider each question and select your answers. Good luck, and congratulations on completing the course!