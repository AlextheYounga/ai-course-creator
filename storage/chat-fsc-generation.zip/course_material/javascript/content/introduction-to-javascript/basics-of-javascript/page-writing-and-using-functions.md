# Writing and Using Functions

In JavaScript, functions are like recipes. Just as a recipe defines a set of instructions for creating a dish, a function defines a set of instructions for performing a specific task in your code. Functions help you break down your code into reusable blocks, making your programs more organized, easier to understand, and simpler to maintain. 

### Function Syntax
In JavaScript, you can define a function using the `function` keyword followed by the function name and a pair of parentheses. Here's a simple example of a function that adds two numbers together:

```javascript
function addNumbers(num1, num2) {
    return num1 + num2;
}
```

In this example:
- `addNumbers` is the name of the function.
- `num1` and `num2` are parameters, which are like placeholders for the actual values you'll use when you call the function.
- The `return` statement specifies the value that the function will output.

### Calling Functions
Once a function is defined, you can call or execute it by using the function name followed by a pair of parentheses containing the arguments. Here's how you can call the `addNumbers` function:

```javascript
let result = addNumbers(5, 3);
console.log(result); // Output: 8
```

In this example, `5` and `3` are the arguments provided to the `addNumbers` function.

### The Importance of Functions
Imagine needing to bake a cake, and instead of using a recipe, you had to repeatedly memorize the exact steps and measurements each time. It would be time-consuming and prone to mistakes. Functions in JavaScript work similarly to baking recipes. They allow you to encapsulate a set of instructions and reuse them whenever needed, saving time and reducing the risk of errors.

### Coding Challenge
<div id="answerable-code-editor">
    <p id="question">Write a function named 'calculateArea' that takes two parameters, 'width' and 'height', and returns the calculated area. Assume the parameters are both numbers.</p>
    <p id="correct-answer">function calculateArea(width, height) { return width * height; }</p>
</div>

Now, let's practice writing a function that calculates the area of a rectangle. Have a go at the coding challenge above!
