# Practice Skill Challenge

Great! Now it's time to put your knowledge to the test with some practice problems. Take your time and do your best to answer each question. Let's get started!

### Question 1

Which of the following is a real-world example where poor performance can directly impact revenue?

<details>
  <summary>Click for Interactive Element</summary>

  <div id="answerable-multiple-choice">
      <p id="question">Which of the following is a real-world example where poor performance can directly impact revenue?</p>
      <select id="choices">
          <option>The speed of a turtle race</option>
          <option id="correct-answer">The performance of an e-commerce website</option>
          <option>Weather forecasts accuracy</option>
          <option>Library book categorization</option>
      </select>
  </div>
</details>

### Question 2

What metric measures the time taken for the browser to render any text, image, or non-white canvas element on the screen?

<details>
  <summary>Click for Interactive Element</summary>

  <div id="answerable-multiple-choice">
      <p id="question">What metric measures the time taken for the browser to render any text, image, or non-white canvas element on the screen?</p>
      <select id="choices">
          <option>First Input Delay (FID)</option>
          <option>First Contentful Paint (FCP)</option>
          <option id="correct-answer">Total Blocking Time (TBT)</option>
          <option>Time to Interactive (TTI)</option>
      </select>
  </div>
</details>

### Question 3

Which technique can help reduce the size of files to speed up load times?

<details>
  <summary>Click for Interactive Element</summary>

  <div id="answerable-multiple-choice">
      <p id="question">Which technique can help reduce the size of files to speed up load times?</p>
      <select id="choices">
          <option>Running more server-side scripts</option>
          <option id="correct-answer">Compressing images, scripts, and stylesheets</option>
          <option>Adding more plugins to the website</option>
      </select>
  </div>
</details>

### Question 4

True or False: HTTP request bundling can reduce the number of network requests and improve application performance.

<details>
  <summary>Click for Interactive Element</summary>

  <div id="answerable-multiple-choice">
      <p id="question">True or False: HTTP request bundling can reduce the number of network requests and improve application performance</p>
      <select id="choices">
          <option>True</option>
          <option id="correct-answer">False</option>
      </select>
  </div>
</details>

### Question 5

What technique can be used to minimize the data payloads sent between the client and the server?

<details>
  <summary>Click for Interactive Element</summary>

  <div id="answerable-fill-blank">
      <p id="question">What technique can be used to minimize the data payloads sent between the client and the server?</p>
      <p id="correct-answer">Minimizing Data Payloads</p>
  </div>
</details>

Great job! Take your time to work through these questions and then check your answers after you're done. Good luck!