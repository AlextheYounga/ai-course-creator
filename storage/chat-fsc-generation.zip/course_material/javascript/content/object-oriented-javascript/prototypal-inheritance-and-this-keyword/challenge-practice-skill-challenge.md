Sure, here are the practice problems for the "Practice Skill Challenge" page:

### 1. Object Properties and Methods

Suppose you have an object representing a book:

```javascript
let book = {
  title: "The Great Gatsby",
  author: "F. Scott Fitzgerald",
  year: 1925,
  synopsis: function() {
    return `The book "${this.title}" by ${this.author} was published in ${this.year}.`;
  }
};
```

**Question:**
What would be the output when calling the `synopsis` method of the `book` object?

### 2. Creating a Class

Imagine you are creating a class for representing animals. Consider the following code snippet:

```javascript
class Animal {
  constructor(name, type) {
    this.name = name;
    this.type = type;
  }

  introduction() {
    return `This is a ${this.type} named ${this.name}.`;
  }
}
```

**Question:**
What would be the output when calling the `introduction` method on an instance of the `Animal` class with `name` as "Buddy" and `type` as "dog"?

### 3. Understanding 'this' Keyword

Consider the following code snippet:

```javascript
function Product(name, price) {
  this.name = name;
  this.price = price;
}

Product.prototype.calculateFinalPrice = function(discount) {
  return this.price * (1 - discount);
};

const product1 = new Product('Laptop', 1000);
```

**Question:**
What would be the result when calling the `calculateFinalPrice` method on `product1` with a 10% discount?

### 4. Inheriting Properties and Methods

Imagine you have a `Shape` class with a method `draw` and a `Circle` class that extends the `Shape` class with its own `draw` method.

**Question:**
Which concept allows the `Circle` class to inherit the properties and methods of the `Shape` class?

### 5. The Power of Prototypal Inheritance

Suppose we have a `Vehicle` constructor function that sets the make and model of a vehicle and a `Car` constructor function that extends the `Vehicle` constructor function to add specific properties and methods for cars.

**Question:**
What method is used to inherit the prototype from the `Vehicle` constructor function to the `Car` constructor function?

I hope these practice problems help reinforce your understanding of the concepts.