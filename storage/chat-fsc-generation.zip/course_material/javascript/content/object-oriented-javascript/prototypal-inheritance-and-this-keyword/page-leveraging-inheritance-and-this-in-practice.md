# Leveraging Inheritance and 'this' in Practice

Now that you have gained an understanding of prototypal inheritance and the 'this' keyword, it's time to put that knowledge into practice. In this section, we will explore how to leverage inheritance and the 'this' keyword in real-world scenarios.

## The Power of Inheritance and 'this'
Imagine a scenario where you are building an application that manages different types of vehicles. You have a generic `Vehicle` object, and based on that, you want to create more specific objects like `Car` and `Motorcycle`. Instead of writing the same code for each type of vehicle, you can use inheritance to create a relationship between them. This allows you to inherit common properties and methods from the `Vehicle` object, while still being able to define specific properties and methods for each type of vehicle. This promotes code reusability and makes your codebase more maintainable.

Let's take the example of a `Vehicle` constructor function and see how you can extend it to create a `Car` constructor function using prototypal inheritance.

```javascript
function Vehicle(make, model, year) {
  this.make = make;
  this.model = model;
  this.year = year;
}

Vehicle.prototype.getDetails = function() {
  return `${this.year} ${this.make} ${this.model}`;
};

function Car(make, model, year, doors) {
  Vehicle.call(this, make, model, year);
  this.doors = doors;
}

// Inherit prototype from Vehicle
Car.prototype = Object.create(Vehicle.prototype);

Car.prototype.drive = function() {
  return `${this.getDetails()} is driving`;
};

const myCar = new Car('Toyota', 'Camry', 2020, 4);
console.log(myCar.drive());
```

Here, the `Car` constructor function inherits the properties and methods of the `Vehicle` constructor function, and we also define a specific `drive` method for the `Car`.

## The 'this' Keyword in Practice
The 'this' keyword is commonly used to refer to the object that the function is bound to. When used correctly, it can make the code more concise and reusable.

Consider a scenario where you are building an online shopping application. You have multiple products, each with its price, and you want to add a method to calculate the final price of the product after applying any discounts.

Let's see how the 'this' keyword can be leveraged to achieve this:

```javascript
function Product(name, price) {
  this.name = name;
  this.price = price;
}

Product.prototype.calculateFinalPrice = function(discount) {
  return this.price * (1 - discount);
};

const product1 = new Product('Headphones', 50);
console.log(product1.calculateFinalPrice(0.2)); // Applying 20% discount
```

In this example, the `calculateFinalPrice` method uses the 'this' keyword to refer to the specific product instance, allowing us to calculate the final price based on its price and the discount provided.

## Putting it into Practice
Let's put our knowledge into practice with a question:

<div id="answerable-multiple-choice">
    <p id="question">Which keyword is commonly used to refer to the object that the function is bound to?</p>
    <select id="choices">
        <option>this</option>
        <option id="correct-answer">That</option>
        <option>They</option>
        <option>It</option>
    </select>
</div>

Understanding how to leverage inheritance and the 'this' keyword is key to writing efficient and maintainable code.

In the next section, we will delve into some common mistakes and best practices related to prototypal inheritance and the 'this' keyword.