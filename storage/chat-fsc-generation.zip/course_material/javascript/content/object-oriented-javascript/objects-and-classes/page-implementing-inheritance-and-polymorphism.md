# Implementing Inheritance and Polymorphism

Inheritance and polymorphism are essential concepts in object-oriented programming that allow us to create more organized, reusable, and scalable code. By understanding and implementing these concepts, you can build robust applications with clear hierarchies and structures.

## Inheritance

Imagine inheritance in programming as similar to a family tree. A child inherits characteristics from their parents, and in programming, a class can inherit properties and behaviors from another class. This promotes code reusability and helps in creating a hierarchy of classes.

Let's consider an example to illustrate inheritance. Suppose we have a `Vehicle` class with properties like `color`, `model`, and methods like `startEngine` and `stopEngine`. Now, we can create a `Car` class that inherits from the `Vehicle` class. The `Car` class will automatically have the properties and methods of the `Vehicle` class, and we can also add specific properties and methods that are unique to cars, such as `numberOfSeats` or `drive`.

```javascript
class Vehicle {
  constructor(color, model) {
    this.color = color;
    this.model = model;
  }

  startEngine() {
    console.log('Engine started');
  }

  stopEngine() {
    console.log('Engine stopped');
  }
}

class Car extends Vehicle {
  constructor(color, model, numberOfSeats) {
    super(color, model);
    this.numberOfSeats = numberOfSeats;
  }

  drive() {
    console.log('Car is moving');
  }
}

let car1 = new Car('red', 'XYZ', 4);
car1.startEngine(); // Output: Engine started
car1.drive(); // Output: Car is moving
```

In this example, the `Car` class inherits the properties and methods of the `Vehicle` class, benefiting from code reuse.

## Polymorphism

Polymorphism, on the other hand, allows objects to be treated as instances of their parent class. This means that a method can behave differently based on the object it is called on.

To understand this better, let's consider a real-world analogy. Think of a shape class in a drawing application with a method `drawShape`. The `drawShape` method would behave differently based on the shape it's drawing, whether it's a circle, square, or triangle. This is polymorphism in action.

Now, let's consider a coding example to explain polymorphism further.

```javascript
class Shape {
  draw() {
    console.log('Drawing a shape');
  }
}

class Circle extends Shape {
  draw() {
    console.log('Drawing a circle');
  }
}

class Square extends Shape {
  draw() {
    console.log('Drawing a square');
  }
}

function drawAnyShape(shape) {
  shape.draw();
}

let circle = new Circle();
let square = new Square();

drawAnyShape(circle); // Output: Drawing a circle
drawAnyShape(square); // Output: Drawing a square
```

In this example, the `drawAnyShape` function can take any shape object and call its `draw` method, which behaves differently based on the actual shape.

## Interactive Element
<div id="answerable-multiple-choice">
    <p id="question">What concept allows objects to be treated as instances of their parent class?</p>
    <select id="choices">
        <option>Inheritance</option>
        <option id="correct-answer">Polymorphism</option>
        <option>Encapsulation</option>
        <option>Abstraction</option>
    </select>
</div>

Understanding and implementing inheritance and polymorphism will give you a solid foundation for building complex and maintainable applications.

Now that we've explored the concepts of inheritance and polymorphism, let's dive deeper into their practical implementations in JavaScript.