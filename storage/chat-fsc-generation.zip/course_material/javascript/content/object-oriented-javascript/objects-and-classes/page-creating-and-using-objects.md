# Creating and Using Objects

In the world of JavaScript, objects are like characters in a story. Each object has its own unique traits, behaviors, and abilities. They allow us to organize and structure our code in a way that reflects the real world around us. Let's dive into the fascinating world of creating and using objects in JavaScript.

## Objects: The Building Blocks of JavaScript

Imagine you are building a virtual city in a game. You would have different types of buildings such as houses, schools, and offices. Each building has its own characteristics like the number of floors, the color, and the number of rooms. In JavaScript, an object is like a building; it encapsulates data (characteristics) and functions (behaviors) into a single entity. 

Let's create a simple object representing a car:

```javascript
let car = {
    make: "Tesla",
    model: "Model 3",
    year: 2022,
    isElectric: true,
    displayInfo: function() {
        return `${this.year} ${this.make} ${this.model}`;
    }
};
```

In this example, the `car` object has properties like `make`, `model`, `year`, and `isElectric`, as well as a method `displayInfo` to display information about the car.

## Understanding Properties and Methods

Properties are like the characteristics of an object, such as the make, model, and year of the car. Methods, on the other hand, are the behaviors associated with the object, like the ability to accelerate, brake, and display information.

Now, imagine you have a dog object with properties like `breed`, `age`, and a method called `bark()` which makes the dog bark when called.

## Using Objects in Real-World Scenarios

Objects are used extensively in the technology industry. Imagine you are building a social media platform. You would have objects representing users, posts, comments, and likes, each with their own unique properties and methods. Understanding objects and their usage is crucial in modern software development and web applications.

### Interactive Element
<div id="answerable-fill-blank">
    <p id="question">What is the term for the characteristics of an object?</p>
    <p id="correct-answer">Properties</p>
</div>

Now that we have grasped the concept of creating and using objects, let's continue exploring the fascinating world of object-oriented JavaScript!
