# Understanding Classes

In JavaScript, classes are blueprints for creating objects with similar properties and methods. They allow us to create multiple instances (or objects) of the same type, each with its own state while sharing the same functionality. 

Let's imagine classes as cookie cutters. Just as a cookie cutter is used to make identical cookies with the same shape, a class is used to create objects with the same structure and behavior.

```javascript
class Car {
  constructor(make, model) {
    this.make = make;
    this.model = model;
  }

  displayInfo() {
    return `This car is a ${this.make} ${this.model}.`;
  }
}

const myCar = new Car("Toyota", "Camry");
const friendCar = new Car("Honda", "Civic");

console.log(myCar.displayInfo()); // Output: This car is a Toyota Camry.
console.log(friendCar.displayInfo()); // Output: This car is a Honda Civic.
```

In the example above, the `Car` class acts as the cookie cutter, and `myCar` and `friendCar` are the cookies cut out by that cookie cutter.

### Key Concepts

1. **Constructor**: It is a special method for creating and initializing objects created with a class.
2. **this Keyword**: It refers to the current instance of the class and is used to access class variables.
3. **Instances**: Objects created using the class blueprint are called instances.

Now, let's reinforce our understanding with a quick question.

## Fill in the Blank

What keyword is used to refer to the current instance of the class?
- "it"
- "self"
- "this"
- "that"

<div id="answerable-fill-blank">
    <p id="question">What keyword is used to refer to the current instance of the class?</p>
    <p id="correct-answer">"this"</p>
</div>

Understanding classes is essential in building scalable and maintainable code. In the modern tech industry, frameworks like React and Angular heavily utilize classes to create reusable and modular components. Embracing this concept will pave the way to mastering more advanced JavaScript frameworks and libraries.