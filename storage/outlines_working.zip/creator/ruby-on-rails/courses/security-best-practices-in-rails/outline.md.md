```json
[
    {
        "chapterName": "Understanding Web Security",
        "pages": [
            "Introduction to Web Security",
            "Common Web Security Threats",
            "Principles of Secure Web Development"
        ]
    },
    {
        "chapterName": "Implementing Authentication and Authorization",
        "pages": [
            "Introduction to Authentication and Authorization",
            "Secure Authentication in Rails",
            "Authorization Best Practices"
        ]
    },
    {
        "chapterName": "Securing Rails Applications",
        "pages": [
            "Overview of Rails Application Security",
            "Best Practices for Securing Rails Applications",
            "Implementing Security Measures in Rails"
        ]
    }
]
```