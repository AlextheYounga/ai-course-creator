When it comes to building web applications, one of the most essential tasks is performing CRUD operations on a database. CRUD stands for Create, Read, Update, and Delete, and these operations are fundamental to managing data within a relational database.

In the world of Ruby on Rails, ActiveRecord plays a crucial role in interacting with a database. In this section, we'll dive into how SQL and ActiveRecord in Rails are used to perform these CRUD operations.

Let's start with the basics. When we talk about CRUD operations in the context of a database, think of it as managing a library. You create new books, read existing books, update information in the books, and delete books when they are no longer needed. It’s the same concept, just with data in a database.

### Creating Data
In ActiveRecord, creating new records in a database table is straightforward. We can use the `create` method on a model class to add a new row to the corresponding table. Here's an example:

```ruby
new_user = User.create(name: "John", email: "john@example.com")
```

Imagine you are adding a new book to the library’s catalogue. You provide all the necessary information, and the librarian adds the book to the system.

### Reading Data
Reading data from a database is often done based on specific conditions or requirements. In Rails, you can use methods like `find`, `where`, and `first` to retrieve data from the database. Here’s a simple example of reading data:

```ruby
user = User.find(1)
```

Just like going to the library and asking for a specific book by providing its details or title.

### Updating Data
Updating existing records in the database is a common task. With ActiveRecord, it's as easy as calling the `update` method on an instance of a model. For example:

```ruby
user = User.find(1)
user.update(name: "Jonathan")
```

This is like editing the details of a book in the library’s catalogue, perhaps updating the author's name or adding a new edition.

### Deleting Data
Sometimes, we need to remove records from the database, which is where the delete operation comes in. In Rails, you can use the `destroy` method to delete records. For example:

```ruby
user = User.find(1)
user.destroy
```

In our library analogy, think of this as removing a book from the catalogue when it’s no longer part of the collection.

Understanding how to perform CRUD operations in SQL and ActiveRecord is fundamental for building robust web applications. It allows you to manage and manipulate data effectively, just as you would interact with the contents of a well-organized library.