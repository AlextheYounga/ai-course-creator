```json
[
    {
        "courseName": "Introduction to Ruby on Rails",
        "modules": [
            {
                "name": "Ruby Language Basics",
                "skills": [
                    "Understanding of basic programming concepts (variables, loops, conditional statements)",
                    "Mastery of Ruby syntax and language features",
                    "Understanding of Ruby's object model"
                ]
            },
            {
                "name": "Web Development Fundamentals",
                "skills": [
                    "Understanding of HTML",
                    "Understanding of CSS",
                    "Understanding of how websites work (client-server model)"
                ]
            },
            {
                "name": "Rails Framework Essentials",
                "skills": [
                    "Understanding of MVC (Model-View-Controller) architecture",
                    "Ability to create and manage Rails applications",
                    "Understanding of Rails conventions and best practices"
                ]
            }
        ]
    },
    {
        "courseName": "Database Management with Rails",
        "modules": [
            {
                "name": "Relational Databases and ActiveRecord",
                "skills": [
                    "Understanding of relational databases",
                    "Ability to use ActiveRecord for database operations",
                    "Understanding of database indexing and optimization"
                ]
            }
        ]
    },
    {
        "courseName": "Testing and Debugging in Rails",
        "modules": [
            {
                "name": "Test-Driven Development (TDD)",
                "skills": [
                    "Ability to write and run test cases using RSpec or other testing frameworks",
                    "Proficiency in debugging Rails applications",
                    "Understanding of TDD (Test-Driven Development) principles"
                ]
            }
        ]
    },
    {
        "courseName": "Security Best Practices in Rails",
        "modules": [
            {
                "name": "Web Security and Authentication",
                "skills": [
                    "Understanding of common web security threats",
                    "Ability to implement secure authentication and authorization in Rails applications",
                    "Awareness of best practices for securing Rails applications"
                ]
            }
        ]
    },
    {
        "courseName": "Performance Optimization in Rails",
        "modules": [
            {
                "name": "Identifying and Addressing Performance Bottlenecks",
                "skills": [
                    "Ability to identify and address performance bottlenecks in Rails applications",
                    "Understanding of caching strategies and techniques",
                    "Proficiency in optimizing database queries and application code for performance"
                ]
            }
        ]
    }
]
```